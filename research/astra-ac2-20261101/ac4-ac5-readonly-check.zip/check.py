"""Read-only, source-bound API integrity checks; makes no model calls."""
import hashlib,json
from pathlib import Path
from urllib.request import urlopen
ROOT=Path(__file__).resolve().parent
BASE='http://127.0.0.1:8000/api/v1'
GROUP='EXPC133D630DAC1441E93AB7DF407A5E364'
RUNS=['RUNB8AF4F09C517464F9C965F0860001313','RUNB53C3562569941B7A5E6A8F66B6B53FE']
def get(path):
    with urlopen(BASE+path,timeout=30) as r:
        raw=r.read()
    return json.loads(raw),hashlib.sha256(raw).hexdigest()
audits=[]; tests=[];results=[]; hashes={}
for rid in RUNS:
    run,hashes[rid+':audit']=get('/audits/'+rid)
    suite,hashes[rid+':tests']=get('/audits/'+rid+'/tests')
    result,hashes[rid+':results']=get('/audits/'+rid+'/results')
    audits.append(run);tests.append(suite);results.append(result)
bundle,hashes['group:export']=get('/experiments/'+GROUP+'/reproducibility-bundle.json')
conversation,hashes['conversation:export']=get('/conversations/'+audits[0]['conversation_id']+'/export')
assert all(a['run_id']==rid and a['status']=='COMPLETED' for a,rid in zip(audits,RUNS))
assert all(a['experiment_id']==GROUP for a in audits) and audits[0]['conversation_id']==audits[1]['conversation_id']
sig=lambda t:(t['dimension'],t['prompt'],t['expected_behavior'],tuple(sorted(t['supporting_memory_ids'])),t['test_type'])
suite_sets=[sorted(map(sig,ts)) for ts in tests]
assert len(suite_sets[0])==len(suite_sets[1])==4 and suite_sets[0]==suite_sets[1]
assert sorted(map(sig,bundle['frozen_test_suite']))==suite_sets[0]
config_fields=('provider','model','pipeline_provider','pipeline_model','evaluator_provider','evaluator_model','memory_strategy','retrieval_mode','temperature','random_seed','test_budget','target_memory_capacity','target_system_adapter','memory_maintenance_policy')
assert all(audits[0].get(k)==audits[1].get(k) for k in config_fields)
assert audits[0]['target_memory_writer'] != audits[1]['target_memory_writer']
assert {x['configuration']['run_id'] for x in bundle['runs']}==set(RUNS)
export_runs={x['audit_run']['run_id']:x for x in conversation['audits']}
assert set(RUNS)<=set(export_runs)
details=[]
for rid,result in zip(RUNS,results):
    exp=next(x for x in bundle['runs'] if x['configuration']['run_id']==rid)
    raw=export_runs[rid]
    assert result['run_id']==rid and exp['result']['run_id']==rid
    assert len(result['answers'])==len(raw['target_responses'])==len(raw['evaluations'])==4
    for f in result['failures']:
        detail,hashes[rid+':failure:'+f['failure_id']]=get('/audits/'+rid+'/failures/'+f['failure_id'])
        assert detail==f
        assert f['test']['run_id']==rid and f['response']['run_id']==rid
        assert f['test']['test_id']==f['response']['test_id']==f['evaluation']['test_id']
        assert f['evaluation']['response_id']==f['response']['response_id']
        assert f['test']['prompt'] and f['test']['expected_behavior'] and f['response']['response_text']
        assert f['evidence'] and f['source_statements'] and f['evaluation']['failure_classification']
        assert all(m['source_message_ids'] for m in f['evidence'])
        exported=next(x for x in exp['answers'] if x['test_id']==f['test']['test_id'])
        assert exported['prompt']==f['test']['prompt'] and exported['expected_behavior']==f['test']['expected_behavior'] and exported['answer']==f['response']['response_text']
        assert exported['evaluation_id']==f['failure_id'] and exported['source_evidence'] and exported['source_statements']
        assert any(x['evaluation_id']==f['failure_id'] for x in raw['evaluations'])
        details.append({'run_id':rid,'test_id':f['test']['test_id'],'failure_id':f['failure_id'],'evidence_count':len(f['evidence']),'source_statement_count':len(f['source_statements']),'classification':f['evaluation']['failure_classification']})
metadata=[]
for a,result in zip(audits,results):
    responses=[x['response'] for x in result['answers']]
    assert all(r['execution_metadata']['reported_model']=='gpt-6-astra' and r['execution_metadata']['requested_reasoning_effort']=='max' for r in responses)
    metadata.append({'run_id':a['run_id'],'writer':a['target_memory_writer'],'model':a['model'],'pipeline_model':a['pipeline_model'],
        'test_budget':a['test_budget'],'configured_temperature':a['temperature'],'configured_seed':a['random_seed'],
        'reported_sampling':sorted({r['execution_metadata']['sampling_control'] for r in responses}),
        'reported_temperature':sorted({str(r['execution_metadata']['sent_temperature']) for r in responses}),
        'reported_model':'gpt-6-astra','requested_reasoning_effort':'max',
        'generator_versions':sorted({x['generator_version'] for x in next(t for t,rr in zip(tests,RUNS) if rr==a['run_id'])})})
out={'check':'read-only API check against currently running application','run_ids':RUNS,'experiment_id':GROUP,
 'same_frozen_suite':True,'questions_per_run':4,'same_listed_configuration_except_writer':True,
 'failure_detail_export_checks':details,'metadata':metadata,'response_sha256':hashes,
 'limits':['Existing completed runs were created before subsequent code changes; checking their data through the current API is not a new current-revision end-to-end execution.',
 'The comparison is an intervention between writers, not two identical configurations or independent repeatability trials.',
 'Model-controlled sampling and provider responses prevent deterministic replay guarantees.',
 'Automatic failure classification is not independently verified by this structural check.','Source/export access and endpoint consistency are not a security or usability certification.']}
(ROOT/'read-only-check.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('Read-only checks passed; failures inspected:',len(details))
