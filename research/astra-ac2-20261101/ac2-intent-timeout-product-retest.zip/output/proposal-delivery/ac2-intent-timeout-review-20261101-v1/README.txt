本包只审核本次真实产品流程新生成的4道题，不重复审核上一批材料。
两个 reviewer-*-completed.json 含来源、题目、参考答案与 Astra high 独立 AI 初审。
请两位人工各自核对，并分别填写 human-reviewer-1.json / human-reviewer-2.json。可以纠正 AI 判断，也可以保留 uncertain。
本次已保存4/4题；AI一致认为4题有效，尚未记录人工确认。单个开发历史，不能据此宣称10历史全部修复。
