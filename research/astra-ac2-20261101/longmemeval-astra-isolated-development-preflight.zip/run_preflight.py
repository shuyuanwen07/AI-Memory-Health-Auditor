import hashlib,json,os,sys
from datetime import datetime,timezone
from pathlib import Path
from dotenv import load_dotenv
OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/y/Documents/26-S2/5623/AI Memory Health Auditor')
load_dotenv(ROOT/'.env',override=True)
os.environ['DATABASE_URL']='sqlite://'
if not os.environ.get('OPENAI_API_KEY'): raise SystemExit('No OpenAI credential configured')
sys.path.insert(0,str(OUT));sys.path.insert(1,str(ROOT))
from app.benchmarks.live import LiveBenchmarkRunner
from app.schemas.benchmark import LiveBenchmarkRequest
from app.target_ai.providers import single_attempt_target_request
protocol=json.loads((OUT/'protocol.json').read_text());amend=json.loads((OUT/'execution-amendment.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if sha(OUT/'protocol.json')!=amend['protocol_sha256'] or sha(Path(__file__))!=amend['runner_sha256']:raise SystemExit('Protocol or runner changed')
if any(sha(OUT/path)!=v for path,v in protocol['isolated_python_sha256'].items()):raise SystemExit('Isolated app changed')
results=[]
for case in protocol['cases']:
 path=OUT/case['file']
 if sha(path)!=case['source_sha256']:raise SystemExit('Source changed')
 data=json.loads(path.read_text())
 for strategy in protocol['strategies']:
  filename=OUT/(case['case_id']+'-'+strategy+'.json')
  if filename.exists():raise SystemExit('Existing attempt found; no re-dispatch')
  record={'case_id':case['case_id'],'strategy':strategy,'status':'dispatched','started_utc':datetime.now(timezone.utc).isoformat(),'protocol_sha256':amend['protocol_sha256']}
  with filename.open('x',encoding='utf8') as f:json.dump(record,f,indent=2)
  try:
   request=LiveBenchmarkRequest(payload=data,source_authorised=True,source_label='Official LongMemEval-S development full history',
    dataset_provenance={'dataset_version':'98d7416c24c778c2fee6e6f3006e7a073259d48f','license':'MIT per pinned dataset manifest','citation':'Wu et al., LongMemEval (ICLR 2025)'},
    provider='openai',model='gpt-6-astra',strategies=[strategy],max_cases=1,target_memory_capacity=50,target_memory_profile=protocol['memory_profile'])
   with single_attempt_target_request():response=LiveBenchmarkRunner().run(request)
   result=response.model_dump(mode='json');metadata=result['conditions'][0]['cases'][0]['execution_metadata']
   if metadata.get('reported_model')!='gpt-6-astra' or metadata.get('requested_reasoning_effort')!='max':raise ValueError('Missing Astra max provider receipt')
   record.update(status='completed',result=result)
  except Exception as e:
   record.update(status='failed_or_ambiguous',error_type=type(e).__name__,http_status=getattr(e,'status_code',None))
  record['finished_utc']=datetime.now(timezone.utc).isoformat();filename.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
  print(case['case_id'],strategy,record['status'],flush=True);results.append({'case_id':case['case_id'],'strategy':strategy,'status':record['status'],'file_sha256':sha(filename)})
  if record['status']!='completed':
   print('Stopped after failure/ambiguous dispatch; no automatic retry.',flush=True);(OUT/'collection-summary.json').write_text(json.dumps({'status':'partial','results':results},indent=2)+'\n');raise SystemExit(1)
(OUT/'collection-summary.json').write_text(json.dumps({'status':'completed','results':results},indent=2)+'\n')
print('Completed two-case isolated preflight; model answers require independent review.',flush=True)
