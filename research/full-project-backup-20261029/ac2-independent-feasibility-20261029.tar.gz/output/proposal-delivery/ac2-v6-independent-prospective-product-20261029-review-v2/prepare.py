import copy,hashlib,json,pathlib,zipfile
from datetime import datetime,timezone
root=pathlib.Path(__file__).resolve().parents[3]
old=root/'output/proposal-delivery/ac2-v6-independent-prospective-product-20261029-v1'
source_path=root/'output/proposal-delivery/ac2-independent-source-proposal-20261029/histories.json'
out=pathlib.Path(__file__).resolve().parent

def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def h(x):return hashlib.sha256(x).hexdigest()
def write(name,x):
 with (out/name).open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')

p=json.loads((old/'protocol.json').read_bytes());originals=[json.loads((old/f'reviewer-{i}.json').read_bytes()) for i in (1,2)]; source_bytes=source_path.read_bytes();assert h(source_bytes)==p['source_sha256']
source=json.loads(source_bytes)['conversations'];byid={s['conversation_id']:s for s in source};assert len(byid)==len(source)==30
for original in originals:
 assert original['material_sha256']==h(canon({'histories':original['histories'],'items':original['items']}))
 assert len(original['items'])==17 and len(original['histories'])==15
assert originals[0]['items']==originals[1]['items'] and originals[0]['histories']==originals[1]['histories']
items=copy.deepcopy(originals[0]['items']); histories=copy.deepcopy(originals[0]['histories']);hby={x['history_id']:x for x in histories}
assert len(hby)==15 and len({x['blind_id'] for x in items})==17
for hid, hist in hby.items():
 assert hid in byid and hist['messages']==byid[hid]['messages']
 source_ids={m['source_id'] for m in hist['messages']};assert len(source_ids)==len(hist['messages'])
 memories={m['memory_id']:m for m in hist['provisional_memories']};assert len(memories)==len(hist['provisional_memories'])
 for m in memories.values():
  assert all(x in source_ids for x in m['source_message_ids'])
for item in items:
 assert item['history_id'] in hby and item['grounding'] is None and item['executability'] is None
 mems={m['memory_id']:m for m in hby[item['history_id']]['provisional_memories']}
 for ref in item['supporting_provisional_memories']:
  assert ref['memory_id'] in mems and ref==mems[ref['memory_id']]
 item['reference_answer_validity']=None
question_material={'histories':histories,'items':items};question_hash=h(canon(question_material))
missing=sorted(set(byid)-set(hby));assert len(missing)==15
source_items=[]
for hid in missing:
 row=byid[hid];ids={m['source_id'] for m in row['messages']};assert len(ids)==len(row['messages'])
 records=[]
 for i,r in enumerate(row['proposed_interpretations'],1):
  assert all(x in ids for x in r['source_ids'])
  records.append({'review_item_id':f'{hid}-R{i:02d}','type':r['type'],'source_ids':r['source_ids'],'interpretation':r['interpretation'],'validity':None,'reason':''})
 source_items.append({'history_id':hid,'messages':row['messages'],'proposed_interpretations':records,'overall_source_validity':None,'overall_reason':''})
source_material={'histories':source_items};source_hash=h(canon(source_material))
question_instruction='请独立核对完整原始消息、临时提取事实和关系、题目与参考答案。逐题将 grounding（来源依据是否成立）、executability（题目能否依据材料明确作答）以及 reference_answer_validity（参考答案是否准确回答题目且受来源支持）分别填为 valid、invalid 或 uncertain，并在 reason 中说明。AI 编写的来源与自动提取事实均未被人工确认；不要在审核前看对方判断、系统状态或评分。'
source_instruction='这些历史没有生成题目，不代表题目无效。请独立阅读每段完整来源，逐条判断作者提出的事实或关系解释是否有来源支持，填写 validity 为 valid、invalid 或 uncertain，并说明原因；overall_source_validity 用于记录这段来源是否足够明确供后续研究，不把未生成题目计入题目有效率。来源和解释由 AI 编写，尚未经人工审核；请披露 AI 辅助。'
for i in (1,2):
 decl={'reviewer_label':None,'completed_by_human':None,'completed_independently':None,'seen_other_review':None,'seen_automatic_scores_or_warnings':None,'used_ai_assistance':None}
 write(f'questions-reviewer-{i}.json',{'format':'ac2-v6-question-human-review-v2','reviewer_slot':i,'material_sha256':question_hash,'instructions':question_instruction,'reviewer_declaration':decl,**question_material})
 write(f'sources-reviewer-{i}.json',{'format':'ac2-v6-no-question-source-review-v2','reviewer_slot':i,'material_sha256':source_hash,'instructions':source_instruction,'reviewer_declaration':decl,**source_material})
readme='AC2 前瞻研究 v2：每位审核者请分别填写自己的 questions JSON（17 题，三项判断）及 sources JSON（15 段无题来源，核对来源解释），不得互看判断或在审核前查看系统自动状态。所有判断均填 valid、invalid 或 uncertain 并说明；审核声明也请逐项填写。15 段没有题目，不代表无效题，也不计入题目有效率。两份来源和题目由 AI 编写或自动提取，尚未人工确认。完成后分别返回两个 JSON。\n'
(out/'填写说明.txt').write_text(readme,encoding='utf8')
for i in (1,2):
 with zipfile.ZipFile(out/f'reviewer-{i}-v2.zip','x',zipfile.ZIP_DEFLATED) as z:
  for name in (f'questions-reviewer-{i}.json',f'sources-reviewer-{i}.json','填写说明.txt'): z.write(out/name,name)
with zipfile.ZipFile(out/'双人审核-v2.zip','x',zipfile.ZIP_DEFLATED) as z:
 for i in (1,2):
  for name in (f'questions-reviewer-{i}.json',f'sources-reviewer-{i}.json'):z.write(out/name,name)
 z.write(out/'填写说明.txt','填写说明.txt')
manifest={'format':'ac2-v6-review-v2-manifest-v1','created_at_utc':datetime.now(timezone.utc).isoformat(),'original_protocol_sha256':h((old/'protocol.json').read_bytes()),'original_source_sha256':h(source_bytes),'original_review_material_sha256':originals[0]['material_sha256'],'questions_material_sha256':question_hash,'source_review_material_sha256':source_hash,'blind_ids':sorted(x['blind_id'] for x in items),'question_history_ids':sorted(hby),'no_question_history_ids':missing,'no_question_not_invalid':True,'counts':{'questions':17,'question_histories':15,'no_question_histories':15},'files_sha256':{p.name:h(p.read_bytes()) for p in sorted(out.iterdir()) if p.is_file() and p.name!='manifest.json'}}
write('manifest.json',manifest)
print('Verified source/IDs: 17 questions, 15 question histories, 15 separate no-question histories; all labels blank.')
