import fs from 'node:fs/promises';
import {PresentationFile,FileBlob} from '@oai/artifact-tool';
import {finalizePresentation} from '/Users/y/.codex/plugins/cache/openai-primary-runtime/presentations/26.1020.11618/skills/presentations/container_tools/artifact_tool_utils.mjs';
const root=process.cwd(), work=root+'/.presentation-validation/v52-work', source=root+'/output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_2026-10-28_v51.pptx', out=root+'/output/presentation/ELEC5623_Memory_Auditor_Final_Results_2026-10-29_v56.pptx';
const p=await PresentationFile.importPptx(await FileBlob.load(source));
const inspected=await p.inspect({kind:'textbox,shape,chart,table,image',maxChars:4000000});
const ids=inspected.ndjson.split('\n').filter(Boolean).map(x=>JSON.parse(x)).filter(x=>['textbox','shape','chart','table','image'].includes(x.kind)).map(x=>x.id);
p.delete(ids);
const slides=p.slides.items; if(slides.length!==13)throw Error('expected 13 slides');
const C={navy:'#12304A',ink:'#152B3C',teal:'#087F8C',muted:'#536B7C',bg:'#F7F7F4',gray:'#DCE6E9',red:'#BC504C',orange:'#B47D2B',white:'#FFFFFF',light:'#DDF0EE'};
const add=(s,x,y,w,h,text,size=24,color=C.ink,bold=false,align='left')=>{let o=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{style:'solid',fill:'none',width:0}});o.text=text;o.text.style={typeface:'Arial',fontSize:size,color,bold,alignment:align,verticalAlignment:'middle',wrap:'square'};return o};
const rect=(s,x,y,w,h,fill)=>s.shapes.add({geometry:'rect',position:{left:x,top:y,width:w,height:h},fill,line:{style:'solid',fill:'none',width:0}});
const title=(s,num,speaker,t,sub)=>{s.background.fill=C.bg;rect(s,58,38,5,20,C.teal);add(s,75,34,1090,24,`SPEAKER ${speaker}     •     ${String(num).padStart(2,'0')}`,15,C.teal,true);add(s,58,77,1155,62,t,34,C.ink,true);if(sub)add(s,60,143,1140,38,sub,19,C.muted);};
const foot=(s,t)=>{rect(s,60,665,1160,1,C.gray);add(s,60,675,1140,25,t,14,C.muted);};
const note=(s,t)=>{s.speakerNotes.text=t;};
const bar=(s,y,name,value,txt,color=C.teal)=>{add(s,75,y,440,30,name,20,C.ink);rect(s,520,y+8,510,18,'#E5ECEE');rect(s,520,y+8,Math.max(2,510*value),18,color);add(s,1035,y-1,180,32,txt,18,C.ink,true,'right');};
const metric=(s,x,y,w,label,before,after,note2)=>{add(s,x,y,w,34,label,20,C.muted,true);add(s,x,y+56,w,50,before,32,C.red,true);add(s,x,y+118,w,50,after,32,C.teal,true);add(s,x,y+183,w,55,note2,16,C.muted);};
const card=(s,x,y,w,h,k,v,body)=>{rect(s,x,y,w,h,C.white);rect(s,x,y,5,h,C.teal);add(s,x+20,y+18,w-40,27,k,17,C.teal,true);add(s,x+20,y+54,w-40,43,v,28,C.ink,true);add(s,x+20,y+106,w-40,h-122,body,18,C.muted);};
// 1. Title
{
 let s=slides[0];s.background.fill=C.navy;rect(s,62,55,5,27,'#5CD1BE');add(s,80,55,1000,26,'ELEC5623    GROUP 2',16,'#7EE2CF',true);add(s,80,164,1100,136,'AI Memory\nHealth Auditor',55,C.white,true);add(s,80,335,1020,84,'Detect memory failures, inspect evidence, and test improvements',27,'#D4E5EA');rect(s,80,565,1100,1,'#587084');add(s,80,595,900,30,'Speaker 1   ·   Speaker 2   ·   Speaker 3   ·   Speaker 4',17,'#D4E5EA');
 note(s,`Speaker 1\nToday we present the AI Memory Health Auditor. Our project asks whether we can inspect how an assistant uses remembered information, identify failures and test whether a change improves the observed behaviour. We will explain the problem, the system, our experimental design, our results and the limitations. Our results include both improvements and findings that did not support the original hypothesis. The figures in the presentation match the current dashboard and use selected synthetic histories and a selected benchmark subset.\nSource: docs/EXPERIMENT_REPORT_2026-10-28.md; Dashboard compact-final-dashboard-v1.json.`);
}
// 2. Why
{
 let s=slides[1];title(s,2,1,'Why audit AI memory?','A memory can be accurate when stored and still be used incorrectly later.');
 card(s,66,238,350,260,'BEFORE','Prefers Python','General preference across projects.');card(s,465,238,350,260,'PROJECT','Java for Cedar','A specific project requires Java.');card(s,865,238,350,260,'RISK','Wrong context','An answer that applies Python to Cedar misses the task-specific requirement.');foot(s,'Example for explanation. Real audits retain the source, question, answer and assessment.');
 note(s,`Speaker 1\nAn assistant may remember a fact correctly yet apply it to the wrong task. In this illustrative example, a user generally prefers Python, while a particular project requires Java. If the assistant recommends Python for that project, the problem is not simply whether a fact exists in storage. It is whether the assistant uses the applicable fact in context. Updates and conflicting records create similar risks. The auditor exposes these cases in a repeatable workflow and keeps the evidence needed to inspect the decision.\nSource: project proposal and docs/EXPERIMENT_REPORT_2026-10-28.md.`);
}
// 3 workflow
{
 let s=slides[2];title(s,3,1,'How the auditor works','A human confirms the source facts before the target is tested.');
 const xs=[63,301,539,777,1015],labels=[['1  SOURCE','Dialogue'],['2  EXTRACT','Facts + links'],['3  CONFIRM','Human review'],['4  TEST','Target answers'],['5  ASSESS','Evidence + scores']];
 labels.forEach((a,i)=>{rect(s,xs[i],260,202,150,C.white);rect(s,xs[i],260,5,150,C.teal);add(s,xs[i]+18,280,165,30,a[0],16,C.teal,true);add(s,xs[i]+18,330,165,58,a[1],23,C.ink,true);if(i<4)add(s,xs[i]+206,315,29,45,'›',33,C.teal,true,'center')});
 add(s,64,474,1100,64,'Four abilities: accuracy, freshness, conflict resolution and appropriate use',21,C.ink,true);foot(s,'Sources, answers, uncertain judgments and evidence remain available for inspection.');
 note(s,`Speaker 1\nThe audit begins with an authorised conversation. The system proposes facts and relationships such as an update or conflict, and an operator confirms or edits the memory. It then generates tests, sends the questions to the target assistant and evaluates the responses against the confirmed evidence. We report four abilities: accuracy, freshness, conflict resolution and appropriate use. The product keeps the source, target answer and reasons behind an assessment. A source-scope review can also flag an ambiguous question for review rather than silently discarding it.\nSource: system workflow and experiment report.`);
}
// 4 design
{
 let s=slides[3];title(s,4,2,'The three experiments','Each experiment answers a different question.');
 card(s,66,235,350,282,'EXPERIMENT A','Audit methods','Compare direct, fixed-template and contextual questions under the same budget.');card(s,465,235,350,282,'EXPERIMENT B','Memory strategies','Compare four retrieval strategies on the same questions.');card(s,865,235,350,282,'EXPERIMENT C','External check','Compare strategy results on a selected LongMemEval subset.');foot(s,'The Auditor’s own scoring reliability is evaluated separately with human-reviewed answers.');
 note(s,`Speaker 2\nOur evaluation has three parts. Experiment A compares three question-construction methods with equal budgets. Experiment B compares four memory strategies on matched synthetic histories and repeated questions. Experiment C examines a selected LongMemEval subset. These studies answer different questions: A concerns methods, B concerns target memory strategies, and C checks performance on an external benchmark selection. We also test the Auditor’s scoring reliability separately, because a better target strategy is not by itself proof that the Auditor is correct.\nSource: experiment report, Proposal Experiments A–C.`);
}
// 5 A
{
 let s=slides[4];title(s,5,2,'A: all methods found the same known defects','Each method detected 3 of 9 predefined defect IDs.');
 bar(s,245,'Direct questions',1/3,'3 / 9');bar(s,335,'Fixed templates',1/3,'3 / 9');bar(s,425,'Contextual questions',1/3,'3 / 9');
 add(s,76,535,1100,52,'No advantage for contextual questions was demonstrated in this sample.',23,C.ink,true);foot(s,'3 related synthetic histories · 36 answers · 18 failed answers outside the frozen defect inventory.');
 note(s,`Speaker 2\nIn experiment A, each method detected three of nine predefined defect identifiers. The contextual method did not outperform the direct or fixed-template methods on this sample. There were 36 answers across three related synthetic histories. Two independent human reviewers using AI assistance agreed on 33 failures and three passes, but 18 failed answers did not map to the narrower frozen defect inventory. The three out of nine figure therefore describes discovery against that predefined inventory, not every possible failure. A later expansion was stopped during AI question review because the usable groups were concentrated in a single conflict scenario.\nSource: experiment-a-human-return-20261029-v1/analysis.json; ai-readiness-summary.json.`);
}
// 6 B
{
 let s=slides[5];title(s,6,2,'B: four strategies on the same histories','Human-consensus passes across 36 answers per strategy.');
 bar(s,215,'First-match retrieval',.25,'9 / 36  ·  25%');bar(s,300,'Relationship-priority retrieval',.75,'27 / 36  ·  75%');bar(s,385,'Match the task and project',.50,'18 / 36  ·  50%');bar(s,470,'Consider time and importance',.75,'27 / 36  ·  75%');foot(s,'3 previously used synthetic histories · 3 repeats per history · repeated answers are related.');
 note(s,`Speaker 2\nExperiment B used the same histories and questions for four strategies. Two independent human reviewers used AI assistance. The agreed human-pass counts were nine out of 36 for first-match retrieval, 27 out of 36 for relationship-priority retrieval, 18 out of 36 for matching the task and project, and 27 out of 36 for considering time and importance. These results help us compare behaviour across strategies, rather than assume a strategy is better from its name. However, the 36 answers per strategy come from only three previously used synthetic histories with repeated runs. They are related observations, not 36 independent cases.\nSource: ac1-ac2-b-return-20261029-v1/b-consensus-summary.json.`);
}
// 7 C
{
 let s=slides[6];title(s,7,3,'C: four strategies on selected benchmark cases','Human-adjudicated pass rate among decided answers.');
 bar(s,215,'First-match retrieval',17/87,'17 / 87  ·  19.5%');bar(s,300,'Relationship-priority retrieval',57/81,'57 / 81  ·  70.4%');bar(s,385,'Match the task and project',47/84,'47 / 84  ·  56.0%');bar(s,470,'Consider time and importance',50/84,'50 / 84  ·  59.5%');foot(s,'30 selected LongMemEval cases · 3 repeats · 24 uncertain answers excluded from decided denominators.');
 note(s,`Speaker 3\nThis slide shows the four-strategy extension on 30 selected LongMemEval cases. Each strategy produced three answers per case, and the values shown use the human-adjudicated decided answers as their denominators. The independent reviewers used AI assistance. First-match passed 17 of 87, relationship-priority 57 of 81, task-and-project matching 47 of 84, and time-and-importance 50 of 84. Across all four strategies, 24 answers remained uncertain. Because the cases were selected and repeated answers share a case, these figures are descriptive and should not be treated as the full benchmark result.\nSource: four-strategy-adjudicated-bounds-2026-10-29.json.`);
}
// 8 Ranking
{
 let s=slides[7];title(s,8,3,'C: the original ranking check','A separate two-strategy comparison checked direction, not the four-strategy scores.');
 add(s,70,238,520,48,'Direction agreed',23,C.muted,true);add(s,70,298,520,90,'3 / 3 repeats',54,C.teal,true);add(s,70,418,530,90,'Relationship-priority ranked above first-match in the saved B and C comparisons.',21,C.ink);
 rect(s,670,238,520,235,C.white);add(s,700,270,460,38,'LongMemEval subset',20,C.muted,true);add(s,700,322,460,70,'14 / 500 cases',42,C.ink,true);add(s,700,410,460,35,'First-match 15/42 · Relationship-priority 30/42',17,C.muted);foot(s,'Automatic grades. This earlier two-strategy result is separate from the four-strategy extension.');
 note(s,`Speaker 3\nThe original proposal also asked whether the local ordering was consistent with an external benchmark. In the saved earlier B and C comparisons, relationship-priority retrieval ranked above first-match retrieval in the same direction in all three repeats. The C part used 14 of the 500 LongMemEval cases, with 42 repeated answers per strategy: 15 passed for first-match and 30 for relationship-priority. This is a limited two-strategy directional check. It should not be confused with the separate four-strategy extension on 30 cases, and it does not establish a full-benchmark result.\nSource: archived Phase 4 B/C and docs/EXPERIMENT_REPORT_2026-10-28.md.`);
}
// 9 AC3
{
 let s=slides[8];title(s,9,3,'Auditor scoring improved on the same answers','Old and new scorers assessed the same 118 human-consensus answers.');
 metric(s,70,225,350,'FAILURES DETECTED','55 / 68  ·  80.9%','61 / 68  ·  89.7%','Old scorer → new scorer');
 metric(s,465,225,350,'CORRECT CLASSIFICATION','0 / 55  ·  0%','54 / 61  ·  88.5%','Old detected failures were unclassified');
 metric(s,860,225,350,'FALSE POSITIVES','18 / 50  ·  36.0%','0 / 50  ·  0%','Zero observed in this selected sample');
 foot(s,'120 answers · 30 synthetic histories · 2 reviewer disagreements excluded from the main comparison.');
 note(s,`Speaker 3\nWe tested the Auditor itself by applying old and new scoring methods to the same saved answers. Two independent human reviewers, using AI assistance, agreed on 118 of the 120 responses: 68 failures and 50 passes. The new scorer detected 61 of 68 failures compared with 55 of 68 previously. It correctly classified 54 of its 61 detected failures; the old scorer left all 55 detected failures unclassified. False positives fell from 18 of 50 human-agreed passes to zero observed out of 50. These results met the descriptive thresholds for this selected synthetic sample. Zero observed errors does not prove the population error is zero, and the two disagreements were preserved separately.\nSource: paired-authorized-retest-20261029-v1/paired-analysis.json.`);
}
// 10 AC1
{
 let s=slides[9];title(s,10,4,'AC1: relation matching improved, fact matching fell','Paired comparison on the 27 histories completed in both runs.');
 add(s,74,230,480,38,'REFERENCE RELATIONSHIP IDs',20,C.muted,true);add(s,74,287,500,57,'58 / 80   to   79 / 80',34,C.teal,true);add(s,74,353,480,32,'72.5% to 98.8%',21,C.ink);
 add(s,680,230,480,38,'REFERENCE FACT IDs',20,C.muted,true);add(s,680,287,500,57,'212 / 215   to   205 / 215',34,C.ink,true);add(s,680,353,480,32,'98.6% to 95.3%',21,C.muted);
 rect(s,75,450,1100,105,C.light);add(s,100,468,1050,70,'ID matches can be partial. Three new histories were incomplete and are excluded from this paired comparison.',19,C.ink);foot(s,'Selected synthetic histories · reviewed reference is not exhaustive · ID matching is not strict recall.');
 note(s,`Speaker 4\nFor AC1, we compared extraction results on 27 histories that completed in both runs. Relationship reference-ID matches increased from 58 of 80 to 79 of 80. Fact reference-ID matches decreased from 212 of 215 to 205 of 215. Both directions matter: the relation result improved, but the fact result did not. Three histories in the newer run were partial and are excluded from this paired comparison. A later targeted retry produced five relationships which two reviewers judged valid, while one older reference relationship was judged invalid. ID matching can be partial and the reference set is not exhaustive, so these are not strict recall estimates.\nSource: ac1-paired-comparison.json and ac1-analysis.json.`);
}
// 11 AC2
{
 let s=slides[10];title(s,11,4,'AC2: more valid questions, but many remain invalid','Both versions were reviewed against the same selected histories.');
 bar(s,250,'Earlier generator',51/111,'51 / 111  ·  45.9%');bar(s,350,'Newer generator',63/117,'63 / 117  ·  53.8%');
 rect(s,76,430,1110,160,'#F5E9DB');add(s,101,443,1060,130,'54 / 117 newer questions were invalid; 37 passed the old gate.\nScope review sent all 37 for review; it also flagged 53 valid questions.\n0 invalid accepted in this replay. Human review burden remains high.',20,C.ink,true);foot(s,'30 related synthetic histories · retrospective replay, not independent validation.');
 note(s,`Speaker 4\nAC2 asks whether generated questions are grounded and executable. In the paired comparison, the earlier generator produced 111 questions, of which 51 were adjudicated valid. The newer generator produced 117, of which 63 were valid. That is an improvement in the number of valid questions, but 54 of the newer generator’s 117 questions were still adjudicated invalid. The existing automatic gate had accepted 37 of those invalid questions. Missing outputs are recorded separately. The source-scope review was then replayed on the same observed development questions. It sent all 37 previously accepted invalid questions for review. The old gate had already rejected the other 17, leaving zero invalid questions accepted in this replay. It also flagged 53 previously accepted valid questions for human review, while nine valid questions remained rejected by the old gate. This adds a real review burden. The same development questions were used in the replay, so the zero observed misses do not demonstrate generalisation or prove all errors are fixed. A warning-free question is not automatically valid.\nSource: ac2-adjudicated-paired-summary.json and product-scope-retrospective-replay-v3.json.`);
}
// 12 tutor loop
{
 let s=slides[11];title(s,12,4,'Diagnosis, repair and retest','A saved synthetic example shows the complete workflow.');
 const xs=[65,460,855], v=[['1  DIAGNOSE','Missing facts','Inspect answer-time evidence to identify the retrieval problem.'],['2  REPAIR','Change retrieval','Try a targeted retrieval policy for the same task.'],['3  RETEST','Same questions','Compare before and after using the shared test suite.']];
 v.forEach((a,i)=>card(s,xs[i],215,350,225,a[0],a[1],a[2]));add(s,74,487,1100,55,'Targeted repair: 1 / 6 to 3 / 6 on the shared decided questions',25,C.teal,true);foot(s,'One synthetic history · automatic assessments · 5 of 24 answers uncertain; not a general causal claim.');
 note(s,`Speaker 4\nThe tutor asked us to show a complete problem-to-improvement loop. In a saved synthetic example, the audit exposed missing facts in the answer-time evidence. We inspected the evidence, changed the retrieval behaviour and ran the same questions again. Among six shared questions with decided automatic assessments, the targeted condition had three passes compared with one in the original condition. Five of 24 answers across the broader group were uncertain. This illustrates a useful workflow, but the example is small and automatically assessed, so we do not claim a general causal effect from this one case.\nSource: current-source diagnosis-led comparison EXP627CCD21BC1D465996A30FF0E630739B.`);
}
// 13 summary
{
 let s=slides[12];title(s,13,4,'What we learned and what comes next','Evidence supports a useful workflow, with clear remaining limits.');
 add(s,75,218,1100,45,'What the results show',23,C.teal,true);add(s,75,270,1100,88,'The Auditor can expose and compare failures. Its newer scorer improved on the selected paired sample.',23,C.ink);
 add(s,75,390,1100,45,'What we will improve',23,C.teal,true);add(s,75,440,1100,120,'Improve question quality and source coverage. Test on more diverse, independent histories and complete human review of AI-assisted findings.',23,C.ink);
 foot(s,'A did not establish a method advantage · repeated cases are related · C covers a selected subset.');
 note(s,`Speaker 4\nOur system provides a traceable way to find memory failures, inspect evidence and compare changes. The paired scoring study shows an improvement on the selected answers, while experiment A did not show the contextual method outperforming the alternatives. Question quality remains a major constraint: the newer generator still produced many invalid questions. Next we would improve question specificity and extraction coverage, validate on more diverse histories and benchmark cases, and complete human review of the AI-assisted judgments and remaining disagreements. We would also test usability and measure uncertainty across independent cases. These next steps are important before claiming broad generalisation.\nSource: experiment report and current Dashboard results.`);
}
for(let i=0;i<slides.length;i++){const blob=await p.export({slide:slides[i],format:'png',scale:1});await fs.writeFile(`${work}/slide-${String(i+1).padStart(2,'0')}.png`,new Uint8Array(await blob.arrayBuffer()));}
const candidate=work+'/candidate.pptx';await (await PresentationFile.exportPptx(p)).save(candidate);
const result=await finalizePresentation({workspaceDir:root,candidatePath:candidate,finalPath:out,pythonExecutable:'/Users/y/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3',integrityValidatorPath:'/Users/y/.codex/plugins/cache/openai-primary-runtime/presentations/26.1020.11618/skills/presentations/container_tools/inspect_presentation_package_integrity.py',layoutValidatorPath:'/Users/y/.codex/plugins/cache/openai-primary-runtime/presentations/26.1020.11618/skills/presentations/container_tools/inspect_presentation_layout_geometry.py',layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit'],fontPolicy:{basis:'design',families:['Arial']},explicitTotalSlideCount:13,verifyArtifactToolImport:true,receiptPath:work+'/validation-v56.json'});
console.log(JSON.stringify(result));
