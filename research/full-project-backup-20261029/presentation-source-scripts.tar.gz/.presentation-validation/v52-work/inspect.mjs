import {PresentationFile, FileBlob} from '@oai/artifact-tool';
import fs from 'node:fs/promises';
const p=await PresentationFile.importPptx(await FileBlob.load('output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_2026-10-28_v51.pptx'));
console.log('slides',p.slides.items.length);console.log((await p.inspect({kind:'slide,textbox,shape,chart,notes',maxChars:12000})).ndjson);
for (let i=0;i<p.slides.items.length;i++) {const blob=await p.export({slide:p.slides.items[i],format:'png',scale:0.7});await fs.writeFile(`.presentation-validation/v52-work/source-${i+1}.png`,new Uint8Array(await blob.arrayBuffer()))}
