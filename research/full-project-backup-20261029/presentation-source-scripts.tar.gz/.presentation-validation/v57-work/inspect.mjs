import {PresentationFile,FileBlob} from '@oai/artifact-tool';
const p=await PresentationFile.importPptx(await FileBlob.load('output/presentation/ELEC5623_Memory_Auditor_Final_Results_2026-10-29_v56.pptx'));
console.log('slides',p.slides.items.length);
console.log((await p.inspect({kind:'slide,textbox,shape,notes',search:'ID matches can be partial',maxChars:10000})).ndjson);
let s=p.slides.items[9];console.log('notes',s.speakerNotes.text);for(const o of s.shapes.items) {let t=String(o.text??'');if(t)console.log(JSON.stringify({id:o.id,name:o.name,text:t,position:o.position}));}
