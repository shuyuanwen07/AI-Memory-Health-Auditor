import csv
import hashlib
import json
import random
from copy import deepcopy
from pathlib import Path

root = Path(__file__).resolve().parents[1]
out_path = root / "output/proposal-delivery/HUMAN_REVIEW_MASTER_2026-10-28.json"
evidence_catalog = {}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def add_evidence(value):
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except (json.JSONDecodeError, TypeError):
            value = {"text": value}
    digest = hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()[:16]
    evidence_id = f"E-{digest}"
    evidence_catalog.setdefault(evidence_id, value)
    return evidence_id


def parse_jsonish(value):
    if not value:
        return None
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return value


def csv_rows(relative_path):
    with (root / relative_path).open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def c_packet_item(row, prefix, evidence_column):
    evidence = parse_jsonish(row.get(evidence_column, ""))
    evidence_refs = [add_evidence(evidence)] if evidence else []
    return {
        "item_id": row.get("blind_item_id", ""),
        "question": row.get("question", ""),
        "reference_answer": row.get("benchmark_reference_answer", ""),
        "target_response": row.get("target_response", ""),
        "evidence_refs": evidence_refs,
        "review": {"answer_judgment": None, "rationale": ""},
    }


def load_c_csv_queue(queue_id, title, relative_path, note):
    rows = csv_rows(relative_path)
    items = [c_packet_item(row, queue_id, "source_evidence") for row in rows]
    return {
        "queue_id": queue_id,
        "title": title,
        "status": "待人工审核",
        "review_count": len(items),
        "review_instruction": "对照给定来源和参考答案，填写 answer_judgment 为 Pass、Fail 或 Uncertain，并用 rationale 说明依据。不要推断实验条件或自动评分结果。",
        "scope_note": note,
        "source_packet": relative_path,
        "label_choices": ["Pass", "Fail", "Uncertain"],
        "items": items,
    }


def current_repair_queue():
    relative = "output/proposal-delivery/live-current-source-repair-2026-10-28/human-review/blind-review.csv"
    rows = csv_rows(relative)
    items = []
    for row in rows:
        evidence = parse_jsonish(row.get("source_evidence_json", ""))
        items.append({
            "item_id": row["review_id"],
            "dimension": row["dimension"],
            "question": row["question"],
            "expected_behaviour": row["expected_behaviour"],
            "target_response": row["target_answer"],
            "evidence_refs": [add_evidence(evidence)] if evidence else [],
            "review": {
                "question_validity": None,
                "answer_verdict": None,
                "failure_type": None,
                "critical_error": None,
                "supporting_source_message_ids": [],
                "rationale": "",
            },
        })
    return {
        "queue_id": "current_source_repair_24",
        "title": "当前版本导师修复实验（24 条答案）",
        "status": "待人工审核",
        "review_count": len(items),
        "review_instruction": "先判断问题和预期行为是否有来源支持，再判答案 Pass、Fail 或 Uncertain。失败时仅在证据支持时填写类型，并列出来源消息 ID。",
        "scope_note": "同一合成历史、每种条件一次运行；团队已看过结果。人工回看可用于纠错，不作为未曝光的独立盲审。",
        "source_packet": relative,
        "items": items,
    }


def current_comparison_queue():
    relative = "output/proposal-delivery/live-presentation-demo-current-source-2026-10-28/human-review/blind-review.csv"
    rows = csv_rows(relative)
    items = []
    for row in rows:
        evidence = parse_jsonish(row.get("source_evidence_json", ""))
        items.append({
            "item_id": row["review_id"],
            "dimension": row["dimension"],
            "question": row["question"],
            "expected_behaviour": row["expected_behavior"],
            "target_response": row["target_answer"],
            "evidence_refs": [add_evidence(evidence)] if evidence else [],
            "review": {
                "answer_verdict": None,
                "failure_type": None,
                "critical_error": None,
                "supporting_source_message_ids": [],
                "rationale": "",
            },
        })
    return {
        "queue_id": "current_source_six_run_48",
        "title": "当前版本六次运行比较（48 条答案）",
        "status": "待人工审核",
        "review_count": len(items),
        "review_instruction": "只依据所给来源和预期行为标记 Pass、Fail 或 Uncertain；若失败，引用来源消息 ID。",
        "scope_note": "同一合成历史的六次运行；自动结果和聚合结果已被项目成员看过。人工回看不构成独立盲审。",
        "source_packet": relative,
        "items": items,
    }


def earlier_repair_queue():
    relative = "output/proposal-delivery/live-repair-loop-2026-10-28/blind-review.csv"
    rows = csv_rows(relative)
    items = []
    for row in rows:
        evidence = {
            "source_statements": row.get("source_statements", ""),
            "confirmed_evidence": row.get("confirmed_evidence", ""),
        }
        items.append({
            "item_id": row["review_item"],
            "case_code": row["case_code"],
            "dimension": row["dimension"],
            "question": row["test_prompt"],
            "expected_behaviour": row["expected_behavior"],
            "target_response": row["target_answer"],
            "evidence_refs": [add_evidence(evidence)],
            "review": {
                "question_validity": None,
                "answer_correctness": None,
                "failure_category": None,
                "supporting_source_ids": [],
                "rationale": "",
            },
        })
    return {
        "queue_id": "earlier_repair_loop_36",
        "title": "较早版本修复循环（36 条答案）",
        "status": "待人工审核",
        "review_count": len(items),
        "review_instruction": "对每项分别判断问题有效性、答案正确性；失败时只在证据支持时标注失败类别。",
        "scope_note": "这是较早代码版本的合成案例，和当前版本 tutor loop 分开记录。",
        "source_packet": relative,
        "items": items,
    }


def formal_ab_queue():
    folder = root / "artifacts/local/phase4-formal-review-20261027/reviewer-1"
    material_path = folder / "material.json"
    template_path = folder / "blank-result.json"
    material = json.loads(material_path.read_text(encoding="utf-8"))
    blank = json.loads(template_path.read_text(encoding="utf-8"))
    items = []
    for item_id, item in material["items"].items():
        task = deepcopy(item)
        # Keep the first-pass response review free of the stored proposed defect mapping.
        if task.get("kind") == "response":
            task.pop("defects", None)
        review = deepcopy(blank["labels"][item_id])
        review.setdefault("note", "")
        items.append({"item_id": item_id, "task": task, "review": review})
    unresolved_count = len(json.loads((root / "output/proposal-evaluation/phase4-review-recheck-2026-10-28.json").read_text(encoding="utf-8"))["unresolved_item_ids"])
    return {
        "queue_id": "proposal_ab_formal_review_216",
        "title": "Proposal A/B 综合来源审核（216 项）",
        "status": "待人工审核",
        "review_count": len(items),
        "review_instruction": "依据队列中的 source_histories 检查每项。question 判断 valid/invalid/uncertain；response 判断 pass/fail/uncertain、失败维度和关键错误；candidate 判断事实是否有来源支持；reference 判断覆盖完整性；relationship 判断关系类型。保留无法确定的项目。",
        "scope_note": "包含 48 个问题、108 条 A/B 答案、27 个记忆候选、24 个参考事实单元和 9 个关系对。之前回看仍有 32 个未解决项（含在这 216 项中，不另重复计数）；A/B 旧回传有 AI 协助或结果曝光，不能当独立金标准。",
        "source_material_sha256": hashlib.sha256(material_path.read_bytes()).hexdigest(),
        "source_histories": material["histories"],
        "reference_unit_definition": material.get("reference_unit_definition"),
        "relationship_unit_definition": material.get("relationship_unit_definition"),
        "critical_error_definition": material.get("critical_error_definition"),
        "previous_review_open_item_count": unresolved_count,
        "items": items,
    }


def v5_c_queue():
    relative = "artifacts/local/phase4-c-openrouter-20261027-v5"
    run = json.loads((root / relative / "C-live.json").read_text(encoding="utf-8"))
    subset = json.loads((root / relative / "longmemeval-subset.json").read_text(encoding="utf-8"))
    items = []
    for receipt in run["target_receipts"]:
        case_index = int(receipt["case_index"]) - 1
        case = subset[case_index]
        evidence = {
            "question_date": case.get("question_date"),
            "haystack_dates": case.get("haystack_dates"),
            "haystack_session_ids": case.get("haystack_session_ids"),
            "haystack_sessions": case.get("haystack_sessions"),
            "answer_session_ids": case.get("answer_session_ids"),
        }
        response = receipt.get("response", {}).get("response_text", "")
        blind_hash = hashlib.sha256((receipt["response"]["response_id"] + "|phase4-c-v5").encode()).hexdigest()[:10].upper()
        items.append({
            "item_id": f"V5-{blind_hash}",
            "question_type": case.get("question_type"),
            "question": case.get("question", ""),
            "reference_answer": case.get("answer", ""),
            "target_response": response,
            "evidence_refs": [add_evidence(evidence)],
            "review": {"answer_judgment": None, "rationale": ""},
        })
    items.sort(key=lambda x: x["item_id"])
    return {
        "queue_id": "proposal_c_v5_review_84",
        "title": "Proposal C v5 LongMemEval 对照回看（84 条答案）",
        "status": "待人工审核",
        "review_count": len(items),
        "review_instruction": "对照 LongMemEval 参考答案及 source_evidence，填写 Pass、Fail 或 Uncertain，并写明理由。每个问题重复出现，请逐条独立判定，不推断策略或重复轮次。",
        "scope_note": "14 个问题各出现 6 次。此队列由保存的 v5 原始运行重新整理；隐藏了策略、重复轮次、运行 ID 和自动判分。",
        "source_material": f"{relative}/C-live.json + {relative}/longmemeval-subset.json",
        "label_choices": ["Pass", "Fail", "Uncertain"],
        "items": items,
    }


def intake_queue():
    data = json.loads(Path("/private/tmp/intake-candidates.json").read_text(encoding="utf-8"))
    items = []
    for row in data["candidates"]:
        refs = [add_evidence({"source_message_id": ev["source_message_id"], "role": ev["role"], "text": ev["text"], "timestamp": ev.get("timestamp")}) for ev in row.get("source_evidence", [])]
        proposed_relationships = [
            {key: value for key, value in rel.items() if key != "confidence"}
            for rel in row.get("relationships", [])
        ]
        items.append({
            "candidate_id": row["candidate_id"],
            "proposed_memory": row["text"],
            "source_message_ids": row["source_message_ids"],
            "proposed_relationships": proposed_relationships,
            "evidence_refs": refs,
            "review": {
                "decision": None,
                "corrected_memory": None,
                "confirmed_source_message_ids": [],
                "relationship_review": [
                    {"relationship_id": rel.get("relationship_id"), "decision": None, "corrected_type": None, "supporting_source_message_ids": [], "rationale": ""}
                    for rel in proposed_relationships
                ],
                "rationale": "",
            },
        })
    return {
        "queue_id": "current_source_intake_candidates_14",
        "title": "当前版本新建审计：14 条记忆候选",
        "status": "待人工审核",
        "review_count": len(items),
        "review_instruction": "逐条核对引用原文，选择 accept、edit、reject 或 uncertain。修改时填写 corrected_memory；并分别复核 proposed_relationships 的类型、方向与证据，写入对应 relationship_review。不要只根据模型建议确认。",
        "scope_note": "这 14 条来自独立的合成 intake retest；当前均未确认，没有目标模型测试结果。AI 的 advisory finding 不放入首轮材料，避免提示答案。",
        "source_material": "output/proposal-delivery/live-extraction-retest-2026-10-28/receipt-summary.json and local application conversation C117E268554B14881AD475D5028206658",
        "decision_choices": ["accept", "edit", "reject", "uncertain"],
        "items": items,
    }


queues = [
    formal_ab_queue(),
    load_c_csv_queue(
        "proposal_c_archived_review_84",
        "Proposal C archived LongMemEval（84 条答案）",
        "output/proposal-delivery/phase4-c-review-2026-10-28/blind-review.csv",
        "14 个问题各出现 6 次。保存结果供来源核对，不用于宣称完整基准成绩或独立 Auditor 有效性。",
    ),
    v5_c_queue(),
    load_c_csv_queue(
        "proposal_c_v6_review_180",
        "Proposal C v6 扩展集（180 条答案）",
        "output/proposal-delivery/phase4-c-v6-human-review/blind-review.csv",
        "30 个问题各出现 6 次；重复答案来自同一批 30 段历史，不能当作 180 个独立案例。",
    ),
    current_repair_queue(),
    current_comparison_queue(),
    earlier_repair_queue(),
    intake_queue(),
]

counts = {queue["queue_id"]: queue["review_count"] for queue in queues}
total_review_items = sum(counts.values())

master = {
    "format": "AI-Memory-Health-Auditor-Human-Review-Master-v1",
    "title_zh": "AI Memory Health Auditor 人工审核总文件",
    "generated_date": "2026-10-28",
    "language": "zh-CN instructions; source questions and answers retain their original language",
    "read_me_zh": [
        "本文件汇总当前已准备的所有未完成来源标注：Proposal A/B、归档 C、C v5、C v6、两组当前版本实验、较早修复实验，以及 14 条 intake 记忆候选。",
        "请只填写每项的 review 对象；不要删除 item_id、source_histories 或 evidence_refs。evidence_refs 指向本文件末尾 evidence_catalog 中的原始证据。",
        "选 Uncertain/uncertain 是有效审核结果，不要为了完成率强行判定。答案判定、问题有效性、记忆有效性和关系分类是不同任务，请按 queue 的说明分别填写。",
        "项目已有自动分数和汇总结果曝光记录。你完成的审核可用于来源纠错和人工复核，但若已看过这些结果，不可报告为未曝光的独立盲审或独立金标准。正式效度仍需符合独立审核与双人重叠审核要求。",
        "留空的人工确认项不是默认通过。许可证、同意、云处理许可、成员贡献和新手观察只能由实际责任人根据真实记录填写。",
    ],
    "reviewer_declaration": {
        "reviewer_label": None,
        "completed_at": None,
        "used_ai_assistance": None,
        "has_seen_automated_or_aggregate_results": None,
        "completed_independently": None,
        "note": "请据实填写。根据项目记录，自动与聚合结果曾对团队公开；如果审核者已看过，exposure 应填 true。",
    },
    "summary": {
        "total_item_records_for_review": total_review_items,
        "counts_by_queue": counts,
        "evidence_catalog_entries": len(evidence_catalog),
        "formal_ab_prior_recheck_open_items": 32,
        "formal_ab_prior_unresolved_summary": {
            "A_question_validity_uncertain": "13 of 48",
            "A_response_labels_unresolved": "6 of 36",
            "A_failure_category_mappings_disputed": 2,
            "memory_reference_unit_recall": None,
        },
        "important_scope_note": "32 个先前未解决的 A/B 标注已包含在 216 项队列内，不重复计数。其他队列来自独立实验/版本，不能合并分母或直接汇总为一个准确率。",
    },
    "label_definitions_zh": {
        "answer_judgment": {"Pass": "答案实质正确，且对可回答/不可回答问题的处理恰当。", "Fail": "答案实质错误、无来源支持，或在来源无答案时没有适当弃答。", "Uncertain": "来源或参考答案不足以作出可靠判断。"},
        "question_validity": {"valid": "问题与参考行为有来源支持，范围清楚且可评估。", "invalid": "问题或预期行为与来源不符、超范围或不可判定。", "uncertain": "现有来源不足以确定。"},
        "intake_decision": {"accept": "候选事实被原始来源完整支持。", "edit": "部分支持；修改后只保留可追溯内容。", "reject": "来源不支持或候选混合了不相干事实。", "uncertain": "需要更多来源或人工澄清。"},
        "critical_error": "仅当答案可能实质性误导或伤害用户时填写 true；证据不足时留 null。",
    },
    "queues": queues,
    "evidence_catalog": dict(sorted(evidence_catalog.items())),
    "manual_confirmations_zh": [
        {
            "confirmation_id": "source_permission_and_release",
            "prompt": "团队确认用于最终报告/演示的确切数据版本、许可证/同意范围、研究用途、服务器存储与适用的云处理权限，并记录证据。",
            "review": {"dataset_or_release_id": None, "research_use_permitted": None, "storage_permitted": None, "cloud_processing_authorised": None, "permission_reference": None, "reviewer_label": None, "reviewed_at": None, "notes": ""},
        },
        {
            "confirmation_id": "member_contributions",
            "prompt": "每位组员独立确认自己实际完成的工作和对应证据；计划分工不能替代完成记录。",
            "members": [{"member_slot": f"member_{i}", "actual_contributions": [], "evidence_references": [], "confirmed": None, "confirmed_at": None} for i in range(1, 5)],
        },
        {
            "confirmation_id": "novice_observations",
            "prompt": "若要支持可用性主张，记录真实新手操作观察，包括完成情况、困难、失败或放弃步骤；不得根据模拟或回忆补造观察。",
            "observations": [{"participant_code": None, "task": None, "outcome": None, "difficulties": [], "unsuccessful_steps": [], "consent_record": None, "observed_at": None, "notes": ""}],
        },
        {
            "confirmation_id": "proposal_b_threshold_freeze",
            "prompt": "Phase 4 B 记录的成功阈值为空。先完成合格试点和来源标注，再在任何新 held-out 结果产生/查看之前冻结阈值、协议和数据分割；不要回填已看过的结果。",
            "review": {"thresholds": None, "protocol_version": None, "development_split_fingerprint": None, "frozen_at": None, "reviewer_label": None, "notes": ""},
        },
    ],
    "source_files_preserved": [
        "artifacts/local/phase4-formal-review-20261027/reviewer-1/material.json",
        "output/proposal-delivery/phase4-c-review-2026-10-28/blind-review.csv",
        "output/proposal-delivery/phase4-c-v6-human-review/blind-review.csv",
        "output/proposal-delivery/live-current-source-repair-2026-10-28/human-review/blind-review.csv",
        "output/proposal-delivery/live-presentation-demo-current-source-2026-10-28/human-review/blind-review.csv",
        "output/proposal-delivery/live-repair-loop-2026-10-28/blind-review.csv",
        "artifacts/local/phase4-c-openrouter-20261027-v5/C-live.json",
        "artifacts/local/phase4-c-openrouter-20261027-v5/longmemeval-subset.json",
    ],
}

out_path.parent.mkdir(parents=True, exist_ok=True)
out_path.write_text(json.dumps(master, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"path": str(out_path), "bytes": out_path.stat().st_size, "review_items": total_review_items, "evidence_entries": len(evidence_catalog), "queue_counts": counts}, ensure_ascii=False, indent=2))
