import fs from 'node:fs/promises';
import path from 'node:path';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';

const workspace = '/Users/y/Documents/26-S2/5623/AI Memory Health Auditor';
const source = path.join(workspace, 'output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v18.pptx');
const buildDir = path.join(workspace, '.presentation-validation/v19-build');
const candidate = path.join(buildDir, 'candidate.pptx');
const deck = await PresentationFile.importPptx(await FileBlob.load(source));

function replaceText(id, expected, replacement) {
  const target = deck.resolve(id);
  if (!target?.text) throw new Error(`Missing text object ${id}`);
  target.text.replace(expected, replacement);
}

function setFontSize(id, size) {
  const target = deck.resolve(id);
  if (!target?.text) throw new Error(`Missing text object ${id}`);
  target.text.fontSize = size;
}

function setNotes(id, text) {
  const target = deck.resolve(id);
  if (!target || !('text' in target)) throw new Error(`Missing notes object ${id}`);
  target.text = text;
}

async function renderSlides(directory) {
  await fs.mkdir(directory, { recursive: true });
  for (let i = 0; i < deck.slides.items.length; i++) {
    const slide = deck.slides.items[i];
    const png = await deck.export({ slide, format: 'png', scale: 1 });
    const name = `slide-${String(i + 1).padStart(2, '0')}.png`;
    await fs.writeFile(path.join(directory, name), new Uint8Array(await png.arrayBuffer()));
  }
  const montage = await deck.export({ format: 'webp', montage: true, scale: 0.45 });
  await fs.writeFile(path.join(directory, 'montage.webp'), new Uint8Array(await montage.arrayBuffer()));
}

const before = await deck.inspect({ kind: 'slide,textbox,notes', maxChars: 1000000 });
await fs.writeFile(path.join(buildDir, 'inspect-before.ndjson'), before.ndjson);
await renderSlides(path.join(buildDir, 'render-before'));

// Compact chart labels use the same policy names as the app, with smaller type where required.
replaceText('sh/w32twb6l', 'Rule-based', 'Relationship-priority');
setFontSize('sh/w32twb6l', 18);
replaceText('sh/j6dcr65c', 'Rule-based by repeat', 'Relationship-priority by repeat');
setFontSize('sh/j6dcr65c', 14);
replaceText('sh/a9ojq5kz', 'Rule-based', 'Relationship-priority');
setFontSize('sh/a9ojq5kz', 17);

// Expanded C uses the full canonical policy names on the chart and result callout.
replaceText('sh/98rehwve', 'Contextual rule-based retrieval', 'Relationship-priority retrieval');
setFontSize('sh/98rehwve', 18);
replaceText('sh/zipwbmdc', 'Contextual rule-based 61/90 vs First-match 19/90 · +46.7 percentage points', 'Relationship-priority retrieval 61/90 vs First-match retrieval 19/90 · +46.7 pp');
setFontSize('sh/zipwbmdc', 22);
replaceText('sh/kfixwbe1', 'Gaps: both policies scored 0/15 on multi-session; contextual rule-based scored 5/15 (33%) on temporal reasoning. Mean latency was 6.80s vs 4.04s; contextual rule-based used 2.3× input tokens.\nEstimated total cost US$0.178; 180/180 usable grades. Human review pending; target and grader share the GPT-6 Luna family. This is not a full benchmark score or Auditor accuracy claim.', 'Gaps: both policies scored 0/15 on multi-session; Relationship-priority scored 5/15 (33%) on temporal reasoning. Mean latency was 6.80s vs 4.04s; Relationship-priority used 2.3× First-match input tokens.\nEstimated total cost US$0.178; 180/180 usable grades. Human review pending; target and grader share the GPT-6 Luna family. This is not a full benchmark score or Auditor accuracy claim.');
setFontSize('sh/kfixwbe1', 16);

replaceText('sh/0nap8f6l', 'Separate 6-run check: contextual rule-based passed 15/24 vs first-match 3/24; automatic scores, one history, no human gold.', '6 runs: Relationship-priority 15/24 vs First-match 3/24 · automatic grades, one history, no human gold.');

const noteIds = ['nt/jyx0ra1s', 'nt/x8f69ofe', 'nt/gnmp4jqx', 'nt/fu1gfa1s', 'nt/jetc3ut0', 'nt/8f2psfyx'];
const notes = await deck.inspect({ kind: 'notes', maxChars: 1000000 });
const noteById = new Map(notes.ndjson.trim().split('\n').map(line => JSON.parse(line)).map(note => [note.id, note.text]));
for (const id of noteIds) {
  const text = noteById.get(id);
  if (typeof text !== 'string') throw new Error(`Missing speaker notes ${id}`);
  const updated = text
    .replaceAll('Contextual rule-based', 'Relationship-priority')
    .replaceAll('contextual rule-based', 'relationship-priority')
    .replaceAll('contextual-rule-based', 'relationship-priority');
  if (updated === text) throw new Error(`Expected strategy label was not present in notes ${id}`);
  setNotes(id, updated);
}

await renderSlides(path.join(buildDir, 'render-after'));
const inspection = await deck.inspect({ kind: 'slide,textbox,notes', maxChars: 1000000 });
await fs.writeFile(path.join(buildDir, 'inspect-after.ndjson'), inspection.ndjson);
const pptx = await PresentationFile.exportPptx(deck);
await pptx.save(candidate);
console.log(`Exported ${deck.slides.items.length} slides to ${candidate}`);
