import fs from 'node:fs/promises';
import path from 'node:path';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';

const workspace = '/Users/y/Documents/26-S2/5623/AI Memory Health Auditor';
const finalPath = path.join(workspace, 'output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v19.pptx');
const renderDir = path.join(workspace, '.presentation-validation/v19-build/render-final');
const deck = await PresentationFile.importPptx(await FileBlob.load(finalPath));
const inspection = await deck.inspect({ kind: 'slide,textbox,notes', maxChars: 1000000 });
await fs.mkdir(renderDir, { recursive: true });
await fs.writeFile(path.join(renderDir, 'inspect.ndjson'), inspection.ndjson);
for (let i = 0; i < deck.slides.items.length; i++) {
  const slide = deck.slides.items[i];
  const png = await deck.export({ slide, format: 'png', scale: 1 });
  await fs.writeFile(path.join(renderDir, `slide-${String(i + 1).padStart(2, '0')}.png`), new Uint8Array(await png.arrayBuffer()));
}
const montage = await deck.export({ format: 'webp', montage: true, scale: 0.45 });
await fs.writeFile(path.join(renderDir, 'montage.webp'), new Uint8Array(await montage.arrayBuffer()));
const raw = inspection.ndjson;
const result = {
  slides: deck.slides.items.length,
  oldStrategyLabels: [...raw.matchAll(/contextual[- ]rule-based|rule-based by repeat|\bRule-based\b/g)].map(match => match[0]),
  canonicalNamesPresent: raw.includes('First-match retrieval') && raw.includes('Relationship-priority retrieval'),
  speakers: [...new Set([...raw.matchAll(/Speaker [1-4]/g)].map(match => match[0]))],
  speakerNoteCount: (raw.match(/"kind":"notes"/g) || []).length,
  output: finalPath,
};
if (result.slides !== 12 || result.oldStrategyLabels.length || !result.canonicalNamesPresent || result.speakerNoteCount !== 12 || result.speakers.length !== 4) {
  throw new Error(`Final presentation verification failed: ${JSON.stringify(result)}`);
}
console.log(JSON.stringify(result, null, 2));
