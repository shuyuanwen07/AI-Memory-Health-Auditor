import fs from "node:fs/promises";
import { FileBlob, PresentationFile } from "@oai/artifact-tool";

const input = "../output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final.pptx";
const output = "../output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v14.pptx";
const noteText = JSON.parse(await fs.readFile("./speaker-notes-v14.json", "utf8"));
const presentation = await PresentationFile.importPptx(await FileBlob.load(input));
if (presentation.slides.items.length !== 12) throw new Error(`Expected 12 slides, got ${presentation.slides.items.length}`);

presentation.resolve("sh/sryl4zqx").text = "Speaker 1  →  Speaker 2  →  Speaker 3  →  Speaker 4";
for (let index = 0; index < presentation.slides.items.length; index += 1) {
  const script = noteText[String(index + 1)];
  if (!script || !script.startsWith(`Speaker ${Math.floor(index / 3) + 1} | Slide ${index + 1}`)) {
    throw new Error(`Missing or incorrectly assigned script for slide ${index + 1}`);
  }
  presentation.slides.getItem(index).speakerNotes.text = script;
}

const blob = await PresentationFile.exportPptx(presentation);
await blob.save(output);

const renderDir = "./v14-final-render";
await fs.mkdir(renderDir, { recursive: true });
for (const [index, slide] of presentation.slides.items.entries()) {
  const png = await presentation.export({ slide, format: "png", scale: 1 });
  await fs.writeFile(`${renderDir}/slide-${index + 1}.png`, new Uint8Array(await png.arrayBuffer()));
}
const inspect = await presentation.inspect({ kind: "slide,notes", maxChars: 30000 });
await fs.writeFile(`${renderDir}/slides-and-notes.ndjson`, inspect.ndjson);
const notes = presentation.slides.items.map((slide, index) => ({
  slide: index + 1,
  speaker: `Speaker ${Math.floor(index / 3) + 1}`,
  noteLength: slide.speakerNotes.text.length,
  containsAssignedName: /Shuyuan Wen|Chongtai Jia|Chayapat Leardngammongkul|Yichao Wang/.test(slide.speakerNotes.text),
  containsScript: slide.speakerNotes.text.includes("Slide "),
}));
console.log(JSON.stringify({ output, slideCount: presentation.slides.items.length, notes }, null, 2));
