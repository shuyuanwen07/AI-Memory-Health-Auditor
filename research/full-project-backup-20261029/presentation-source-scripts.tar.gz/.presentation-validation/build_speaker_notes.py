import json
import re
from pathlib import Path

from docx import Document

root = Path(__file__).resolve().parents[1]
docx_path = root / "output/presentation/ELEC5623_AI_Memory_Health_Auditor_Four_Speaker_Script.docx"
inspect_path = root / ".presentation-validation/v13-final-render/slides-and-notes.ndjson"
output_path = root / ".presentation-validation/speaker-notes-v14.json"

paragraphs = [p.text.strip() for p in Document(docx_path).paragraphs if p.text.strip()]
speaker = None
segment = None
scripts = {}

for paragraph in paragraphs:
    header = re.match(r"Speaker\s+(\d+)\s+—\s+[^|]+\|\s*(.*)$", paragraph)
    if header:
        speaker = int(header.group(1))
        continue
    schedule = re.match(r"Slides\s+(\d+)–(\d+)\s*\|\s*Target:\s*([^|]+)\|\s*(.*)$", paragraph)
    if schedule:
        segment = {
            "start": int(schedule.group(1)),
            "end": int(schedule.group(2)),
            "target": schedule.group(3).strip(),
            "handoff": schedule.group(4).strip(),
        }
        continue
    slide = re.match(r"Slide\s+(\d+)\s*\|\s*(.*?)\s{2,}(.*)$", paragraph)
    if slide:
        number = int(slide.group(1))
        speech = slide.group(3).strip()
        speech = speech.replace("Chongtai", "Speaker 2").replace("Chayapat", "Speaker 3")
        scripts[number] = {
            "speaker": speaker,
            "title": slide.group(2).strip(),
            "speech": speech,
            "segment": segment,
        }

if set(scripts) != set(range(1, 13)):
    raise SystemExit(f"Expected 12 slide scripts, found: {sorted(scripts)}")

old_notes = {}
for line in inspect_path.read_text().splitlines():
    row = json.loads(line)
    if row.get("kind") == "notes":
        old_notes[int(row["slideIndex"]) + 1] = row.get("text", "")

result = {}
for number, item in scripts.items():
    segment_info = item["segment"] or {}
    notes = [f"Speaker {item['speaker']} | Slide {number} — {item['title']}"]
    if segment_info.get("start") == number:
        notes.append(f"Segment timing: {segment_info['target']}")
    notes.extend(["", item["speech"]])
    if segment_info.get("end") == number:
        handoff = segment_info.get("handoff", "")
        if handoff.startswith("Handoff:"):
            notes.extend(["", handoff.replace("Handoff:", "Handoff:", 1)])
        elif "Close" in handoff:
            notes.extend(["", "Close the presentation."])

    references = []
    for line in old_notes.get(number, "").splitlines():
        line = line.strip()
        if line.startswith(("Source:", "Sources:", "Live group:", "Like-for-like compare:")):
            references.append(line)
    if references:
        notes.extend(["", "Presenter references / live evidence:", *references])
    result[str(number)] = "\n".join(notes)

output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(f"Wrote {len(result)} speaker-note scripts to {output_path}")
