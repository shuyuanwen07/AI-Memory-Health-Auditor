import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { finalizePresentation } from '/Users/y/.codex/plugins/cache/openai-primary-runtime/presentations/26.1020.11618/skills/presentations/container_tools/artifact_tool_utils.mjs';

const workspaceDir = '/Users/y/Documents/26-S2/5623/AI Memory Health Auditor';
const skillDir = '/Users/y/.codex/plugins/cache/openai-primary-runtime/presentations/26.1020.11618/skills/presentations';
const candidatePath = path.join(workspaceDir, '.presentation-validation/v15-build/candidate.pptx');
const finalPath = path.join(workspaceDir, 'output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v15.pptx');
const stagingDir = path.join(workspaceDir, '.presentation-validation/v15-build/finalizer');
await fs.mkdir(stagingDir, {recursive:true});
const result = await finalizePresentation({
  workspaceDir,
  candidatePath,
  finalPath,
  pythonExecutable: '/Users/y/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3',
  integrityValidatorPath: path.join(skillDir, 'container_tools/inspect_presentation_package_integrity.py'),
  layoutValidatorPath: path.join(skillDir, 'container_tools/inspect_presentation_layout_geometry.py'),
  layoutArgs: ['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit'],
  explicitTotalSlideCount: 12,
  requiredNativeTableOwnerSlides: [],
  requiredNativeChartOwnerSlides: [],
  fontPolicy: {basis:'reference',families:['Arial'],referencePath:path.join(workspaceDir,'output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final.pptx'),referenceSha256:'6afa8f327f83b94f48082eebb50a92e257f10d195b2adf6ae1679475a7c55c93'},
  verifyArtifactToolImport: true,
  receiptPath: path.join(stagingDir, 'v15-validation.json'),
});
console.log(JSON.stringify(result, null, 2));
