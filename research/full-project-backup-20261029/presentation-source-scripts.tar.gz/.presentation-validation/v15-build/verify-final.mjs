import fs from 'node:fs/promises';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';
const input = '/Users/y/Documents/26-S2/5623/AI Memory Health Auditor/output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final.pptx';
const out = '/private/tmp/mha-v15-preview/final';
await fs.mkdir(out, {recursive:true});
const presentation = await PresentationFile.importPptx(await FileBlob.load(input));
const inspection = await presentation.inspect({kind:'slide,textbox,shape,image,table,chart,notes,layout', maxChars:1000000});
await fs.writeFile(`${out}/inspect.ndjson`, inspection.ndjson);
for (let i = 0; i < presentation.slides.items.length; i++) {
  const slide = presentation.slides.items[i];
  const png = await presentation.export({slide, format:'png', scale:1});
  await fs.writeFile(`${out}/slide-${String(i+1).padStart(2,'0')}.png`, new Uint8Array(await png.arrayBuffer()));
}
const montage = await presentation.export({format:'webp', montage:true, scale:0.5});
await fs.writeFile(`${out}/montage.webp`, new Uint8Array(await montage.arrayBuffer()));
console.log(`Final render complete: ${presentation.slides.items.length} slides.`);
