import fs from 'node:fs/promises';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';

const input = '/Users/y/Documents/26-S2/5623/AI Memory Health Auditor/output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final.pptx';
const draft = '/Users/y/Documents/26-S2/5623/AI Memory Health Auditor/.presentation-validation/v15-build/candidate.pptx';
const previewDir = '/private/tmp/mha-v15-preview/after';
const presentation = await PresentationFile.importPptx(await FileBlob.load(input));

function replaceText(id, expected, replacement) {
  const target = presentation.resolve(id);
  if (!target?.text) throw new Error(`Missing text object ${id}`);
  target.text.replace(expected, replacement);
}
function setNotes(id, value) {
  const target = presentation.resolve(id);
  if (!target || !('text' in target)) throw new Error(`Missing notes object ${id}`);
  target.text = value;
}

replaceText('sh/7qp4be9c', 'Can an audit find a memory failure, support a repair,\nand show what changed?', 'Can ground-truth-driven contextual tests find\nmore failures than direct and fixed-template tests?');
replaceText('sh/1cj2d8b6', 'Proposal experiments test different parts of the claim', 'Three experiments assess the Auditor');
replaceText('sh/kbm987y5', 'Can methods expose memory defects?', 'Which method detects more memory failures?');
replaceText('sh/a5kr2xg3', 'Does the stronger memory score higher?', 'Can the Auditor distinguish Weak and Strong?');
replaceText('sh/3ytsrmpw', 'Does the ranking hold on new histories?', 'Does LongMemEval agree on the ranking?');
replaceText('sh/qlcjipgn', 'Same model/history, frozen 8 tests and prompt settings; three arms.', 'Same API model and history; only target retrieval changed; same 8 tests.');

replaceText('sh/1gbm9s3a', 'Current-source Weak/Strong comparison', 'Research conclusion: Auditor efficacy remains unconfirmed');
replaceText('sh/sb2lcnmd', 'Weak: 3 pass · 16 fail · 5 uncertain (24 answers)', 'A: 27/27 decided failures detected; formal method comparison remains unresolved.');
replaceText('sh/a543mx4r', 'Strong: 15 pass · 4 fail · 5 uncertain (24 answers)', 'B/C: Strong > Weak in target-memory tests; this is not Auditor accuracy.');
replaceText('sh/xw3q94ne', '6 runs; Strong ranked higher in all 3 pairs; ratings are automatic.', 'Independent held-out labels and frozen thresholds are still needed.');
replaceText('sh/mps7a5or', 'Memory review', 'Auditor reliability');
replaceText('sh/nq1o3a5w', 'http://localhost:5173/new-audit', 'http://localhost:5173/quality');
replaceText('sh/0nap8f6l', 'Verifier PASS: 48 exact inputs; JSON/CSV reconcile; 0 failed requests. One synthetic history; repeats correlated; auto labels; no human gold.', 'Separate 6-run check: Strong passed 15/24 vs Weak 3/24; automatic scores, one history, no human gold.');

setNotes('nt/y90nupkv', `Speaker 1 | Slide 1 — Opening\nSegment timing: 2:30\n\nOur research asks whether ground-truth-driven contextual tests can find memory failures more effectively than direct questions and fixed templates under an equal test budget, while keeping false alarms within a pilot threshold. The target is a controlled memory-enabled AI: a fixed API model with a separate external memory layer. The Auditor evaluates that target; it does not modify the foundation model. The repair-and-retest loop later in the talk is an additional, limited demonstration.\n\nPresenter references / live evidence:\nSources: proposal §§2, 5.3, 7.2–7.5; docs/EXPERIMENT_REPORT_2026-10-28.md`);

setNotes('nt/jyx0ra1s', `Speaker 2 | Slide 4 — Experimental map\nSegment timing: 2:30\n\nThe primary question is whether personalised contextual and indirect tests detect more memory failures than direct questions and fixed templates, under equal test budgets and a pilot-defined false-positive threshold. Experiment A compares those test methods. Experiment B holds the API base model and test conditions fixed while comparing Weak and Strong external memory policies; it checks whether the Auditor can distinguish known target-memory conditions. Experiment C checks whether a compatible LongMemEval subset gives the same relative ranking. These answer different questions and use separate datasets and measures, so their scores are not pooled. The repair loop later is supplementary and is not the proposal's primary experiment.\n\nPresenter references / live evidence:\nSources: proposal §§5.3, 7.2–7.5; experiment report §5; LongMemEval, Wu et al. (2025), https://openreview.net/forum?id=pZiyCaVuti.`);

setNotes('nt/udsvah03', `Speaker 3 | Slide 9 — Diagnosis, repair and retest\n\nThis is a supplementary tutor-requested demonstration, separate from the proposal's main method-comparison question. The changed component is the target system's external retrieval policy; the Auditor and the API base model remain fixed. Baseline receipts omitted facts needed for the task. GPT-6 Luna suggested input delivery as a hypothesis, not a proven cause. With the same history, API model, settings and eight tests, the original and generic conditions each passed 1/8 with two uncertain; targeted retrieval passed 4/8 with one uncertain. Among six shared decided answers, two passed only under the target setting and none only under baseline; three failed in both. Accuracy and Freshness improved, while Appropriate Use and Conflict Resolution issues remain. Five labels need human review. One run per arm on one synthetic history is a useful demonstration, not a causal or general result.\n\nHandoff: Speaker 4\n\nPresenter references / live evidence:\nLive group: http://localhost:5173/experiments/EXP627CCD21BC1D465996A30FF0E630739B\nLike-for-like compare: http://localhost:5173/compare?before=RUN42167A38184D40EE8E7AD2A79C25E8DB&after=RUNBA08475F1AD241D883BC811BC85C7652\nSources: current-source experiment group and saved run receipts; diagnosis receipt for RUN062CE040377A4BDD92B9258647822B00.`);

setNotes('nt/8f2psfyx', `Speaker 4 | Slide 12 — Research conclusion and live evidence\n\nThe current evidence does not yet establish the primary Auditor claim. In A, 27 of 27 decided failure labels were detected, but six answers remain uncertain and formal method superiority and distinct-defect discovery are not measured. B and C show Strong scoring above Weak in these target-memory collections; those scores assess the target memory, not Auditor accuracy. Independent held-out human labels and a frozen threshold are still needed to validate the Auditor.\n\nThe separate current-source six-run comparison produced 48 saved answers and reconciled JSON/CSV records with no failed requests. Strong passed 15/24 and Weak 3/24, but this used one synthetic history and automatic labels without human gold. It supports execution and target-policy separation, not semantic validity. The repair demo on slide 9 is also exploratory.\n\nThe conclusion is therefore: the prototype can run and trace controlled memory comparisons, but the central research claim remains open pending independent blind review and a frozen held-out evaluation.\n\nClose the presentation.\n\nPresenter references / live evidence:\nCurrent-source group EXP77CB1B845E75465ABDF7C8FC986113E4; experiment report §§5–7; proposal §7.`);

await fs.mkdir(previewDir, {recursive:true});
for (let i = 0; i < presentation.slides.items.length; i++) {
  const slide = presentation.slides.items[i];
  const png = await presentation.export({slide, format:'png', scale:1});
  await fs.writeFile(`${previewDir}/slide-${String(i+1).padStart(2,'0')}.png`, new Uint8Array(await png.arrayBuffer()));
}
const montage = await presentation.export({format:'webp', montage:true, scale:0.5});
await fs.writeFile(`${previewDir}/montage.webp`, new Uint8Array(await montage.arrayBuffer()));
const pptx = await PresentationFile.exportPptx(presentation);
await pptx.save(draft);
console.log(`Exported draft with ${presentation.slides.items.length} slides.`);
