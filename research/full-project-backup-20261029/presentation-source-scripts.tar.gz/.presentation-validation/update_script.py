from docx import Document
from pathlib import Path

path = Path('output/presentation/ELEC5623_AI_Memory_Health_Auditor_Four_Speaker_Script.docx')
doc = Document(path)

replacements = {
    'Speaker 1 — The problem and the system': 'Speaker 1 — Shuyuan Wen | The problem and the system',
    'Speaker 2 — Proposal experiments A and B': 'Speaker 2 — Chongtai Jia | Proposal experiments A and B',
    'Speaker 3 - Experiment C and the tutor repair loop': 'Speaker 3 — Chayapat Leardngammongkolkul | Experiment C and the earlier tutor loop',
    'Speaker 4 — Auditor evidence, rubric, and conclusion': 'Speaker 4 — Yichao Wang | Auditor evidence, rubric, and conclusion',
}
for p in doc.paragraphs:
    if p.text in replacements:
        p.runs[0].text = replacements[p.text]

# The opening allocation follows the proposal's planned work areas; it does not certify completed individual work.
for p in doc.paragraphs:
    if p.text.startswith('Speaker 1–4 are placeholders'):
        p.runs[0].text = ('Suggested speaking order follows the proposal’s planned work areas. The member contribution form remains pending each person’s confirmation. '
                          'The script separates target-memory scores from Auditor reliability and identifies reviews still pending.')
        break

slides = {
    'Slide 1 | Opening': (
        'Our project asks whether an AI memory auditor can do more than score an answer. Can it find a concrete memory failure, show the evidence behind it, and help an operator test a repair? We built the AI Memory Health Auditor to investigate that question.'
    ),
    'Slide 2 | Why memory needs an audit': (
        'An answer can be fluent and still use incorrect, stale, conflicting, or out-of-scope memory. We test four abilities: accuracy, freshness, conflict resolution, and appropriate use. LongMemEval, LoCoMo, and BEAM provide memory tasks or benchmarks; Zep and Mem0 support evaluation on custom or user data. Our contribution is a prototype connecting operator-confirmed personal facts to contextual tests, evidence-based diagnosis, and traceable retesting. It builds on this related work rather than claiming that existing benchmarks or products cannot evaluate memory.'
    ),
    'Slide 3 | Workflow': (
        'The system separates the Auditor, the target AI, and the evaluator. An authorised conversation enters a source store. GPT-6 Luna proposes structured memory candidates with source links, and an operator confirms the reference facts. An LLM drafts contextual questions grounded in those facts. The target model answers under a scoped memory policy. The evaluator uses deterministic rules where criteria are stable and LLM assessment for open answers; disagreement can remain uncertain. React presents the audit, FastAPI orchestrates it, and PostgreSQL stores evidence and results. GenAI helps interpret varied dialogue, draft semantically varied questions, and assess open responses. The contribution is this traceable audit workflow, not a new foundation model. I’ll hand over to Chongtai to explain the proposal experiments.'
    ),
    'Slide 4 | Experimental map': (
        'The proposal separates three evaluations. A tests audit methods with three equal-budget arms. B compares Weak and Strong target memories. C checks whether a pinned external benchmark gives the same ranking. They use different cases and measures, so we report them separately. The current-source six-run Weak/Strong comparison on slide 12 is an additional, source-bound study; we do not pool it with A, B, or C.'
    ),
    'Slide 5 | Experiment A': (
        'Experiment A collected 36 target answers across three histories, three methods, and four questions per method and history. Retrospective reference review resolved 30 answers: 27 were labelled failures and three passes; six remained uncertain. Among those resolved items, the automatic failure detector caught all 27 reviewed failures. That is conditional on the resolved subset, not a formal defect-discovery rate. The distinct-defect rate remains unmeasured because question validity, response-to-defect mappings, and reviewer provenance are unresolved.'
    ),
    'Slide 6 | Experiment B': (
        'Experiment B used 72 canonical answers across three related synthetic histories, two memory policies, and three repeats. The rule-evaluator macro score was 25 percent for Weak and 97.22 percent for Strong. Strong scored 100, 100, and 91.67 percent across the repeats. These values describe target-memory performance in this collection; they are not Auditor accuracy. The histories are related, repeats are not independent, and review was retrospective. A frozen, independently labelled held-out validity result has not been established. Chayapat will show the external consistency check and the separate earlier-source tutor loop.'
    ),
    'Slide 7 | Experiment C': (
        'The archived LongMemEval compatibility run covered 14 of 500 Oracle cases and produced 84 answers across two policies and three repeats, scored with the pinned upstream prompt. Weak scored 15 of 42, or 35.7 percent; Strong scored 30 of 42, or 71.4 percent. Strong ranked higher in every repeat. Proposal B and this local C collection therefore agreed on ranking direction in all three repeats. This is a local consistency check, not a full benchmark result, and the absolute scores from B and C are not comparable.'
    ),
    'Slide 8 | The first policy comparison': (
        'In a separate earlier-source GPT-6 Luna UI study, the reference-reviewed score rose from three of twelve passes with first-match retrieval to nine of twelve after prioritising requirements and updates. Conflict resolution and appropriate use improved, while freshness remained zero of three. This gave us a concrete diagnosis target, but did not establish that an Auditor diagnosis caused the change. Treat it as historical evidence from an earlier source snapshot, separate from the current-source comparison on slide 12.'
    ),
    'Slide 9 | Diagnosis, repair, retest': (
        'For the tutor-requested loop, we inspected the saved baseline receipt before choosing a change. It included retired MySQL but omitted the current PostgreSQL update. We changed retrieval to match the task and project, then reused the same four frozen questions in three paired groups. Baseline and generic control each passed three of twelve answers. Targeted retrieval passed nine of nine decided answers, while three of twelve remained uncertain. This is repeated evidence from one synthetic history and an earlier source snapshot; repeats are correlated. It shows an evidence-guided repair and same-test retest, not general efficacy. Keep it separate from the current-source group on slide 12.'
    ),
    'Slide 10 | Auditor reliability': (
        'This earlier-source 24-answer Auditor check is separate from the current-source group on slide 12. Seventeen of 24 answers received decisive automated assessments, and all 17 agreed with saved references; seven were uncertain. Labels were Codex-assisted and saved after automated outputs were visible. This was one synthetic history with zero independent adjudications. The 9-of-12 failure-detection figure is a reference comparison, not independently validated recall. The useful product signal is that uncertainty remains visible for review.'
    ),
    'Slide 11 | Proposal and rubric status': (
        'The prototype and end-to-end workflow are implemented. Against the proposal criteria, AC1 is not established, AC2 partly evidenced, AC3 not achieved, AC4 partly verified, and AC5 partly evidenced. The current-source verifier checks exact inputs and export consistency; it does not establish answer correctness. A separate synthetic intake run produced 14 candidate memories and two advisory flags; all candidates await operator review, and no target tests ran. The 216-item A/B review return was AI-assisted and result-exposed, so it is not independent blind evidence. Relative strengths under the rubric are the usable prototype, justified GenAI architecture, Track B fit, and clear workflow; independent validity remains the main gap. The proposal planned Shuyuan Wen for extraction, ground truth, and database; Chongtai Jia for test generation and target connector; Chayapat Leardngammongkul for evaluation and metrics; and Yichao Wang for frontend, dashboard, and privacy controls. These are planned assignments, not verified completed contributions. Each member must confirm their actual work. The source archive is assembled, while release permissions and contribution confirmations remain pending.'
    ),
    'Slide 12 | Conclusion and live evidence': (
        'The latest current-source group, EXP77CB1B845E75465ABDF7C8FC986113E4, contains six runs over one frozen question bank: three Weak and three Strong. It produced 48 target answers and 48 automatic evaluations with zero failed requests. Weak had three passes, 16 failures, and five uncertain answers; Strong had 15 passes, four failures, and five uncertain. Strong ranked higher in all three paired repeats. The offline verifier passed six runs, 48 exact input checks, and JSON/CSV reconciliation. The result is bound to backend digest 7d303324… and question-set fingerprint 4bb4a2…. This confirms run and export integrity, not semantic correctness or independent Auditor validity. Ratings are automatic; one synthetic history is reused across correlated repeats, and there are no human-gold labels. The result supports feasibility and a local ranking, not a general claim. The earlier tutor loop on slide 9 is separate. Open Experiments to inspect this group. Thank you.'
    ),
}

found = set()
for p in doc.paragraphs:
    if p.runs and p.runs[0].text.startswith('Slide '):
        heading = p.runs[0].text.strip()
        heading = heading.rstrip()
        if heading in slides:
            if len(p.runs) < 2:
                raise RuntimeError(f'Expected heading/body runs for {heading}')
            p.runs[1].text = slides[heading]
            found.add(heading)
missing = set(slides) - found
if missing:
    raise RuntimeError(f'Missing expected script paragraphs: {sorted(missing)}')

doc.save(path)
print(f'Updated {path}; {len(slides)} slide scripts and four speaker headers.')
