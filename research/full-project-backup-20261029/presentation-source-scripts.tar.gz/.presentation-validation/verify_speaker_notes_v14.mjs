import fs from "node:fs/promises";
import { FileBlob, PresentationFile } from "@oai/artifact-tool";

const source = "../output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v14.pptx";
const expected = JSON.parse(await fs.readFile("./speaker-notes-v14.json", "utf8"));
const presentation = await PresentationFile.importPptx(await FileBlob.load(source));
if (presentation.slides.items.length !== 12) throw new Error("Slide count changed unexpectedly");
const namePattern = /Shuyuan Wen|Chongtai Jia|Chayapat Leardngammongkul|Yichao Wang/;
for (const [index, slide] of presentation.slides.items.entries()) {
  const number = index + 1;
  const notes = slide.speakerNotes.text;
  if (notes !== expected[String(number)]) throw new Error(`Speaker notes did not survive export on slide ${number}`);
  if (!notes.startsWith(`Speaker ${Math.floor(index / 3) + 1} | Slide ${number}`)) throw new Error(`Speaker assignment mismatch on slide ${number}`);
  if (namePattern.test(notes)) throw new Error(`Personal speaker name found in slide ${number} notes`);
}
const renderDir = "./v14-reimport-render";
await fs.mkdir(renderDir, { recursive: true });
for (const [index, slide] of presentation.slides.items.entries()) {
  const png = await presentation.export({ slide, format: "png", scale: 1 });
  await fs.writeFile(`${renderDir}/slide-${index + 1}.png`, new Uint8Array(await png.arrayBuffer()));
}
const inspect = await presentation.inspect({ kind: "slide,notes", maxChars: 30000 });
await fs.writeFile(`${renderDir}/slides-and-notes.ndjson`, inspect.ndjson);
console.log(JSON.stringify({
  slideCount: presentation.slides.items.length,
  notesVerified: 12,
  coverSequence: presentation.resolve("sh/sryl4zqx").text,
  noteLabels: presentation.slides.items.map((slide, index) => `Speaker ${Math.floor(index / 3) + 1}: ${slide.speakerNotes.text.length} chars`),
}, null, 2));
