import fs from "node:fs/promises";
import { FileBlob, PresentationFile } from "@oai/artifact-tool";

const source = "../output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v11.pptx";
const buildDir = "./v12-build";
await fs.mkdir(buildDir, { recursive: true });

const presentation = await PresentationFile.importPptx(await FileBlob.load(source));
const setText = (id, value) => { presentation.resolve(id).text = value; };
const setPosition = (id, position) => { presentation.resolve(id).position = position; };

// Bring the proposal overview up to date while keeping the archived C result separate.
setText("sh/h4fa9wfy", "LongMemEval extension");
setText("sh/p0batw72", "30 new v6 cases");
setText("sh/oz29krqh", "180 target answers + grades\n2 policies × 3 repeats");
setText("sh/3ytsrmpw", "Does the ranking hold on new histories?");
presentation.slides.getItem(3).speakerNotes.text = [
  "Speaker: Speaker 2",
  "Cue: Separate A, B and C before presenting their results. A asks whether the auditing methods expose defects. B compares the target memory policies. Archived C checks whether an external benchmark-compatible measure agrees on ranking. The new v6 C collection adds 30 held-out cases and does not replace the archived 14-case C or the separate v5 record.",
  "The expanded collection keeps the primary v6 decision separate from any combined summary because its cases were selected under a new frozen protocol and executed under a later source snapshot. The scores across A, B and C use different datasets and measures, so they are not pooled.",
  "Sources: experiment report §5; LongMemEval paper, Wu et al. (2025), https://openreview.net/forum?id=pZiyCaVuti.",
].join("\n\n");

// Keep the earlier GPT-4o C result distinct from the newer GPT-6 Luna expansion.
setText("sh/cb2tkvap", "Archived C · 14-case LongMemEval ranking");
presentation.slides.getItem(6).speakerNotes.text = [
  "Speaker: Speaker 3",
  "Cue: This is the archived C run that was used for the original B-to-C rank-direction comparison. It used 14 of 500 Oracle cases and upstream-prompt-compatible GPT-4o judgments through OpenRouter. Strong scored 30/42, compared with Weak at 15/42, and ranked higher in each of three repetitions.",
  "Keep this result separate from the GPT-6 Luna v5 and v6 collections. It is a local compatibility check, not a full benchmark result. The benchmark paper is Wu et al. (2025), LongMemEval: Benchmarking chat assistants on long-term interactive memory, ICLR: https://openreview.net/forum?id=pZiyCaVuti.",
].join("\n");

// AC5 now reflects the completed local C rule while preserving its generalisation limit.
setText("sh/98jedc3u", "Local C rule passed");
setText("sh/eh8fex47", "Broader cases; independent human grades");
presentation.slides.getItem(10).speakerNotes.text = [
  "Speaker: Speaker 4",
  "Cue: Report status against the approved criteria and keep implementation, observed performance and independent validity distinct. AC1 is not established; AC2 is partly evidenced; AC3 is not achieved. AC4 has a verified run and export path, but the full intake-to-report trace still waits for operator review of the 14 candidates. AC5's expanded local C comparison is complete: its frozen rule passed in all three repetitions. It does not settle generalisation, and the same-family automatic grader still needs independent human calibration.",
  "The 216-item A/B review return was AI-assisted and result-exposed, so it cannot count as independent blind evidence. The project contribution archive and member contribution confirmations remain to be reviewed by the team. User-provided names and planned proposal roles are not proof of individual completed contributions.",
  "Sources: proposal §9 Table 11; rubric criteria 1–7; experiment report §5–7; human review handoff.",
].join("\n\n");

const slide = presentation.slides.getItem(7);
setText("sh/lgbepgvm", "SPEAKER 3 · 2 OF 3");
setText("sh/18byd4zy", "Expanded C · Strong led on 30 new cases");
setText("sh/ri9g7uhw", "Source: frozen C v6 result; experiment report §5 · /expanded-c");
setText("sh/6h0fypgb", "8");
setText("sh/tkby9kzm", "v6 · 30 new cases · 3 repeats per policy · 180 answers + 180 usable grades");
setText("sh/sjix0zy1", "Weak · first-hit memory");
setText("sh/o7ydoret", "19 / 90 · 21.1%");
setText("sh/98rehwve", "Strong · task and update focus");
setText("sh/0jydkreh", "61 / 90 · 67.8%");
setText("sh/ehgvihwr", "Frozen winner rule passed · Strong led in 3/3 repeats");
setText("sh/zipwbmdc", "Strong 61/90 vs Weak 19/90 · +46.7 percentage points");
setText("sh/kfixwbe1", "Gaps: multi-session 0/15 for both; temporal Strong 5/15 (33%). Mean latency 6.80s vs 4.04s; Strong used 2.3× input tokens.\nEstimated total cost US$0.178; 180/180 usable grades. Human review pending; target and grader share the GPT-6 Luna family. This is not a full benchmark score or Auditor accuracy claim.");

setPosition("sh/id0fu50z", { left: 385, top: 239, width: 113, height: 25 });
setPosition("sh/n6pwfmd8", { left: 385, top: 337, width: 363, height: 25 });
setPosition("sh/1k7edwv2", { left: 92, top: 415, width: 1062, height: 218 });
setPosition("sh/ehgvihwr", { left: 116, top: 429, width: 1010, height: 29 });
setPosition("sh/zipwbmdc", { left: 116, top: 464, width: 986, height: 42 });
setPosition("sh/kfixwbe1", { left: 116, top: 510, width: 1005, height: 112 });
slide.speakerNotes.text = [
  "Speaker: Speaker 3",
  "Cue: Explain that this is the predeclared expansion of Proposal C. We kept the 14-case v5 record unchanged and selected 30 additional LongMemEval cases from the pinned 500-case Oracle source, with no question or evidence-session overlap against the earlier 28-case prepared release. Each strategy answered the same 30 cases three times, giving 90 answers and 90 usable automatic grades per strategy.",
  "The frozen decision rule required Strong to beat Weak on pooled accuracy and win at least two of three paired repetitions. Strong passed both parts: 61/90 (67.8%) versus 19/90 (21.1%), leading in all three repeats. Category results qualify that conclusion: both strategies scored zero on multi-session; Strong reached only 5/15 on temporal reasoning.",
  "Discuss the practical trade-off: Strong averaged 6.80 seconds versus 4.04 seconds and used about 2.3 times as many target input tokens. The estimated total collection cost was US$0.178; this is a token-rate estimate, not an invoice. Collection is complete at 180/180 answers and grades. Three explicit grader 429 responses were recovered through the recorded, single-request operational addendum.",
  "Do not call this Auditor accuracy or the official LongMemEval score. Target and automatic judge are from the same GPT-6 Luna family; independent human review is pending. The 180 blind-review rows are repeated answers over 30 histories, not 180 independent histories. The 44-case v5-plus-v6 summary is secondary because the snapshots differ.",
  "Source: frozen v6 protocol and analysis in artifacts/local/phase4-c-openrouter-20261028-v6; official benchmark citation: Wu et al. (2025), LongMemEval, ICLR, https://openreview.net/forum?id=pZiyCaVuti. The aggregate-only comparison is visible at http://localhost:5173/expanded-c.",
].join("\n\n");

for (const [index, targetSlide] of [presentation.slides.getItem(6), slide].entries()) {
  const png = await targetSlide.export({ format: "png", scale: 1 });
  await fs.writeFile(`${buildDir}/slide-${index === 0 ? 7 : 8}.png`, new Uint8Array(await png.arrayBuffer()));
  const layout = await targetSlide.export({ format: "layout" });
  await fs.writeFile(`${buildDir}/slide-${index === 0 ? 7 : 8}.layout.json`, await layout.text());
}
const montage = await presentation.export({ format: "webp", montage: true, scale: 0.5 });
await fs.writeFile(`${buildDir}/montage.webp`, new Uint8Array(await montage.arrayBuffer()));
const inspect = await presentation.inspect({ target: { id: "sl/fu1gfa1s" }, kind: "slide,textbox,shape,notes", maxChars: 20000 });
await fs.writeFile(`${buildDir}/changed-slides.ndjson`, inspect.ndjson);
const out = await PresentationFile.exportPptx(presentation);
await out.save(`${buildDir}/candidate.pptx`);
console.log(JSON.stringify({
  candidate: `${buildDir}/candidate.pptx`,
  slides: presentation.slides.items.length,
  updatedSlides: [7, 8],
  byteCount: (await fs.stat(`${buildDir}/candidate.pptx`)).size,
}, null, 2));
