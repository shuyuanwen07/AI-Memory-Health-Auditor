import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { parseArgs } from 'node:util';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const REPO = path.resolve(SCRIPT_DIR, '../..');
const SKILL_DIR = '/Users/y/.codex/plugins/cache/openai-primary-runtime/presentations/26.1026.10807/skills/presentations';
process.env.RUNTIME_NODE_MODULES ??= path.join(SCRIPT_DIR, 'node_modules');
const DEFAULTS = {
  source: path.join(REPO, 'output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v19.pptx'),
  dashboard: path.join(REPO, 'frontend/public/reports/proposal-final-results-v1.json'),
  fourStrategy: path.join(REPO, 'frontend/public/reports/phase4-c-four-strategy-v7.json'),
  output: path.join(REPO, 'output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v20.pptx'),
  staging: path.join(REPO, '.presentation-validation/v20-build/staging-v34'),
};

const CANONICAL_STRATEGIES = [
  ['weak_first_hit', 'First-match retrieval'],
  ['strong_rule_based', 'Relationship-priority retrieval'],
  ['scope_aware', 'Match the task and project'],
  ['temporal_importance', 'Consider time and importance'],
];
const PALETTE = {
  background: '#F7F6F1', navy: '#12304A', teal: '#087F8C', muted: '#536B7C',
  line: '#CCD5D8', white: '#FFFFFF', alternate: '#EEF2F1',
};

function fail(message) { throw new Error(message); }
function isRecord(value) { return typeof value === 'object' && value !== null && !Array.isArray(value); }
function isInt(value, min = 0) { return Number.isInteger(value) && value >= min; }
function isFiniteNumber(value) { return typeof value === 'number' && Number.isFinite(value); }
function sha256(bytes) { return createHash('sha256').update(bytes).digest('hex'); }
function near(a, b, tolerance = 0.11) { return Math.abs(a - b) <= tolerance; }
function displayPct(value) { return value == null ? 'Not available' : `${Number(value).toFixed(1)}%`; }
function displayAccuracy(row) {
  return `${row.correct}/${row.total}${row.accuracy_percent == null ? '' : ` · ${Number(row.accuracy_percent).toFixed(1)}%`}`;
}

function parseCli() {
  const { values } = parseArgs({
    args: process.argv.slice(2),
    options: {
      source: { type: 'string' }, dashboard: { type: 'string' },
      'four-strategy': { type: 'string' }, output: { type: 'string' },
      'check-only': { type: 'boolean', default: false },
    },
    strict: true,
  });
  return {
    source: path.resolve(values.source ?? DEFAULTS.source),
    dashboard: path.resolve(values.dashboard ?? DEFAULTS.dashboard),
    fourStrategy: path.resolve(values['four-strategy'] ?? DEFAULTS.fourStrategy),
    output: path.resolve(values.output ?? DEFAULTS.output),
    staging: DEFAULTS.staging,
    checkOnly: values['check-only'],
  };
}

async function readJson(filePath, label) {
  let value;
  try { value = JSON.parse(await fs.readFile(filePath, 'utf8')); }
  catch (error) { fail(`${label} is missing or invalid JSON: ${filePath} (${error.message})`); }
  if (!isRecord(value)) fail(`${label} must be a JSON object.`);
  return value;
}

function validateDashboardABC(data) {
  if (data.format !== 'proposal-final-results-dashboard-v1') fail('A/B/C input is not the published proposal-final-results-dashboard-v1 aggregate.');
  for (const key of ['generated_at', 'source_bundle', 'source_revision']) {
    if (typeof data[key] !== 'string' || !data[key]) fail(`A/B/C dashboard is missing ${key}.`);
  }
  if (!isRecord(data.generator) || !Array.isArray(data.source_hashes) || data.source_hashes.length < 1) fail('A/B/C dashboard lacks generator/source hash provenance.');

  const a = data.proposal_a;
  if (!isRecord(a) || a.answers !== 36 || a.histories !== 3 || a.methods !== 3 || a.questions_per_method_per_history !== 4) {
    fail('Published Proposal A counts do not match the frozen dashboard contract.');
  }
  const ar = a.retrospective_review;
  if (!isRecord(ar) || ar.total !== a.answers || ar.resolved + ar.uncertain !== ar.total || ar.per_method?.length !== 3) {
    fail('Proposal A review counts do not reconcile.');
  }
  if (a.formal_failure_discovery_rate !== null) fail('Proposal A discovery rate must remain explicitly unmeasured.');
  for (const method of ar.per_method) {
    if (!isRecord(method) || method.answers !== 12 || method.resolved + method.uncertain !== method.answers) fail('Proposal A method counts do not reconcile.');
  }

  const b = data.proposal_b;
  if (!isRecord(b) || b.canonical_answers !== 72 || b.histories !== 3 || b.repetitions !== 3 || b.policies?.length !== 2) {
    fail('Published Proposal B counts do not match the frozen dashboard contract.');
  }
  const byId = Object.fromEntries(b.policies.map(policy => [policy.id, policy]));
  const weak = byId.weak_first_hit;
  const relationship = byId.strong_rule_based;
  if (!weak || !relationship || weak.label !== 'First-match retrieval' || relationship.label !== 'Relationship-priority retrieval') fail('Proposal B canonical strategy labels do not match the dashboard.');
  for (const policy of b.policies) {
    if (policy.canonical_answers !== 36 || policy.per_repetition?.length !== 3) fail('Proposal B policy coverage or repeat count is inconsistent.');
    const repeated = policy.per_repetition.reduce((sum, row) => sum + row.passes + row.failures + row.uncertain, 0);
    if (repeated !== policy.canonical_answers) fail(`Proposal B repeat totals do not reconcile for ${policy.label}.`);
  }
  if (!Array.isArray(b.paired_history_macro_deltas_pp) || b.paired_history_macro_deltas_pp.length !== 3) fail('Proposal B must retain the three paired history effects.');

  const archived = data.proposal_c?.archived_compatibility;
  const expanded = data.proposal_c?.expanded_v5_v6;
  if (!isRecord(archived) || archived.cases !== 14 || archived.available_cases !== 500 || archived.repetitions !== 3 || archived.target_answers !== 84 || archived.usable_grades !== 84) {
    fail('Archived Proposal C compatibility counts do not match the published dashboard.');
  }
  if (!isRecord(expanded) || expanded.v6?.case_count !== 30 || expanded.v6?.repetitions !== 3 || expanded.v6_within_collection_repeat_wins !== 3) {
    fail('Expanded C v6 counts do not match the published dashboard.');
  }
  const archivedPolicies = Object.fromEntries(archived.policies.map(policy => [policy.id, policy]));
  const cWeak = archivedPolicies.weak_first_hit;
  const cRelationship = archivedPolicies.strong_rule_based;
  if (!cWeak || !cRelationship || cWeak.correct !== 15 || cWeak.total !== 42 || cRelationship.correct !== 30 || cRelationship.total !== 42) fail('Archived C values do not reconcile to the published A/B/C dashboard.');
  const expandedPolicies = Object.fromEntries(expanded.v6.policies.map(policy => [policy.id, policy]));
  const v6Weak = expandedPolicies.weak_first_hit;
  const v6Relationship = expandedPolicies.strong_rule_based;
  if (!v6Weak || !v6Relationship || v6Weak.correct !== 19 || v6Weak.total !== 90 || v6Relationship.correct !== 61 || v6Relationship.total !== 90) fail('Expanded C v6 values do not reconcile to the published A/B/C dashboard.');
  if (archived.b_c_ordering_agreement?.agreed_repetitions !== 3 || archived.b_c_ordering_agreement?.total_repetitions !== 3) fail('The archived B/C ranking agreement must remain 3/3.');
  return { a, b, archived, expanded };
}

function validateFourStrategyReport(report) {
  if (report.format !== 'phase4-c-four-strategy-v7') fail('Four-strategy JSON is not the published phase4-c-four-strategy-v7 report.');
  if (typeof report.complete_for_decision !== 'boolean') fail('Four-strategy report must explicitly state complete_for_decision.');
  for (const key of ['study_id', 'generated_at', 'protocol_id', 'source_revision']) {
    if (typeof report[key] !== 'string' || !report[key]) fail(`Four-strategy report is missing ${key}.`);
  }
  for (const key of ['protocol_sha256', 'run_sha256']) {
    if (typeof report[key] !== 'string' || !/^[a-f0-9]{64}$/i.test(report[key])) fail(`Four-strategy report has invalid ${key}.`);
  }
  if (report.case_count !== 30 || report.repetitions !== 3 || !Array.isArray(report.strategies) || report.strategies.length !== 4) {
    fail('Four-strategy report must contain four strategies with positive case and repeat counts.');
  }
  if (!isInt(report.total_target_answers) || !isInt(report.total_usable_grades) || report.total_usable_grades > report.total_target_answers) {
    fail('Four-strategy target/grade coverage is invalid.');
  }
  const expectedTargetCount = report.case_count * report.repetitions * 4;
  if (report.total_target_answers !== expectedTargetCount || report.total_usable_grades !== expectedTargetCount) {
    fail(`v7 run is incomplete (${report.total_target_answers} target answers, ${report.total_usable_grades} usable grades; ${expectedTargetCount} of each required); do not publish a final presentation yet.`);
  }
  const ids = new Set();
  let gradeSum = 0;
  for (const [id, label] of CANONICAL_STRATEGIES) {
    const row = report.strategies.find(item => item.id === id);
    if (!row || row.label !== label || ids.has(id)) fail(`Four-strategy result is missing the canonical strategy ${label}.`);
    ids.add(id);
    if (!isInt(row.correct) || !isInt(row.total) || row.correct > row.total || !isFiniteNumber(row.accuracy_percent) || row.total > report.case_count * report.repetitions) {
      fail(`Invalid pooled result for ${label}.`);
    }
    if (row.total === 0 || !near(row.accuracy_percent, row.correct * 100 / row.total)) fail(`Accuracy denominator mismatch for ${label}.`);
    if (!Array.isArray(row.per_repetition) || row.per_repetition.length !== report.repetitions) fail(`Missing per-repeat results for ${label}.`);
    let correctSum = 0;
    let totalSum = 0;
    const seen = new Set();
    for (const repeat of row.per_repetition) {
      if (!isRecord(repeat) || !isInt(repeat.repetition, 1) || repeat.repetition > report.repetitions || seen.has(repeat.repetition)) fail(`Invalid repeat identity for ${label}.`);
      if (!isInt(repeat.correct) || !isInt(repeat.total) || repeat.correct > repeat.total || repeat.total > report.case_count) fail(`Invalid repeat denominator for ${label}.`);
      if (repeat.total > 0 && (!isFiniteNumber(repeat.accuracy_percent) || !near(repeat.accuracy_percent, repeat.correct * 100 / repeat.total))) fail(`Repeat accuracy mismatch for ${label}.`);
      if (repeat.total === 0 && repeat.accuracy_percent !== null) fail(`A zero-coverage repeat must have a null accuracy for ${label}.`);
      seen.add(repeat.repetition);
      correctSum += repeat.correct;
      totalSum += repeat.total;
    }
    if (correctSum !== row.correct || totalSum !== row.total) fail(`Pooled and repeat counts do not reconcile for ${label}.`);
    gradeSum += row.total;
  }
  if (gradeSum !== report.total_usable_grades) fail('Per-strategy usable grade totals do not match the report total.');
  if (!Array.isArray(report.limitations) || report.limitations.length === 0) fail('Four-strategy report must include its limitations.');
  if (typeof report.decision_rule !== 'string' || !report.decision_rule.trim()) fail('Four-strategy report must retain its decision rule.');
  if (typeof report.recommended_strategy !== 'string') fail('Four-strategy report must state its decision status.');
  if (!report.complete_for_decision) {
    if (report.recommended_strategy !== 'no_clear_winner') fail('A timing-unverified complete run must explicitly report no_clear_winner.');
    if (!report.limitations.some(item => /timing|timestamp|monotonic|pacing|dispatch gap/i.test(item))) fail('A run withheld from decision must disclose the timing-evidence limitation.');
  }
  return report;
}

function getTimingLimitation(report) {
  return report.limitations.find(item => /timing|timestamp|monotonic|pacing|dispatch gap/i.test(item)) ?? null;
}

function parseInspection(result) {
  const source = typeof result === 'string' ? result : result?.ndjson;
  if (typeof source !== 'string') fail('Could not inspect the imported PowerPoint.');
  return source.split(/\r?\n/).filter(Boolean).map(line => JSON.parse(line));
}

function slideText(records, slideIndex) {
  return records.filter(record => record.slideIndex === slideIndex && ['textbox', 'shape'].includes(record.kind))
    .map(record => record.text ?? '').join('\n');
}

function requireSlideValues(records, index, expected, label) {
  const visible = slideText(records, index);
  for (const value of expected) if (!visible.includes(value)) fail(`${label} slide ${index + 1} does not match published dashboard value: ${value}`);
}

function validateVisibleDashboardSlides(records, abc) {
  const a = abc.a.retrospective_review;
  const bWeak = abc.b.policies.find(row => row.id === 'weak_first_hit');
  const bRelationship = abc.b.policies.find(row => row.id === 'strong_rule_based');
  const cWeak = abc.archived.policies.find(row => row.id === 'weak_first_hit');
  const cRelationship = abc.archived.policies.find(row => row.id === 'strong_rule_based');
  const v6Weak = abc.expanded.v6.policies.find(row => row.id === 'weak_first_hit');
  const v6Relationship = abc.expanded.v6.policies.find(row => row.id === 'strong_rule_based');
  requireSlideValues(records, 4, [String(abc.a.answers), `${a.resolved} / ${a.total}`, `${a.uncertain} / ${a.total}`, `${a.confusion_vs_adopted_references.tp} / ${a.confusion_vs_adopted_references.tp}`], 'A');
  requireSlideValues(records, 5, [`${Number(bWeak.macro_accuracy_percent).toFixed(2)}%`, `${Number(bRelationship.macro_accuracy_percent).toFixed(2)}%`, ...bRelationship.per_repetition.map(row => String(Number(row.macro_accuracy_percent).toFixed(2).replace(/0+$/, '').replace(/\.$/, '')))], 'B');
  requireSlideValues(records, 6, [`${cWeak.correct} / ${cWeak.total}`, `${cRelationship.correct} / ${cRelationship.total}`, `${abc.archived.cases} of ${abc.archived.available_cases} Oracle cases`, `${abc.archived.b_c_ordering_agreement.agreed_repetitions} / ${abc.archived.b_c_ordering_agreement.total_repetitions}`], 'Archived C');
  requireSlideValues(records, 7, [`${v6Weak.correct} / ${v6Weak.total}`, `${v6Relationship.correct} / ${v6Relationship.total}`, `${abc.expanded.v6_within_collection_repeat_wins}/${abc.expanded.v6.repetitions}`], 'Expanded C v6');
}

function addText(slide, name, value, position, style = {}) {
  const shape = slide.shapes.add({
    geometry: 'textbox', name, position, fill: 'none',
    line: { style: 'solid', fill: 'none', width: 0 },
  });
  shape.text = value;
  shape.text.style = { typeface: 'Arial', color: PALETTE.navy, fontSize: 18, ...style };
  shape.text.insets = 0;
  return shape;
}

function addResultsSlide(presentation, report, dashboardData, priorSlide) {
  const { slide } = presentation.slides.insert({
    after: priorSlide,
    layout: 'Blank',
    width: 1280,
    height: 720,
    background: { fill: PALETTE.background },
  });
  addText(slide, 'speaker-label', 'SPEAKER 3 · 3 OF 4', { left: 74, top: 27, width: 520, height: 24 }, { fontSize: 15, bold: true, color: PALETTE.teal });
  addText(slide, 'slide-title', 'Four retrieval strategies on the same cases', { left: 74, top: 58, width: 1132, height: 64 }, { fontSize: 39, bold: true, color: PALETTE.navy });
  addText(slide, 'study-caption', `Experiment C extension · ${report.case_count} LongMemEval cases · ${report.repetitions} repeats per strategy · ${report.total_target_answers} target answers and ${report.total_usable_grades} usable grades`, { left: 78, top: 137, width: 1120, height: 30 }, { fontSize: 16, color: PALETTE.muted });
  const decisionStatus = !report.complete_for_decision
    ? 'Complete data coverage · no protocol winner'
    : report.recommended_strategy === 'no_clear_winner'
      ? 'Complete coverage · protocol rule selected no clear winner'
      : `Complete coverage · protocol rule selects ${CANONICAL_STRATEGIES.find(([id]) => id === report.recommended_strategy)?.[1] ?? report.recommended_strategy}`;
  addText(slide, 'decision-status', decisionStatus, { left: 78, top: 162, width: 1120, height: 22 }, { fontSize: 14, bold: true, color: PALETTE.teal });

  const lookup = Object.fromEntries(report.strategies.map(row => [row.id, row]));
  const strategyRows = CANONICAL_STRATEGIES.map(([id]) => lookup[id]);
  const chartRows = [...strategyRows].reverse();
  const chart = slide.charts.add('bar', {
    position: { left: 74, top: 186, width: 1132, height: 330 },
    categories: chartRows.map(row => row.label),
    series: [{ name: 'Pooled score', values: chartRows.map(row => row.accuracy_percent), fill: PALETTE.teal }],
    barOptions: { direction: 'bar', grouping: 'clustered', gapWidth: 62 },
    hasLegend: false,
    xAxis: {
      textStyle: { fill: PALETTE.navy, fontSize: 15 },
      line: { style: 'solid', fill: 'none', width: 0 },
    },
    yAxis: {
      min: 0, max: 100, majorUnit: 25, numberFormatCode: '0"%"',
      textStyle: { fill: PALETTE.muted, fontSize: 12 },
      majorGridlines: { style: 'solid', fill: PALETTE.line, width: 1 },
      line: { style: 'solid', fill: PALETTE.line, width: 1 },
    },
    dataLabels: { showValue: true, position: 'inEnd', textStyle: { fill: PALETTE.white, fontSize: 12, bold: true } },
    chartFill: 'none',
    chartLine: { style: 'solid', fill: 'none', width: 0 },
    plotAreaFill: 'none',
    plotAreaLine: { style: 'solid', fill: 'none', width: 0 },
  });
  const pooledSeries = chart.series.getItemAt(0);
  for (const [index, result] of chartRows.entries()) {
    const override = pooledSeries.dataLabelOverrides.add(index);
    override.text = `${result.correct}/${result.total} · ${displayPct(result.accuracy_percent)}`;
    override.position = 'inEnd';
    override.showValue = true;
    override.textStyle.fontSize = 12;
    override.textStyle.typeface = 'Arial';
    override.textStyle.fill = PALETTE.white;
    override.textStyle.bold = true;
  }
  addText(slide, 'repeat-heading', 'Repeat counts · same 30 cases', { left: 78, top: 522, width: 1120, height: 21 }, { fontSize: 14, bold: true, color: PALETTE.navy });
  for (const [index, result] of strategyRows.entries()) {
    const repeats = [...result.per_repetition].sort((a, b) => a.repetition - b.repetition);
    addText(slide, `repeat-results-${result.id}`, `${result.label}: ${repeats.map(row => `R${row.repetition} ${row.correct}/${row.total}`).join('   ')}`, { left: 78, top: 542 + index * 19, width: 1120, height: 19 }, { fontSize: 12, color: PALETTE.muted });
  }
  addText(slide, 'limitation-note', report.complete_for_decision
    ? 'Automatic grades · no independent human calibration · separate from A/B/C · not Auditor accuracy'
    : 'No protocol winner · timing trace not saved · automatic grades, not Auditor accuracy', { left: 78, top: 622, width: 1120, height: 19 }, { fontSize: 12, color: PALETTE.muted });
  slide.shapes.add({ geometry: 'rect', name: 'footer-rule', position: { left: 74, top: 651, width: 1132, height: 1.5 }, fill: PALETTE.line, line: { style: 'solid', fill: 'none', width: 0 } });
  addText(slide, 'source-footer', 'Source: published Research Results A/B/C dashboard + published four-strategy v7 report', { left: 74, top: 662, width: 1060, height: 26 }, { fontSize: 13, color: PALETTE.muted });
  addText(slide, 'slide-number', '9', { left: 1155, top: 662, width: 48, height: 26 }, { fontSize: 15, bold: true, color: PALETTE.muted, alignment: 'right' });

  const a = dashboardData.proposal_a;
  const timingLimitation = getTimingLimitation(report);
  const recommendationLabel = report.recommended_strategy === 'no_clear_winner'
    ? 'no protocol winner'
    : CANONICAL_STRATEGIES.find(([id]) => id === report.recommended_strategy)?.[1] ?? report.recommended_strategy;
  slide.speakerNotes.text = [
    'Speaker 3 | Slide 9 — Four-strategy retrieval comparison',
    '',
    `This is an exploratory extension, separate from the proposal-frozen A/B/C results. It replays ${report.case_count} distinct LongMemEval cases under four retrieval strategies and runs each strategy ${report.repetitions} times. It contains ${report.total_target_answers} target answers and ${report.total_usable_grades} usable automatic grades. The editable bars show pooled correct answers over usable grades. Compact repeat counts appear below each bar. Repeated runs reuse the same cases, so they are not additional independent cases.`,
    '',
    `Read the exact numerator, usable-grade denominator, and percentage inside each bar. The repeat counts appear below it, and all three repeats reuse the same 30 cases. The report recommends ${recommendationLabel}. ${report.complete_for_decision ? 'The frozen decision rule status is complete.' : 'Coverage is complete, but the protocol winner decision is withheld because timing could not be independently verified.'} ${timingLimitation ?? ''} These automatic grades describe retrieval outcomes for this local setup. They do not establish Auditor accuracy, independent human agreement, or a general four-way winner. The existing proposal A/B/C dashboard remains the formal experiment record: Experiment A has ${a.answers} answers and a null formal failure-discovery rate; the v7 supplement does not replace that result.`,
    '',
    `Source files: ${path.relative(REPO, DEFAULTS.dashboard)}; ${path.relative(REPO, DEFAULTS.fourStrategy)}. Dashboard A/B/C generated ${dashboardData.generated_at}; v7 protocol ${report.protocol_id}, SHA-256 ${report.protocol_sha256}; run SHA-256 ${report.run_sha256}. Open the published four-strategy page for category and matched-pair detail.`,
  ].join('\n');
  slide.speakerNotes.setVisible(true);
  return slide;
}

function validateNativeFourStrategyChart(chart, report, label) {
  if (!chart) fail(`${label} four-strategy native chart is missing.`);
  const canonicalRows = CANONICAL_STRATEGIES.map(([id, expectedLabel]) => {
    const row = report.strategies.find(item => item.id === id);
    if (!row || row.label !== expectedLabel) fail(`${label} report is missing ${expectedLabel}.`);
    return row;
  });
  const rows = [...canonicalRows].reverse();
  const series = chart.series?.getItemAt?.(0);
  const categories = series?.categories ?? chart.categories ?? [];
  const values = series?.values ?? [];
  const overrides = series?.dataLabelOverrides?.items ?? [];
  if (categories.length !== rows.length || values.length !== rows.length || overrides.length !== rows.length) fail(`${label} native chart is missing a strategy category, score, or denominator label.`);
  for (const [index, row] of rows.entries()) {
    if (categories[index] !== row.label || !near(values[index], row.accuracy_percent, 0.001)) fail(`${label} native chart does not match the published pooled result for ${row.label}.`);
    const expectedLabel = `${row.correct}/${row.total} · ${displayPct(row.accuracy_percent)}`;
    if (overrides[index].text !== expectedLabel) fail(`${label} native chart denominator label does not match the published result for ${row.label}.`);
  }
}

function findRecord(records, predicate, message) {
  const matches = records.filter(predicate);
  if (matches.length !== 1) fail(`${message}: expected exactly one matching PowerPoint element; found ${matches.length}.`);
  return matches[0];
}

function setShapeText(presentation, records, slideIndex, name, text) {
  const record = findRecord(records, row => row.kind === 'textbox' && row.slideIndex === slideIndex && row.name === name, `Could not find ${name} on slide ${slideIndex + 1}`);
  presentation.resolve(record.id).text = text;
}

function setUniqueText(presentation, records, slideIndex, oldText, newText) {
  const record = findRecord(records, row => row.kind === 'textbox' && row.slideIndex === slideIndex && row.text === oldText, `Could not update “${oldText}” on slide ${slideIndex + 1}`);
  presentation.resolve(record.id).text = newText;
}

function updatedSourceNote(note, originalIndex, dashboard, humanReview, repairReview) {
  let updated = note.replace(/^(Speaker \d+ \| Slide )(\d+)( —)/, (_match, prefix, number, suffix) => `${prefix}${Number(number) >= 9 ? Number(number) + 1 : number}${suffix}`);
  if (originalIndex === 7) updated = updated.replace('human review is pending,', 'human-review files have been received, though reviewer independence and integration into these automatic scores remain unverified,');
  if (originalIndex === 8) updated = updated.replace('Five labels need human review.', `The original automated scores are retained above; two later reviewers agreed on all 24 answers. Human-reviewed pass counts are ${repairReview.conditions.map(row => `${row.pass}/${row.total}`).join(', ')} for original, generic and targeted conditions. Four of eight questions passed only after targeted retrieval, none only before it. The user reports the two people were independent and had not seen automatic scores; the older file declarations conflict with that confirmation. One run per condition on one synthetic history is not a general efficacy estimate.`);
  if (originalIndex === 9) updated += '\n\nA separate category pilot found 11 of 13 automatic categories agreed with the human judgments; the two mismatches were withheld by a development-only candidate gate. In an earlier historical check, the original got 18/18 right and the candidate withheld one correct category. This is abstention, not correction; the candidate is not deployed or prospectively validated.';
  if (originalIndex === 4) {
    const anchor = 'Retrospective reference review resolved 30 answers: 27 were labelled failures and three passes; six remained uncertain.';
    const rows = dashboard.proposal_a.retrospective_review.per_method
      .map(row => `${row.label}: ${row.failures} failures, ${row.passes} pass, ${row.uncertain} uncertain out of ${row.answers}`)
      .join('; ');
    const signatures = dashboard.proposal_a.retrospective_review.per_method.map(row => [row.passes, row.failures, row.uncertain].join('/'));
    const interpretation = new Set(signatures).size === 1
      ? 'These observed counts are equal across the three arms; they do not establish method equivalence or a method advantage.'
      : 'The method arms differ descriptively; unresolved validity and incomplete defect mapping still prevent a formal method-superiority claim.';
    const inserted = `Per-method review: ${rows}. ${interpretation}`;
    if (!updated.includes(anchor)) fail('The v19 Experiment A speaker note did not match the expected text; refusing a blind replacement.');
    updated = updated.replace(anchor, `${anchor} ${inserted}`);
  }
  if (originalIndex === 5) {
    const policy = dashboard.proposal_b.policies.find(row => row.id === 'strong_rule_based');
    const score = Number(policy.macro_accuracy_percent).toFixed(2);
    const clarification = `The ${score}% score is the unweighted four-dimension macro average over Accuracy, Freshness, Conflict resolution, and Appropriate use. The separate Relationship-priority outcome tally is ${policy.passes} pass, ${policy.failures} fail, and ${policy.uncertain} uncertain out of ${policy.passes + policy.failures + policy.uncertain}; do not read the macro score as a pass fraction.`;
    updated = `${updated.trimEnd()}\n\n${clarification}`;
  }
  if (originalIndex === 8) {
    const anchor = 'This is a supplementary tutor-requested demonstration, separate from the proposal\'s main method-comparison question.';
    const replacement = 'This is a saved audit example created to demonstrate the tutor-requested diagnosis → repair → retest loop, separate from the proposal\'s main method-comparison question.';
    if (!updated.includes(anchor)) fail('The tutor-loop speaker note did not match the expected text; refusing a blind replacement.');
    updated = updated.replace(anchor, replacement);
  }
  if (originalIndex === 10) {
    updated += '\n\nFor the original AC3 question set, both reviewers marked all 32 source-grounding items valid. The user confirmed two different reviewers worked independently with AI assistance; the original file declarations are preserved. The source was subsequently revised so two active records each claim a different venue is the only final confirmed venue. The user reports two distinct reviewers independently reviewed the eight changed question contexts and related facts, with AI assistance; identity is not independently authenticated. The revised 32-question source is supported by combined original and revised-item reviews; the original 32 judgments alone do not validate the revision. The user accepted pilot-based thresholds: failure recall at least 80%, classification accuracy at least 80%, test validity at least 90%, and false positive rate no more than 10%. The pilot covered one synthetic history and eight unique questions. The proposed expansion retains the eight reviewed histories and adds 22 varied synthetic histories, for 30 histories and 120 questions total. The 22 new histories and 88 questions still require independent source, fact and relationship review; none has been run. After an AI author self-check, 10 histories were revised in v6, while 12 remain unchanged from v5. The two reviewers should assess the unchanged 12 in v5 and the revised 10 in v6. This is not an independent AI review or a claim of human approval. The material is authored and controlled, not a random or independent population sample. The complete protocol has not been frozen and no held-out answer test has been run; grounding agreement does not demonstrate Auditor validity.';
    updated += '\n\nThe later AC1 adjudication was AI-assisted, exposed to prior decisions, and user-confirmed. Of 27 candidate memories, 21 were originally agreed valid and six were subsequently adjudicated valid. Across 24 listed reference units, 18 were fully covered and six partially covered. The six newly accepted memories require original source context, the reference list is not known to be exhaustive, and these retrospective counts do not establish overall recall or AC1 acceptance. Thirteen original questions were first uncertain and subsequently adjudicated as six valid and seven invalid. Thirteen revisions were jointly reviewed with all three fields marked valid; separate independent label sets are not established. The original experiment data were not altered.';
    updated = updated.replace("AC4 has verified run/export paths, but the separate intake's 14 candidates still await operator review and have no target runs.", "AC4 has verified run/export paths. The separate intake's 14 candidates have since been confirmed against the returned reviews; it has no target run yet.");
    const oldSentence = 'AC5 has only a local expected-order check: B/C show that relationship-priority retrieval scores higher in these target-memory cases, not that the Auditor finds failures. Broader cases and independent human grades remain needed.';
    const newSentence = 'AC5 is substantially evidenced for a local repeated comparison after the separate v6 extension: a frozen 30-case LongMemEval set produced 180 target answers and 180 usable automatic grades, with Relationship-priority retrieval higher in all three repeats. These repeats reuse the same cases, and the GPT-6 Luna grader has not been independently calibrated, so generalisation remains open. This is target-memory evidence, not Auditor validity.';
    if (!updated.includes(oldSentence)) fail('The v19 AC5 speaker note did not match the expected text; refusing a blind replacement.');
    updated = updated.replace(oldSentence, newSentence);
    updated += `\n\nTwo human-review files were received and the user confirmed two independent reviewers who had not seen automatic scores beforehand. Original file declarations differ and must be reconciled. Of ${humanReview.baseline_items} shared items, ${humanReview.agreement} agree, ${humanReview.uncertain} include an uncertain judgment and ${humanReview.disagreement} disagree; agreement is not adjudication. For the new four-strategy answers, ${humanReview.v7_both_reviewed} of ${humanReview.v7_items} have been reviewed by both.`;
  }
  return updated;
}

async function updateSlideLabelsAndNotes(presentation, originalSlides, expectedNotes, dashboard, humanReview, repairReview) {
  for (let originalIndex = 0; originalIndex < originalSlides.length; originalIndex += 1) {
    originalSlides[originalIndex].speakerNotes.text = expectedNotes[originalIndex];
  }

  const records = parseInspection(await presentation.inspect({ kind: 'textbox', maxChars: 500000 }));
  for (const record of records.filter(row => row.kind === 'textbox' && row.name === 'slide-number')) {
    presentation.resolve(record.id).text = String(record.slideIndex + 1);
  }
  const oldNineIndex = 9; // Original slide 9 shifts to position 10 after inserting the new slide.
  setShapeText(presentation, records, oldNineIndex, 'speaker-label', 'SPEAKER 3 · 4 OF 4');
  setShapeText(presentation, records, 8, 'speaker-label', 'SPEAKER 3 · 3 OF 4');
  const shiftedRecords = parseInspection(await presentation.inspect({ kind: 'textbox', maxChars: 500000 }));
  for (const record of shiftedRecords.filter(row => row.kind === 'textbox')) {
    if (record.slideIndex === 7 && record.text?.includes('Human review pending;')) presentation.resolve(record.id).text = record.text.replace('Human review pending;', 'Human-review files received; independence unconfirmed;');
    if (record.slideIndex === 9 && record.text?.includes('Five answers await review;')) presentation.resolve(record.id).text = `Same 8 questions: both pass 1; improved-only pass ${repairReview.paired_original_to_target.target_only_pass}; original-only pass ${repairReview.paired_original_to_target.original_only_pass}; both fail 3.\nTwo reviewers agreed on all 24 answers. User confirms independent review; original declarations differ.\nOne run per condition on one synthetic history; automatic scores are preserved separately. No general causal claim.`;
    if (record.slideIndex === 11 && record.text?.includes('not independent.')) presentation.resolve(record.id).text = `Human review received: ${humanReview.agreement} agree · ${humanReview.uncertain} uncertain · ${humanReview.disagreement} disagree (${humanReview.baseline_items} items). User confirms independence; original declarations differ. Four-strategy review: ${humanReview.v7_both_reviewed}/${humanReview.v7_items}.`;
  }
  setUniqueText(presentation, shiftedRecords, 9, 'Per condition: pass / fail / uncertain (8 tests)', 'Human review · pass / fail (8 tests)');
  for (const [index, left] of [82, 444, 806].entries()) {
    const record = findRecord(shiftedRecords, row => row.kind === 'textbox' && row.slideIndex === 9 && row.position?.left === left && row.position?.top === 463, 'Could not locate tutor human-review score');
    const result = repairReview.conditions[index];
    presentation.resolve(record.id).text = `${result.pass} / ${result.fail}`;
  }
  setUniqueText(presentation, shiftedRecords, 5, 'First-match', 'First-match retrieval');
  setUniqueText(presentation, shiftedRecords, 5, 'Relationship-priority', 'Relationship-priority retrieval');
  setUniqueText(presentation, shiftedRecords, 5, 'Rule-evaluator macro score', 'Four-dimension macro average');
  setUniqueText(presentation, shiftedRecords, 6, 'First-match', 'First-match retrieval');
  setUniqueText(presentation, shiftedRecords, 6, 'Relationship-priority', 'Relationship-priority retrieval');
  setUniqueText(presentation, shiftedRecords, 11, 'Frozen threshold + independent blind labels', '30 histories · 120 questions proposed\n8 reviewed · 12 v5 + 10 v6 await review');
  setUniqueText(presentation, shiftedRecords, 11, 'Direction check only', 'Substantially evidenced locally');
  setUniqueText(presentation, shiftedRecords, 11, 'Independent labels; broader cases', '30 cases · 3 repeats · generalisation open');
  setUniqueText(presentation, shiftedRecords, 11, '13 / 48 validity decisions uncertain', 'Original: 6 valid / 7 invalid; 13 revisions jointly reviewed');
  setUniqueText(presentation, shiftedRecords, 11, 'Independent, source-backed labels', '27/27 judged valid · 18 full / 6 partial\nRetrospective · references not exhaustive');
  setUniqueText(presentation, shiftedRecords, 11, 'Full intake-to-report trace; 14 candidates await operator review', '14 candidates confirmed; target audit not yet run');
  setUniqueText(presentation, shiftedRecords, 10, 'Useful for showing abstention and review paths; not an independent estimate of Auditor accuracy.', 'Category pilot: 11/13 correct; candidate withheld 2. Earlier history: candidate withheld 1 correct category.');
  setUniqueText(presentation, shiftedRecords, 9, 'Current-source tutor loop: diagnosis, repair and retest', 'Saved audit example: diagnosis, repair and retest');
  const relationship = presentation.slides.getItem(5);
  const outcomes = dashboard.proposal_b.policies.find(row => row.id === 'strong_rule_based');
  const outcomeTotal = outcomes.passes + outcomes.failures + outcomes.uncertain;
  addText(relationship, 'separate-adjudication-tally', `Separate outcome tally: ${outcomes.passes} pass, ${outcomes.failures} fail, ${outcomes.uncertain} uncertain (${outcomeTotal} answers)`, { left: 94, top: 526, width: 980, height: 20 }, { fontSize: 13, color: PALETTE.muted });
}

async function updateASlide(presentation, dashboard) {
  const records = parseInspection(await presentation.inspect({ kind: 'textbox', maxChars: 500000 }));
  const arms = dashboard.proposal_a.retrospective_review.per_method;
  const signatures = arms.map(row => [row.passes, row.failures, row.uncertain].join('/'));
  const sameCounts = new Set(signatures).size === 1;
  const denominators = new Set(arms.map(row => row.answers));
  const perArmLabel = denominators.size === 1 ? `${arms[0].answers} answers each` : 'answer counts shown per arm';
  setUniqueText(presentation, records, 4, 'A · The method baseline is partly resolved', sameCounts
    ? 'A · All three methods had the same reviewed counts'
    : 'A · Retrospective outcomes by audit method');
  setUniqueText(presentation, records, 4, 'Among the 30 resolved answers', `Review outcomes by method · ${perArmLabel}`);
  const outcomeLines = arms.map(row => `${row.label.replace(' tests', '')}: ${row.failures} fail · ${row.passes} pass · ${row.uncertain} uncertain`).join('\n');
  const result = findRecord(records, row => row.kind === 'textbox' && row.slideIndex === 4 && row.text === '27 failures  ·  3 passes', 'Could not find the Experiment A outcome field');
  const shape = presentation.resolve(result.id);
  shape.text = outcomeLines;
  shape.position = { left: 92, top: 407, width: 540, height: 86 };
  shape.text.style = { typeface: 'Arial', fontSize: 16, color: PALETTE.navy, alignment: 'left' };
  shape.text.insets = 0;
}

async function updatePolicyLabelsAndBars(presentation, abc) {
  const records = parseInspection(await presentation.inspect({ kind: 'textbox,shape', maxChars: 500000 }));
  const b = Object.fromEntries(abc.b.policies.map(row => [row.id, row]));
  const c = Object.fromEntries(abc.archived.policies.map(row => [row.id, row]));
  const specs = [
    { slideIndex: 5, rowY: [239, 337], labels: [b.weak_first_hit.label, b.strong_rule_based.label], scores: [b.weak_first_hit.macro_accuracy_percent, b.strong_rule_based.macro_accuracy_percent], oldX: 294, oldWidth: 570, newX: 394, newWidth: 470, labelWidth: 285, labelFontSize: 16 },
    { slideIndex: 6, rowY: [238, 340], labels: [c.weak_first_hit.label, c.strong_rule_based.label], scores: [c.weak_first_hit.accuracy_percent, c.strong_rule_based.accuracy_percent], oldX: 285, oldWidth: 600, newX: 360, newWidth: 525, labelWidth: 252, labelFontSize: 16 },
  ];
  const colors = ['#A7423B', '#087F8C'];
  for (const spec of specs) {
    for (let index = 0; index < 2; index += 1) {
      const labelText = index === 0 ? 'First-match retrieval' : 'Relationship-priority retrieval';
      const label = findRecord(records, row => row.kind === 'textbox' && row.slideIndex === spec.slideIndex && row.text === (index === 0 ? 'First-match retrieval' : 'Relationship-priority retrieval'), `Could not find canonical strategy label on slide ${spec.slideIndex + 1}`);
      const labelFacade = presentation.resolve(label.id);
      labelFacade.position = { ...label.position, width: spec.labelWidth };
      labelFacade.text.style = { typeface: 'Arial', fontSize: spec.labelFontSize, bold: true, color: '#152B3C', alignment: 'left' };

      const y = spec.rowY[index];
      const background = findRecord(records, row => row.kind === 'shape' && row.slideIndex === spec.slideIndex && row.position?.left === spec.oldX && row.position?.top === y && row.position?.width === spec.oldWidth && row.fillColor?.toUpperCase() === '#E6EBE9', `Could not find comparison bar background on slide ${spec.slideIndex + 1}`);
      const foreground = findRecord(records, row => row.kind === 'shape' && row.slideIndex === spec.slideIndex && row.position?.left === spec.oldX && row.position?.top === y && row.fillColor?.toUpperCase() === colors[index], `Could not find comparison bar value on slide ${spec.slideIndex + 1}`);
      const bg = presentation.resolve(background.id);
      bg.position = { ...background.position, left: spec.newX, width: spec.newWidth };
      const value = presentation.resolve(foreground.id);
      value.position = { ...foreground.position, left: spec.newX, width: Math.max(1, spec.newWidth * Number(spec.scores[index]) / 100) };
      if (label.text !== labelText) fail('Canonical strategy label update did not persist.');
    }
  }
}

async function saveBlob(filePath, blob) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await blob.save(filePath);
}

async function main() {
  const args = parseCli();
  if (args.output !== args.source && !args.output.startsWith(`${REPO}${path.sep}`)) fail('Final PPTX output must stay inside the project workspace.');
  const missing = [];
  for (const [label, filePath] of [['v19 source deck', args.source], ['published A/B/C dashboard', args.dashboard], ['published v7 four-strategy JSON', args.fourStrategy]]) {
    try { await fs.access(filePath); } catch { missing.push(`${label}: ${filePath}`); }
  }
  if (missing.length) {
    console.log('v20 was not built. Required published inputs are not all present:');
    for (const item of missing) console.log(`- ${item}`);
    console.log('No output deck was created. Run again only after the complete published dashboard and v7 report are available.');
    process.exitCode = 2;
    return;
  }
  try { await fs.access(args.output); fail(`Refusing to overwrite existing presentation: ${args.output}`); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }

  const dashboard = await readJson(args.dashboard, 'Published A/B/C dashboard');
  const fourStrategyStat = await fs.stat(args.fourStrategy);
  if (fourStrategyStat.size === 0) fail('The v7 path is only a zero-byte placeholder; no final presentation will be built.');
  const fourStrategy = await readJson(args.fourStrategy, 'Published v7 report');
  const humanReview = await readJson(path.join(REPO, 'frontend/public/reports/human-review-summary-v1.json'), 'Published human-review dashboard summary');
  const repairReview = await readJson(path.join(REPO, 'frontend/public/reports/tutor-repair-human-review-v2.json'), 'Published human-reviewed repair summary');
  const ac1 = await readJson(path.join(REPO, 'frontend/public/reports/ac1-retrospective-adjudicated-v1.json'), 'AC1 retrospective summary');
  const ac3expanded = await readJson(path.join(REPO, 'output/proposal-delivery/ac3-expanded-v5-original-reconstructed-2026-10-28/manifest.json'), 'AC3 expanded proposed sample');
  const ac3repair = await readJson(path.join(REPO, 'output/proposal-delivery/ac3-expanded-30-candidate-draft-2026-10-28-v6/manifest.json'), 'AC3 revised sample manifest');
  if (ac3repair.changed_history_ids?.length !== 10 || ac3repair.unchanged_added_history_ids?.length !== 12 || ac3repair.review_required_for_changed_histories !== true || ac3repair.frozen !== false || ac3repair.model_called !== false) fail('Unexpected AC3 repair status');
  if (ac3expanded.original_histories !== 8 || ac3expanded.new_histories !== 22 || ac3expanded.total_histories !== 30 || ac3expanded.questions !== 120 || ac3expanded.new_review_required !== true || ac3expanded.frozen !== false || ac3expanded.model_called !== false) fail('Unexpected AC3 expansion status');
  const thresholds = await readJson(path.join(REPO, 'output/proposal-delivery/ac3-threshold-selection-user-delegated-2026-10-28.json'), 'AC3 selected thresholds');
  if (ac1.candidate_valid?.numerator !== 27 || ac1.candidate_valid?.denominator !== 27 || ac1.reference_coverage?.full !== 18 || ac1.reference_coverage?.partial !== 6 || ac1.reference_coverage?.total !== 24) fail('Unexpected AC1 source summary');
  if (thresholds.thresholds?.failure_detection_recall_min !== 0.8 || thresholds.thresholds?.failure_classification_accuracy_min !== 0.8 || thresholds.thresholds?.test_validity_min !== 0.9 || thresholds.thresholds?.false_positive_rate_max !== 0.1) fail('Unexpected selected AC3 thresholds');
  if (repairReview.format !== 'tutor-repair-human-review-public-v1' || repairReview.conditions?.length !== 3 || repairReview.conditions.some(row => row.total !== 8 || row.pass + row.fail !== row.total)) fail('Human-reviewed repair summary has invalid counts.');
  if (humanReview.format !== 'human-review-summary-v1' || humanReview.baseline_items !== humanReview.agreement + humanReview.uncertain + humanReview.disagreement || humanReview.v7_items !== 360 || humanReview.v7_both_reviewed > humanReview.v7_items) fail('Human-review dashboard summary has invalid counts.');
  const abc = validateDashboardABC(dashboard);
  const report = validateFourStrategyReport(fourStrategy);
  const deckBytes = await fs.readFile(args.source);
  const sourceDeckHash = sha256(deckBytes);
  const dashboardHash = sha256(await fs.readFile(args.dashboard));
  const fourStrategyHash = sha256(await fs.readFile(args.fourStrategy));

  if (args.checkOnly) {
    console.log(JSON.stringify({ status: 'inputs_valid', sourceDeckHash, dashboardHash, fourStrategyHash, cases: report.case_count, repetitions: report.repetitions, targetAnswers: report.total_target_answers, usableGrades: report.total_usable_grades }, null, 2));
    return;
  }

  if (args.output === args.source) fail('Output path must differ from the preserved v19 source deck.');
  const presentation = await PresentationFile.importPptx(await FileBlob.load(args.source));
  const originalSlides = [...presentation.slides.items];
  if (originalSlides.length !== 12) fail(`Expected the preserved 12-slide v19 source, got ${originalSlides.length}.`);
  const notesBefore = originalSlides.map(slide => slide.speakerNotes?.text ?? '');
  if (notesBefore.some(note => !note.trim())) fail('A v19 speaker note is missing; refusing to lose or invent it.');
  const expectedNotes = notesBefore.map((note, index) => updatedSourceNote(note, index, dashboard, humanReview, repairReview));
  const records = parseInspection(await presentation.inspect({ kind: 'layout,slide,textbox,notes', maxChars: 1000000 }));
  validateVisibleDashboardSlides(records, abc);
  const blank = findRecord(records, row => row.kind === 'layout' && row.name === 'Blank', 'Blank source layout is missing');

  addResultsSlide(presentation, report, dashboard, originalSlides[7]);
  const { applyPresentationChartFont } = await import(pathToFileURL(path.join(SKILL_DIR, 'container_tools/artifact_tool_utils.mjs')).href);
  const v7Chart = presentation.slides.getItem(8).charts?.items?.[0];
  applyPresentationChartFont(v7Chart, { fontFamily: 'Arial' });
  validateNativeFourStrategyChart(v7Chart, report, 'Draft');
  await updateSlideLabelsAndNotes(presentation, originalSlides, expectedNotes, dashboard, humanReview, repairReview);
  await updateASlide(presentation, dashboard);
  await updatePolicyLabelsAndBars(presentation, abc);

  const finalRecords = parseInspection(await presentation.inspect({ kind: 'slide,textbox,notes', maxChars: 1000000 }));
  const decisionStatus = !report.complete_for_decision
    ? 'Complete data coverage · no protocol winner'
    : report.recommended_strategy === 'no_clear_winner'
      ? 'Complete coverage · protocol rule selected no clear winner'
      : `Complete coverage · protocol rule selects ${CANONICAL_STRATEGIES.find(([id]) => id === report.recommended_strategy)?.[1] ?? report.recommended_strategy}`;
  const fourStrategyExpected = [`${report.case_count} LongMemEval cases`, `${report.total_target_answers} target answers and ${report.total_usable_grades} usable grades`, decisionStatus];
  for (const [id, label] of CANONICAL_STRATEGIES) {
    const result = report.strategies.find(row => row.id === id);
    for (const repeat of [...result.per_repetition].sort((a, b) => a.repetition - b.repetition)) {
      fourStrategyExpected.push(`R${repeat.repetition} ${repeat.correct}/${repeat.total}`);
    }
  }
  requireSlideValues(finalRecords, 8, fourStrategyExpected, 'Four-strategy v7');
  const relationship = dashboard.proposal_b.policies.find(row => row.id === 'strong_rule_based');
  const score = Number(relationship.macro_accuracy_percent).toFixed(2);
  requireSlideValues(finalRecords, 5, [
    'Four-dimension macro average', `${score}%`,
    `Separate outcome tally: ${relationship.passes} pass, ${relationship.failures} fail, ${relationship.uncertain} uncertain (${relationship.passes + relationship.failures + relationship.uncertain} answers)`,
  ], 'Proposal B');
  if (/\b\d+\s*\/\s*36\b/.test(slideText(finalRecords, 5))) fail('Proposal B must not present the four-dimension macro score as a 36-answer fraction.');
  const fourStrategySlideNotes = presentation.slides.getItem(8).speakerNotes?.text ?? '';
  if (!fourStrategySlideNotes.includes('same 30 cases') || !fourStrategySlideNotes.includes('do not establish Auditor accuracy')) fail('The new four-strategy slide is missing its repeated-case or interpretation note.');

  const expectedSlideCount = 13;
  if (presentation.slides.items.length !== expectedSlideCount) fail('The updated presentation does not contain exactly 13 slides.');
  if (sha256(await fs.readFile(args.source)) !== sourceDeckHash) fail('The preserved v19 source changed while preparing v20.');
  for (let index = 0; index < originalSlides.length; index += 1) {
    const after = originalSlides[index].speakerNotes?.text ?? '';
    if (after !== expectedNotes[index]) fail(`Speaker notes unexpectedly changed for original slide ${index + 1}.`);
  }

  const { finalizePresentation } = await import(pathToFileURL(path.join(SKILL_DIR, 'container_tools/artifact_tool_utils.mjs')).href);
  const candidatePath = path.join(args.staging, 'candidate-v20.pptx');
  await fs.mkdir(args.staging, { recursive: true });
  await saveBlob(candidatePath, await PresentationFile.exportPptx(presentation));
  const result = await finalizePresentation({
    explicitTotalSlideCount: expectedSlideCount,
    workspaceDir: REPO,
    candidatePath,
    finalPath: args.output,
    sourceTemplatePath: args.source,
  requiredTemplateReferenceSlides: [1, 6, 7, 8, 9, 12],
  minimumTemplateCoverageRatio: 0.9,
    requiredNativeChartOwnerSlides: [9],
    nativeChartTargetApplication: 'powerpoint',
    materializeLiteralChartWorkbooks: true,
    pythonExecutable: '/Users/y/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3',
    integrityValidatorPath: path.join(SKILL_DIR, 'container_tools/inspect_presentation_package_integrity.py'),
    layoutValidatorPath: path.join(SKILL_DIR, 'container_tools/inspect_presentation_layout_geometry.py'),
    layoutArgs: ['--expected-slide-size-emu', '12192000,6858000', '--validate-bullet-geometry', '--validate-heading-fit'],
    fontPolicy: { basis: 'reference', families: ['Arial'], referencePath: args.source, referenceSha256: sourceDeckHash },
    verifyArtifactToolImport: true,
    receiptPath: path.join(args.staging, 'v20.validation.json'),
  });

  const finalDeck = await PresentationFile.importPptx(await FileBlob.load(args.output));
  if (finalDeck.slides.items.length !== expectedSlideCount) fail('The finalized PowerPoint has an unexpected slide count.');
  validateNativeFourStrategyChart(finalDeck.slides.getItem(8).charts?.items?.[0], report, 'Final PPTX');
  for (let index = 0; index < originalSlides.length; index += 1) {
    const actual = finalDeck.slides.getItem(index < 8 ? index : index + 1).speakerNotes?.text ?? '';
    if (!actual.trim()) fail(`The final PowerPoint lost original speaker notes for source slide ${index + 1}.`);
  }
  const finalNotes = finalDeck.slides.getItem(8).speakerNotes?.text ?? '';
  if (!finalNotes.includes('Speaker 3 | Slide 9 — Four-strategy retrieval comparison')) fail('The new four-strategy speaker notes did not survive export.');
  const finalBNotes = finalDeck.slides.getItem(5).speakerNotes?.text ?? '';
  if (!finalBNotes.includes('unweighted four-dimension macro average') || !finalBNotes.includes('do not read the macro score as a pass fraction')) fail('Proposal B macro-average clarification did not survive export.');
  if (sha256(await fs.readFile(args.source)) !== sourceDeckHash) fail('The preserved v19 source hash changed during finalization.');

  const manifest = {
    format: 'presentation-v20-build-inputs-v1',
    source_deck: { path: path.relative(REPO, args.source), sha256: sourceDeckHash },
    dashboard_abc: { path: path.relative(REPO, args.dashboard), sha256: dashboardHash, format: dashboard.format, generated_at: dashboard.generated_at },
    four_strategy: { path: path.relative(REPO, args.fourStrategy), sha256: fourStrategyHash, format: report.format, protocol_sha256: report.protocol_sha256, run_sha256: report.run_sha256 },
    output_deck: path.relative(REPO, args.output),
    finalizer: result,
  };
  await fs.writeFile(path.join(args.staging, 'v20-build-inputs.json'), JSON.stringify(manifest, null, 2));
  console.log(JSON.stringify({ status: 'built', output: args.output, slideCount: expectedSlideCount, validation: result }, null, 2));
}

main().catch(error => {
  console.error(error?.stack || error?.message || String(error));
  process.exitCode = 1;
});
