import fs from "node:fs/promises";
import { FileBlob, PresentationFile } from "@oai/artifact-tool";

const deckPath = "../output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v13.pptx";
const outDir = "./v13-final-render";
await fs.mkdir(outDir, { recursive: true });
const presentation = await PresentationFile.importPptx(await FileBlob.load(deckPath));
for (const [index, slide] of presentation.slides.items.entries()) {
  const png = await presentation.export({ slide, format: "png", scale: 1 });
  await fs.writeFile(`${outDir}/slide-${index + 1}.png`, new Uint8Array(await png.arrayBuffer()));
}
const inspect = await presentation.inspect({ kind: "slide,notes", maxChars: 30000 });
await fs.writeFile(`${outDir}/slides-and-notes.ndjson`, inspect.ndjson);
const montage = await presentation.export({ format: "webp", montage: true, scale: 0.5 });
await fs.writeFile(`${outDir}/montage.webp`, new Uint8Array(await montage.arrayBuffer()));
console.log(JSON.stringify({
  slides: presentation.slides.items.length,
  rendered: presentation.slides.items.length,
  notesOnUpdatedSlides: [3, 6, 7, 10].map(index => ({slide: index + 1, length: presentation.slides.getItem(index).speakerNotes.text.length})),
}, null, 2));
