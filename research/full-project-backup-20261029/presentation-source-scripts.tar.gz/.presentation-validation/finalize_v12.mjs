import path from "node:path";
import { pathToFileURL } from "node:url";
import { createHash } from "node:crypto";

const skillDir = "/Users/y/.codex/plugins/cache/openai-primary-runtime/presentations/26.1020.11618/skills/presentations";
const workspaceDir = "/Users/y/Documents/26-S2/5623/AI Memory Health Auditor";
const sourceTemplatePath = path.join(workspaceDir, "output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v11.pptx");
const finalPath = path.join(workspaceDir, "output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v13.pptx");
const candidatePath = path.join(workspaceDir, ".presentation-validation/v12-build/candidate.pptx");
const receiptPath = path.join(workspaceDir, ".presentation-validation/v12-build/validation-v13.json");
process.env.RUNTIME_NODE_MODULES = "/Users/y/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules";
const bytes = await (await import("node:fs/promises")).readFile(sourceTemplatePath);
const sourceSha256 = createHash("sha256").update(bytes).digest("hex");
const { finalizePresentation } = await import(pathToFileURL(path.join(skillDir, "container_tools/artifact_tool_utils.mjs")).href);

const result = await finalizePresentation({
  workspaceDir,
  candidatePath,
  finalPath,
  pythonExecutable: "/Users/y/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3",
  integrityValidatorPath: path.join(skillDir, "container_tools/inspect_presentation_package_integrity.py"),
  layoutValidatorPath: path.join(skillDir, "container_tools/inspect_presentation_layout_geometry.py"),
  layoutArgs: ["--expected-slide-size-emu", "12192000,6858000", "--validate-heading-fit", "--cover-role", "cover"],
  explicitTotalSlideCount: 12,
  fontPolicy: { basis: "reference", families: ["Arial"], referencePath: sourceTemplatePath, referenceSha256: sourceSha256 },
  verifyArtifactToolImport: true,
  receiptPath,
});
console.log(JSON.stringify({
  finalPath: result.finalPath,
  sha256: result.finalSha256,
  bytes: result.byteCount,
  packageIntegrity: result.packageIntegrity?.passed,
  presentationLayout: result.presentationLayout?.passed,
  firstPartyImport: result.firstPartyImport?.passed,
  receiptPath: result.receiptPath,
}, null, 2));
