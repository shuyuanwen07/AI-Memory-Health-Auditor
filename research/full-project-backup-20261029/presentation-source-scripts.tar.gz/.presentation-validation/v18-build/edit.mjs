import fs from 'node:fs/promises';
import path from 'node:path';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';

const workspace = '/Users/y/Documents/26-S2/5623/AI Memory Health Auditor';
const source = path.join(workspace, 'output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v17.pptx');
const buildDir = path.join(workspace, '.presentation-validation/v18-build');
const candidate = path.join(buildDir, 'candidate.pptx');
const deck = await PresentationFile.importPptx(await FileBlob.load(source));

function replaceText(id, expected, replacement) {
  const target = deck.resolve(id);
  if (!target?.text) throw new Error(`Missing text object ${id}`);
  target.text.replace(expected, replacement);
}

function setNotes(id, text) {
  const target = deck.resolve(id);
  if (!target || !('text' in target)) throw new Error(`Missing notes object ${id}`);
  target.text = text;
}

async function renderSlides(directory) {
  await fs.mkdir(directory, { recursive: true });
  for (let i = 0; i < deck.slides.items.length; i++) {
    const slide = deck.slides.items[i];
    const png = await deck.export({ slide, format: 'png', scale: 1 });
    const name = `slide-${String(i + 1).padStart(2, '0')}.png`;
    await fs.writeFile(path.join(directory, name), new Uint8Array(await png.arrayBuffer()));
  }
  const montage = await deck.export({ format: 'webp', montage: true, scale: 0.45 });
  await fs.writeFile(path.join(directory, 'montage.webp'), new Uint8Array(await montage.arrayBuffer()));
}

const before = await deck.inspect({ kind: 'slide,textbox,notes', search: 'Weak', maxChars: 100000 });
await fs.writeFile(path.join(buildDir, 'before-weak.ndjson'), before.ndjson);
const beforeStrong = await deck.inspect({ kind: 'slide,textbox,notes', search: 'Strong', maxChars: 100000 });
await fs.writeFile(path.join(buildDir, 'before-strong.ndjson'), beforeStrong.ndjson);
await renderSlides(path.join(buildDir, 'render-before'));

// Slide 6: show the two selection mechanisms without ranking language in the labels.
replaceText('sh/yhg7epsj', 'B · Strong scored higher as expected', 'B · Comparing two retrieval policies');
replaceText('sh/7m98ru9g', 'Weak', 'First-match');
replaceText('sh/w32twb6l', 'Strong', 'Rule-based');
replaceText('sh/j6dcr65c', 'Strong by repeat', 'Rule-based by repeat');
replaceText('sh/qpwnet0b', 'Expected control direction: Strong > Weak. This tests target-policy separation, not Auditor accuracy; labels are retrospective and cases are related.', 'Positive control: the policies should separate on target cases. This tests policy separation, not Auditor accuracy; labels are retrospective and cases are related.');

// Archived C: make the table labels describe the retrieval method.
replaceText('sh/7m98ru9g', 'First-match', 'First-match');
replaceText('sh/l0vuh0rm', 'Weak', 'First-match');
replaceText('sh/a9ojq5kz', 'Strong', 'Rule-based');
replaceText('sh/p8fih03e', 'Strong > Weak in all 3 repeats  ·  3 / 3', 'Same ordering across all 3 repeats  ·  3 / 3');

// Expanded C: retain the values and direction while naming each retrieval policy.
replaceText('sh/sjix0zy1', 'Weak · first-hit memory', 'First-match retrieval');
replaceText('sh/98rehwve', 'Strong · task and update focus', 'Contextual rule-based retrieval');
replaceText('sh/ehgvihwr', 'Expected order reproduced · Strong led in 3/3 repeats', 'Same ordering across all 3 repeats · 3/3');
replaceText('sh/zipwbmdc', 'Strong 61/90 vs Weak 19/90 · +46.7 percentage points', 'Contextual rule-based 61/90 vs First-match 19/90 · +46.7 percentage points');
replaceText('sh/kfixwbe1', 'Gaps: multi-session 0/15 for both; temporal Strong 5/15 (33%). Mean latency 6.80s vs 4.04s; Strong used 2.3× input tokens.\nEstimated total cost US$0.178; 180/180 usable grades. Human review pending; target and grader share the GPT-6 Luna family. This is not a full benchmark score or Auditor accuracy claim.', 'Gaps: both policies scored 0/15 on multi-session; contextual rule-based scored 5/15 (33%) on temporal reasoning. Mean latency was 6.80s vs 4.04s; contextual rule-based used 2.3× input tokens.\nEstimated total cost US$0.178; 180/180 usable grades. Human review pending; target and grader share the GPT-6 Luna family. This is not a full benchmark score or Auditor accuracy claim.');

// Conclusion slide: use the strategy names in its one-line recap.
replaceText('sh/0nap8f6l', 'Separate 6-run check: Strong passed 15/24 vs Weak 3/24; automatic scores, one history, no human gold.', 'Separate 6-run check: contextual rule-based passed 15/24 vs first-match 3/24; automatic scores, one history, no human gold.');

setNotes('nt/jyx0ra1s', `Speaker 2 | Slide 4 — Experimental map\nSegment timing: 2:30\n\nExperiment A is the primary Auditor-method test: it compares contextual tests with direct questions and fixed templates under equal budgets. B and C are supporting target-memory controls. They compare first-match retrieval with contextual rule-based retrieval, which prioritises contextual requirements and updates. The two policies use different selection rules, so the anticipated ordering follows from the control design. B checks whether target scores separate these policies; C checks whether the same ordering appears on new LongMemEval cases. Neither result proves Auditor accuracy or practical value. The datasets and measures remain separate. The repair loop is supplementary, not the proposal's main comparison.\n\nPresenter references / live evidence:\nSources: proposal §§5.3, 7.2–7.5; experiment report §5; LongMemEval, Wu et al. (2025), https://openreview.net/forum?id=pZiyCaVuti.`);

setNotes('nt/x8f69ofe', `Speaker 2 | Slide 6 — Experiment B\n\nTreat B as a positive control. Contextual rule-based retrieval was designed to retain task- and update-relevant memory, while first-match retrieval uses the first matching memory. A higher score for the contextual rule-based policy was expected from these policy designs. It scored 97.22 percent versus 25 percent, with the same ordering across all three repeats. This shows that the target policies separated in these related cases. It does not show that the Auditor can find real errors: these are target-performance scores, and the labels were reviewed retrospectively. The central method claim still depends on A and independent outcome labels, which are not yet established. Speaker 3 will show the separate ranking check and tutor repair demo.\n\nHandoff: Speaker 3`);

setNotes('nt/gnmp4jqx', `Speaker 3 | Slide 7 — Experiment C\nSegment timing: 2:30\n\nArchived C checks whether the same retrieval-policy ordering also appears in a LongMemEval subset. Contextual rule-based retrieval scored 30/42 and first-match retrieval 15/42, with the same ordering in all three repeats. Since the two policies deliberately use different memory-selection rules, this is a local control check, not evidence of Auditor accuracy. It covers 14 of 500 Oracle cases and uses a GPT-4o compatibility grader, so it is not a full benchmark result. The later v5/v6 collections are separate.`);

setNotes('nt/fu1gfa1s', `Speaker 3 | Slide 8 — The first policy comparison\n\nExpanded C asks whether the same retrieval-policy ordering holds on 30 new cases. Contextual rule-based retrieval scored 61/90 versus 19/90 for first-match retrieval and ranked higher in all three repeats. The frozen rule therefore selected the contextual rule-based policy, while the ordering remains a target-policy result rather than evidence of Auditor effectiveness or an official benchmark score. The 180 answers cover 30 histories; human review is pending, and target and grader share the GPT-6 Luna family. Category gaps remain: both policies scored 0/15 on multi-session questions, while contextual rule-based retrieval scored 5/15 on temporal reasoning. Contextual rule-based retrieval averaged 6.80s versus 4.04s and used 2.3 times the input tokens; estimated total cost was US$0.178. The combined v5/v6 result is secondary.\n\nPresenter references / live evidence:\nSource: frozen v6 protocol and analysis in artifacts/local/phase4-c-openrouter-20261028-v6; official benchmark citation: Wu et al. (2025), LongMemEval, ICLR, https://openreview.net/forum?id=pZiyCaVuti. The aggregate-only comparison is visible at http://localhost:5173/expanded-c.`);

setNotes('nt/jetc3ut0', `Speaker 4 | Slide 11 — Proposal and rubric status\n\nAgainst the proposal and rubric, AC1 is not established; AC2 is partial, with 13/48 test-validity decisions unresolved; AC3 is not achieved without a frozen threshold and independent blind labels. AC4 has verified run/export paths, but the separate intake's 14 candidates still await operator review and have no target runs. AC5 has only a local expected-order check: B/C show that contextual rule-based retrieval scores higher in these target-memory cases, not that the Auditor finds failures. Broader cases and independent human grades remain needed. The 216-item A/B return was AI-assisted and result-exposed. Release permissions and member contribution confirmations remain for the team to review; proposal role assignments are planned, not verified work.\n\nPresenter references / live evidence:\nSources: proposal §9 Table 11; rubric criteria 1–7; experiment report §5–7; human review handoff.`);

setNotes('nt/8f2psfyx', `Speaker 4 | Slide 12 — Research conclusion and live evidence\n\nThe current evidence does not yet establish the primary Auditor claim. In A, 27 of 27 decided failure labels were detected, but six answers remain uncertain and formal method superiority and distinct-defect discovery are not measured. B/C reproduce the ordering of deliberately different target-memory policies; this checks target-condition separation, not the Auditor's ability to detect failures. Independent held-out human labels and a frozen threshold are still needed to validate the Auditor.\n\nThe separate current-source six-run comparison produced 48 saved answers and reconciled JSON/CSV records with no failed requests. Contextual rule-based retrieval passed 15/24 and first-match retrieval 3/24, but this used one synthetic history and automatic labels without human gold. It supports execution and target-policy separation, not semantic validity. The repair demo on slide 9 is also exploratory.\n\nThe conclusion is therefore: the prototype can run and trace controlled memory comparisons, but the central research claim remains open pending independent blind review and a frozen held-out evaluation.\n\nClose the presentation.\n\nPresenter references / live evidence:\nCurrent-source group EXP77CB1B845E75465ABDF7C8FC986113E4; experiment report §§5–7; proposal §7.`);

await renderSlides(path.join(buildDir, 'render-after'));
const inspection = await deck.inspect({ kind: 'slide,textbox,notes', maxChars: 1000000 });
await fs.writeFile(path.join(buildDir, 'inspect-after.ndjson'), inspection.ndjson);
const pptx = await PresentationFile.exportPptx(deck);
await pptx.save(candidate);
console.log(`Exported ${deck.slides.items.length} slides to ${candidate}`);
