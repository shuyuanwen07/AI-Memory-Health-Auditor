import { FileBlob, PresentationFile } from '@oai/artifact-tool';
const p=await PresentationFile.importPptx(await FileBlob.load('output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v3.pptx'));
for (const n of [1,2,10,11]) {
 const s=p.slides.getItem(n);
 console.log('\nSLIDE',n+1,'name',s.name,'slide attrs',Object.keys(s));
 console.log('shapes collection',Object.keys(s.shapes),'count',s.shapes.items?.length);
 for (const sh of s.shapes.items??[]) console.log(JSON.stringify({id:sh.id,name:sh.name,geometry:sh.geometry,position:sh.position,text:sh.text?.toString?.(),textObj:sh.text,style:sh.text?.style}));
}
