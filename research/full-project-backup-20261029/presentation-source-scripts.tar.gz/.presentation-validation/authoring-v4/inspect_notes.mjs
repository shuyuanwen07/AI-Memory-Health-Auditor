import { FileBlob, PresentationFile } from '@oai/artifact-tool';
const p=await PresentationFile.importPptx(await FileBlob.load('output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v3.pptx'));
for (const q of ['Speaker: Speaker 1','Speaker: Speaker 4','GenAI']) {
 const x=await p.inspect({kind:'notes,slide,textbox',search:q,maxChars:8000});
 console.log('\n',q, x.ndjson);
}
