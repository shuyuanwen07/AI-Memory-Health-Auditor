import fs from 'node:fs/promises';import path from 'node:path';import {FileBlob,PresentationFile} from '@oai/artifact-tool';import {pathToFileURL} from 'node:url';
const workspaceDir=process.cwd(),skillDir='/Users/y/.codex/plugins/cache/openai-primary-runtime/presentations/26.1020.11618/skills/presentations';
const source=path.join(workspaceDir,'output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v5.pptx');
const candidatePath=path.join(workspaceDir,'.presentation-validation/authoring-v4/candidate-v6.pptx');
const finalPath=path.join(workspaceDir,'output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v6.pptx');
const receiptPath=path.join(workspaceDir,'.presentation-validation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v6.validation.json');
const p=await PresentationFile.importPptx(await FileBlob.load(source));
function replace(i,a,b){const s=p.slides.getItem(i).shapes.items.find(x=>x.text?.toString()===a);if(!s)throw Error(`Missing ${a}`);s.text.replace(a,b)}
replace(3,'Audit-method baseline','Equal-budget methods');
replace(5,'Same model, histories, tests + budget · 72 answers · 3 repeats','Held fixed: model · histories · tests · budget · evaluator · 72 answers · 3 repeats');
await fs.mkdir(path.dirname(candidatePath),{recursive:true});await fs.mkdir(path.dirname(finalPath),{recursive:true});
await (await PresentationFile.exportPptx(p)).save(candidatePath);
const {finalizePresentation}=await import(pathToFileURL(path.join(skillDir,'container_tools/artifact_tool_utils.mjs')).href);
console.log(JSON.stringify(await finalizePresentation({workspaceDir,candidatePath,finalPath,explicitTotalSlideCount:12,requiredNativeTableOwnerSlides:[],expectedSlideSizeEmu:'12192000,6858000',fontPolicy:{basis:'design',families:['Arial']},pythonExecutable:'/Users/y/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3',integrityValidatorPath:path.join(skillDir,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(skillDir,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit'],verifyArtifactToolImport:true,receiptPath}),null,2));
