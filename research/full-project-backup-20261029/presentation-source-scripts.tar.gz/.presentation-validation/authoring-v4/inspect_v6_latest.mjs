import {FileBlob,PresentationFile} from '@oai/artifact-tool';
const p=await PresentationFile.importPptx(await FileBlob.load('output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v6.pptx'));
for(const i of [7,8,10,11]){
 console.log('\nSLIDE',i+1);
 for(const s of p.slides.getItem(i).shapes.items){const t=s.text?.toString();if(t)console.log(JSON.stringify(t))}
}
console.log('\nNOTES');console.log((await p.inspect({kind:'notes',search:'Speaker:',maxChars:20000})).ndjson);
