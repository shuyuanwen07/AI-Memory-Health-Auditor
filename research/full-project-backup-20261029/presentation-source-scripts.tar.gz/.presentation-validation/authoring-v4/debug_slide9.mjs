import {FileBlob,PresentationFile} from '@oai/artifact-tool';
const p=await PresentationFile.importPptx(await FileBlob.load('output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v10.pptx'));
for(const s of p.slides.getItem(8).shapes.items) console.log(JSON.stringify({id:s.id,text:s.text?.toString(),geometry:s.geometry,position:s.position,fill:s.fill,name:s.name}));
