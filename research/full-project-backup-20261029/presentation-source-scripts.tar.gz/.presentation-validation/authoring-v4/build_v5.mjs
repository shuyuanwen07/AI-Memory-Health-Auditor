import fs from 'node:fs/promises';
import path from 'node:path';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';
import { pathToFileURL } from 'node:url';
const workspaceDir=process.cwd();
const skillDir='/Users/y/.codex/plugins/cache/openai-primary-runtime/presentations/26.1020.11618/skills/presentations';
const source=path.join(workspaceDir,'output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v4.pptx');
const candidatePath=path.join(workspaceDir,'.presentation-validation/authoring-v4/candidate-v5.pptx');
const finalPath=path.join(workspaceDir,'output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v5.pptx');
const receiptPath=path.join(workspaceDir,'.presentation-validation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v5.validation.json');
const p=await PresentationFile.importPptx(await FileBlob.load(source));
function replace(slideIndex,oldText,newText){
 const sh=p.slides.getItem(slideIndex).shapes.items.find(s=>s.text?.toString()===oldText);
 if(!sh) throw new Error(`Missing slide ${slideIndex+1} shape text ${oldText}`);
 sh.text.replace(oldText,newText);
}
replace(3,'3 histories × 3 methods\n× 4 questions','3 histories × 3 equal-budget arms\n× 4 questions');
replace(5,'72 canonical answers · 3 related histories · 3 repeats','Same model, histories, tests + budget · 72 answers · 3 repeats');
const check=await p.inspect({kind:'slide,textbox,notes',search:'equal-budget',maxChars:3000});
console.log(check.ndjson);
await fs.mkdir(path.dirname(candidatePath),{recursive:true}); await fs.mkdir(path.dirname(finalPath),{recursive:true});
await (await PresentationFile.exportPptx(p)).save(candidatePath);
const {finalizePresentation}=await import(pathToFileURL(path.join(skillDir,'container_tools/artifact_tool_utils.mjs')).href);
const result=await finalizePresentation({workspaceDir,candidatePath,finalPath,explicitTotalSlideCount:12,requiredNativeTableOwnerSlides:[],expectedSlideSizeEmu:'12192000,6858000',fontPolicy:{basis:'design',families:['Arial']},pythonExecutable:'/Users/y/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3',integrityValidatorPath:path.join(skillDir,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(skillDir,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit'],verifyArtifactToolImport:true,receiptPath});
console.log(JSON.stringify(result,null,2));
