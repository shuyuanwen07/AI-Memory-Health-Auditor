import fs from 'node:fs/promises';
import path from 'node:path';
import { FileBlob, PresentationFile } from '@oai/artifact-tool';
import { pathToFileURL } from 'node:url';

const workspaceDir = process.cwd();
const skillDir = '/Users/y/.codex/plugins/cache/openai-primary-runtime/presentations/26.1020.11618/skills/presentations';
const source = path.join(workspaceDir, 'output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v3.pptx');
const candidatePath = path.join(workspaceDir, '.presentation-validation/authoring-v4/candidate.pptx');
const finalPath = path.join(workspaceDir, 'output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v4.pptx');
const receiptPath = path.join(workspaceDir, '.presentation-validation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v4.validation.json');
const presentation = await PresentationFile.importPptx(await FileBlob.load(source));
function shapeByText(slideIndex, oldText) {
  const slide = presentation.slides.getItem(slideIndex);
  const shape = slide.shapes.items.find(s => s.text?.toString() === oldText);
  if (!shape) throw new Error(`Could not find slide ${slideIndex+1} text: ${oldText}`);
  return shape;
}
function setText(slideIndex, oldText, newText) {
  const shape = shapeByText(slideIndex, oldText);
  shape.text.replace(oldText, newText);
}
function replacePosition(slideIndex, oldText, position) {
  const shape = shapeByText(slideIndex, oldText);
  shape.position = position;
  return shape;
}

// Slide 2: place prior work next to the bounded contribution.
setText(1, 'Why audit AI memory?', 'Related work and the project contribution');
setText(1, 'A fluent answer can still use the wrong memory.', 'A personal audit builds on existing memory tests.');
setText(1, 'The failure may be stale, conflicting, or outside the task’s scope.', 'Benchmarks use defined tasks; Zep and Mem0 offer developer-focused evaluation.');
setText(1, 'Accuracy', 'Benchmarks');
setText(1, 'Is the remembered fact correct?', 'LongMemEval · LoCoMo · BEAM');
setText(1, 'Freshness', 'Zep');
setText(1, 'Did a later update replace it?', 'Custom data · run comparison');
setText(1, 'Conflict resolution', 'Mem0');
setText(1, 'Should the system surface disagreement?', 'User data · benchmark runners');
setText(1, 'Appropriate use', 'Our contribution');
setText(1, 'Does the fact belong to this task or project?', 'Confirmed facts → contextual tests');
setText(1, 'Research question', 'Contribution');
setText(1, 'Can a source-backed Auditor detect, explain, and help improve memory behaviour?', 'User-confirmed ground truth → adaptive tests → traceable diagnosis.');
setText(1, 'Source: Experiment Report, §§ Context and workflow', 'Sources: Wu et al. (2025) · Maharana et al. (2024) · Tavakoli et al. (2026) · Rasmussen et al. (2025) · Chhikara et al. (2025)');

// Slide 3: make the Auditor, controlled target, and evaluator boundaries explicit.
setText(2, 'The Auditor turns source conversations into testable evidence', 'System architecture: Auditor, target and evaluator');
setText(2, 'Authorised\nhistory', 'Source\nhistory');
setText(2, 'Source messages', 'Authorised input');
setText(2, 'Confirmed\nfacts', 'Extract\nmemories');
setText(2, 'Operator checks', 'GPT-6 Luna');
setText(2, 'Frozen\ntests', 'Operator\nreview');
setText(2, 'Four abilities', 'Confirmed facts');
setText(2, 'Controlled\nmemory', 'Generate\ntests');
setText(2, 'Target setting', 'LLM + grounding');
setText(2, 'Answer +\nassessment', 'Target AI\nmemory');
setText(2, 'Uncertainty kept', 'Scoped policy');
setText(2, 'Evidence\nreport', 'Assess +\nreport');
setText(2, 'Receipts + export', 'Rules + LLM');
setText(2, 'Every answer can be inspected against the memory evidence supplied at answer time.', 'Why GenAI: interpret dialogue, generate contextual tests and assess open answers.');
setText(2, 'React interface', 'React · audit interface');
setText(2, 'FastAPI service', 'FastAPI · orchestration');
setText(2, 'PostgreSQL evidence store', 'PostgreSQL · evidence store');
setText(2, 'Four audit dimensions', 'Four audit dimensions');
setText(2, 'Accuracy  ·  Freshness  ·  Conflict Resolution  ·  Appropriate Use', 'Accuracy  ·  Freshness  ·  Conflict Resolution  ·  Appropriate Use');
setText(2, 'Source: Experiment Report, §1 System and experimental workflow', 'Sources: proposal §§4.3–5.4; experiment report §1');

const architecture = presentation.slides.getItem(2);
for (const [name, left, width, label] of [
  ['auditor-boundary', 74, 742, 'AUDITOR WORKFLOW'],
  ['target-boundary', 842, 166, 'CONTROLLED TARGET'],
  ['evaluator-boundary', 1034, 166, 'EVALUATOR'],
]) {
  const header = architecture.shapes.add({
    geometry: 'textbox', name,
    position: { left, top: 164, width, height: 24 },
    fill: 'none',
    line: { style: 'solid', fill: 'none', width: 0 },
  });
  header.text = label;
  header.text.style = { fontSize: 12, typeface: 'Arial', color: '#008C95', bold: true, alignment: 'center' };
}

const notes2 = presentation.resolve('nt/hwbqtkby');
notes2.text = `Speaker: Speaker 1\nCue: Compare the work before stating the contribution. LongMemEval (Wu et al., 2025), LoCoMo (Maharana et al., 2024), and BEAM (Tavakoli et al., 2026) study long-term memory capabilities using benchmark-defined scenarios. Zep supports custom-data evaluation and run comparison; Mem0 supports user-data evaluation and benchmark runners. The proposal describes both reviewed product workflows as primarily developer-oriented. Do not claim that existing products cannot evaluate memory. The project contribution is a user-authorised, human-confirmed ground-truth workflow that generates adaptive contextual/indirect tests and preserves diagnosis evidence. The four measured abilities are shown on slide 3.\nSources: proposal §§1, 2, 4.4; LongMemEval (Wu et al., 2025), ICLR; LoCoMo (Maharana et al., 2024), ACL; BEAM (Tavakoli et al., 2026), ICLR; Zep (Rasmussen et al., 2025), arXiv:2501.13956; Mem0 (Chhikara et al., 2025), ECAI 2025, pp. 2993–3000.`;
notes2.setVisible(true);
const notes3 = presentation.resolve('nt/ofy9wn61');
notes3.text = `Speaker: Speaker 1\nCue: Walk left to right and name the three architecture boundaries: the Auditor workflow (React UI and FastAPI orchestration), the controlled target (scoped memory store and fixed API model), and the evaluator/report. In the current live demonstrations, OpenRouter openai/gpt-6-luna supplied the target and intake agent roles. The extraction prompt follows a structured memory schema and attaches source evidence; a human operator confirms facts before they become test ground truth. The test-generation agent conditions prompts and expected behaviour on confirmed facts and a selected dimension, with grounding checks. The target connector holds the model and test conditions constant while changing the memory policy. The evaluator prefers deterministic rules for exact checks and uses a rubric LLM for semantic answers; disagreement remains Uncertain. GenAI is justified for unstructured conversation, contextual test variation, and open-ended responses. Schemas, source citations, grounding gates, and exact rules bound it. The post-fix intake run confirms that roles completed on one synthetic case, not that candidate memories are correct.\nSources: proposal §§4.3, 5.1, 5.3–5.4; experiment report §1; output/proposal-delivery/live-extraction-retest-2026-10-28/receipt-summary.json`;
notes3.setVisible(true);

// Slide 6: make the control conditions and held-constant setup explicit.
const notes6 = presentation.resolve('nt/x8f69ofe');
if (notes6) {
  notes6.text = `Speaker: Speaker 2\nCue: State the controlled comparison and keep target performance separate from Auditor accuracy. Weak and Strong use the same base model, histories, frozen questions, test budget, and evaluation procedure; retrieval/update policy is the intended difference. B has 72 canonical answers across three related synthetic histories and three repeats. The rule-evaluator macro scores are 25.00% and 97.22%; repeat-level Strong scores are 100%, 100%, and 91.67%. These are exploratory target-memory results with retrospective references, not an independent estimate of Auditor performance.`;
  notes6.setVisible(true);
}

// Slide 11: replace broad rubric praise with observed status and true remaining gates.
setText(10, 'Rubric strengths: prototype, GenAI design, Track B fit, usable workflow. One complete 216-item human review arrived, but it was AI-assisted and result-exposed. Priorities: independent evaluation, related-work link, release freeze, permissions, and team contributions.', 'Track B: tests controlled AI memory, beyond a generic chatbot. Source archive assembled; release permissions and member contribution confirmations remain pending. The 216-item review was AI-assisted and result-exposed, not independent.');
setText(10, 'Source: Experiment Report, §5 Proposal acceptance criteria; ELEC5623 rubric', 'Sources: experiment report §5; proposal §9; rubric criteria 1–7');
const notes11 = presentation.resolve('nt/jetc3ut0');
notes11.text = `Speaker: Speaker 4\nCue: Report status against the approved criteria and distinguish the complete AI-assisted return from independent validation. AC1 is not established; AC2 partly evidenced; AC3 not achieved; AC4 partly verified; AC5 partly evidenced. The 1,800-token extraction failure remains in the evidence. A separate post-fix synthetic conversation with 14 source user messages completed all three intake roles and raised two advisory items, but its 14 candidates await operator review and no target tests ran. The assessed-source archive is assembled and has a file manifest, but it represents a modified working tree; final release freeze and permission confirmation remain open.\nThe proposal assigns Shuyuan Wen to memory extraction, ground truth and database; Chongtai Jia to test generation and the target connector; Leardngammongkolkul Chayapat to evaluation and baselines; and Yichao Wang to frontend and dashboard. These are planned proposal responsibilities, not verified records of completed individual work. Each member must confirm their own contribution. The 216-item review return is AI-assisted and result-exposed, so it cannot count as an independent blind review.\nSources: proposal §9, Table 11; docs/proposal-delivery/MEMBER_CONTRIBUTIONS.md; docs/proposal-delivery/MANUAL_REVIEW_HANDOFF.md; docs/EXPERIMENT_REPORT_2026-10-28.md, §§5–7; ELEC5623 rubric criteria 1–7`;
notes11.setVisible(true);

const notes12 = presentation.resolve('nt/8f2psfyx');
notes12.text = `Speaker: Speaker 4\nCue: Close with the bounded value claim and show where the audience can inspect the actual saved result. The tutor-loop targeted retrieval condition passed 9 of 9 decided answers; three of twelve candidate answers remain uncertain, and the paired groups reuse one synthetic history. The post-fix intake completed the three agent roles but stops before operator review or target tests. This supports practical diagnostic value in a small case, not general Auditor validity. Open Experiments for the saved comparison and New audit for the 14 candidate memories awaiting review. The reliability page still records no independent adjudications.\nSources: experiment report §§3, 6–8; http://localhost:5173/experiments; http://localhost:5173/new-audit; http://localhost:5173/quality`;
notes12.setVisible(true);

// Make sure every result claim is still grounded in the stated evidence and export a candidate.
const review = await presentation.inspect({ kind: 'slide,textbox,notes', maxChars: 30000 });
console.log(review.ndjson.slice(0,12000));
await fs.mkdir(path.dirname(candidatePath), { recursive: true });
await fs.mkdir(path.dirname(finalPath), { recursive: true });
const out = await PresentationFile.exportPptx(presentation);
await out.save(candidatePath);
const { finalizePresentation } = await import(pathToFileURL(path.join(skillDir, 'container_tools/artifact_tool_utils.mjs')).href);
const result = await finalizePresentation({
  workspaceDir,
  candidatePath,
  finalPath,
  explicitTotalSlideCount: 12,
  requiredNativeTableOwnerSlides: [],
  expectedSlideSizeEmu: '12192000,6858000',
  fontPolicy: { basis: 'design', families: ['Arial'] },
  pythonExecutable: '/Users/y/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3',
  integrityValidatorPath: path.join(skillDir, 'container_tools/inspect_presentation_package_integrity.py'),
  layoutValidatorPath: path.join(skillDir, 'container_tools/inspect_presentation_layout_geometry.py'),
  layoutArgs: ['--expected-slide-size-emu', '12192000,6858000', '--validate-bullet-geometry', '--validate-heading-fit'],
  verifyArtifactToolImport: true,
  receiptPath,
});
console.log(JSON.stringify(result, null, 2));
