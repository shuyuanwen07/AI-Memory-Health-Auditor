import {FileBlob,PresentationFile} from '@oai/artifact-tool';
const p=await PresentationFile.importPptx(await FileBlob.load('output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final_2026-10-28_v4.pptx'));
for (const i of [3,5]) for(const s of p.slides.getItem(i).shapes.items) if(s.text?.toString().includes('histories')||s.text?.toString().includes('canonical')) console.log(i+1,JSON.stringify(s.text.toString()));
