import { FileBlob, PresentationFile } from "@oai/artifact-tool";
const source = "../output/presentation/ELEC5623_AI_Memory_Health_Auditor_Presentation_Final.pptx";
const presentation = await PresentationFile.importPptx(await FileBlob.load(source));
const inspect = await presentation.inspect({ target: { id: "sl/y90nupkv" }, kind: "slide,textbox,shape", maxChars: 20000 });
console.log(inspect.ndjson);
