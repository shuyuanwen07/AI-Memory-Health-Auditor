# Diagnosis-led live repair loop evidence

This local evidence set contains three app-exported Repair Comparison groups for the fictional seven-message Harbour history. Each uses the same four Accuracy, Freshness, Conflict Resolution, and Appropriate Use prompt/expected-behaviour pairs. The study reused one history and repeated the same questions; the groups are correlated repeats, not independent histories.

## Results

| Condition | Decided pass | Decided fail | Awaiting review | App group/run IDs |
|---|---:|---:|---:|---|
| Original first-match baseline | 3/12 | 9/12 | 0 | See `manifest.json` |
| Generic instruction control | 3/12 | 9/12 | 0 | See `manifest.json` |
| Targeted `scope_aware` retrieval | 9/9 decided (9/12 answers) | 0 | 3/12 | See `manifest.json` |

The AI-assisted assessor left three candidate answers uncertain. All three candidate Freshness answers passed, and their answer-time memory receipts show the historical MySQL and current PostgreSQL records supplied together. A 100% score is only the 9/9 decided candidate answers; it excludes three unresolved answers and is not an independent human accuracy estimate. Target and evaluator were OpenRouter `openai/gpt-6-luna`. The saved temperature is 0.0, but the provider receipts identify `model_default` sampling; seed 42 is recorded, not proof of provider-enforced deterministic sampling.

## Contents

- `group-2026-10-27-1602.json`, `group-2026-10-27-1606.json`, `group-2026-10-27-1609.json`: full reproduction packages downloaded from the app, including frozen question sets, answers, assessments, retrieval receipts, settings, and paired comparisons.
- `manifest.json`: group/run IDs, per-condition counts, the common question-suite fingerprint, and SHA-256/byte counts for every payload file. The manifest excludes its own hash.
- `blind-review.csv` and `BLIND_REVIEW_INSTRUCTIONS.md`: 36 source-grounded answers in randomized order, without AI verdicts or original run IDs, ready for an unexposed human reviewer.
- `review-key-private.json`: local mapping back to run IDs, conditions and AI outcomes. **Do not give this file to a blind reviewer.**

For an independent review, give the reviewer only the CSV and instructions. Each item asks the reviewer to assess both question validity and answer correctness. The project team has already seen the system results; a team member's later review cannot be called an independent blind label. The independent review has not yet been completed.

The app also shows these three groups at [localhost:5173/experiments](http://localhost:5173/experiments). This evidence is separate from proposal Experiments A/B/C and from the older side-by-side memory comparison.
