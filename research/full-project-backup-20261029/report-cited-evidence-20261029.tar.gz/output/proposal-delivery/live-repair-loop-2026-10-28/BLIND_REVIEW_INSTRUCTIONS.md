# Blind source review instructions

Review `blind-review.csv` without access to the app's automated verdicts, this packet's reproduction JSON files, or `review-key-private.json`. The source is a fictional synthetic Harbour case. For every item, independently assess both: (1) whether the test's expected behaviour is supported by the source statements and confirmed evidence, and (2) whether the target answer satisfies that valid expected behaviour. Enter `valid`, `invalid`, or `uncertain` for test validity; enter `pass`, `fail`, or `uncertain` for answer correctness; if failed, enter a category only when the source supports it. Give a short source-based rationale. Do not infer an outcome from the opaque condition code.

Record reviewer identity/pseudonym, date, whether any AI assistance was used, whether automated scores or another review were seen, and whether the review was completed independently. Keep the private key out of the reviewer's materials. Preserve the returned file unchanged and add adjudications as a separate file.

The current project team has already seen the system results. A review by a team member who has seen them is useful manual validation but is not an independent blind label for the formal held-out claims. For formal independent evidence, use an unexposed reviewer and a second independent reviewer for disagreement resolution.
