# Phase 4 C v6 review packet

Give the reviewer only `blind-review.csv` and `BLIND_REVIEW_INSTRUCTIONS.md`. Keep `review-key-private.json` with the study custodian; it links blinded items to question IDs, Weak/Strong configuration, repetition, run/response IDs, and saved automatic-grader metadata.

The packet contains 180 repeated answer judgments over 30 selected LongMemEval questions (two configurations × three repetitions), not 180 independent histories. It does not make the 30-case sample statistically independent or expand the study to the full 500-case benchmark.
