# Current-source Auditor demonstration

## Saved result

The Auditor created experiment group `EXP77CB1B845E75465ABDF7C8FC986113E4` in the local app. Open [the saved group](http://localhost:5173/experiments/EXP77CB1B845E75465ABDF7C8FC986113E4) to inspect the answers, scores, uncertain judgments, evidence, and exports.

The six runs use the same confirmed synthetic conversation and frozen eight-question suite as the earlier presentation demo. No new extraction or question-generation call was used. Three runs used Weak / first-match retrieval; three used Strong / prioritise requirements and updates.

| Condition | Passed | Failed | Uncertain | Pass rate on decided answers |
|---|---:|---:|---:|---:|
| Weak | 3/24 | 16/24 | 5/24 | 3/19 (15.8%) |
| Strong | 15/24 | 4/24 | 5/24 | 15/19 (78.9%) |

Strong had more decided passes in each paired repetition. This is a repeated engineering result on one synthetic history, not 48 independent cases. Ten answers remain uncertain. The evaluations were generated automatically and have not received independent human labels.

## Source and verification

The measured backend source digest is `7d3033246fffc2d774f282f9e60c6ed6cd85848e540d75019e5764477edb567c`. It matches the 137 `backend/app/**/*.py` files in the assessed-source package. The frozen-suite fingerprint is `4bb4a2ba407a237bd090d8caf610129e669bfc67f314720c57bfc3c7cccfafb5`.

The offline verifier passed all six runs. It reconstructed 48 saved target inputs and reconciled all 48 answer/evaluation identities in both JSON and CSV. The experiment recorded 60/60 successful API workflow steps. Offline verification itself made zero model or network calls and does not establish semantic correctness or independent validation.

## Files

- `presentation-demo-report.json` — full request, run, response, evaluation, and export record.
- `experiment.bundle.json` and `experiment.csv` — app reproduction bundle and tabular export.
- `verification.json` — offline input/export/source reconciliation receipt.
- `manifest.json` — aggregate counts and SHA-256 for each evidence file.
- `human-review/` — a 48-answer source-based review worksheet, instructions, and private condition key. The key contains conditions and automatic judgments; keep it with the custodian and do not give it to reviewers.

The public review CSV contains no run IDs, conditions, repetition numbers, model identity, or automatic judgments. Anyone who has already seen the results must declare that exposure. A team member's review can help correct labels, but it is not an independent blind reference. This packet does not replace the separate A/B or LongMemEval C review.
