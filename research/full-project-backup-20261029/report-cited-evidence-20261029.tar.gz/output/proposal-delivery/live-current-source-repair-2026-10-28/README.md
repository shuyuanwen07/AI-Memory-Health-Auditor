# Current-source diagnosis-led repair replay

This bundle records a current-source, same-suite in-system comparison for the tutor’s diagnosis → targeted repair → retest workflow. The live application group is [`EXP627CCD21BC1D465996A30FF0E630739B`](http://localhost:5173/experiments/EXP627CCD21BC1D465996A30FF0E630739B); the like-for-like original-versus-targeted comparison is [open in the app](http://localhost:5173/compare?before=RUN42167A38184D40EE8E7AD2A79C25E8DB&after=RUNBA08475F1AD241D883BC811BC85C7652).

The current application source digest is `7d3033246fffc2d774f282f9e60c6ed6cd85848e540d75019e5764477edb567c`. The experiment used OpenRouter `openai/gpt-6-luna`, one synthetic source history, the frozen eight-question suite `4bb4a2ba407a237bd090d8caf610129e669bfc67f314720c57bfc3c7cccfafb5`, and three conditions: original first-match retrieval, a generic instruction control, and targeted “Match the task and project” retrieval. Only the retrieval strategy changed for the targeted condition; capacity, instructions, model, source history, and answer limit remained fixed. The diagnostic record was saved before the repair; the model synthesis was exploratory and explicitly did not establish cause.

| Condition | Passed / decided | Failed | Uncertain |
|---|---:|---:|---:|
| Original configuration | 1/6 | 5 | 2 |
| Generic instruction control | 1/6 | 5 | 2 |
| Targeted retrieval | 4/7 | 3 | 1 |

On the six questions decided in both the original and targeted runs, 1 passed in both, 2 passed only with targeted retrieval, 0 passed only with the original, and 3 failed in both. The app’s four-ability macro is 12.5% vs 50%, but coverage differs; do not present those macro values as raw all-answer pass rates. Five answers remain uncertain across the group. The target still has an unresolved Conflict Resolution answer and two failed Appropriate Use answers.

The full app reproduction bundle is stored as `experiment.bundle.json`. `manifest.json` binds its hash, the source digest, run IDs, per-dimension counts, paired comparison, and reviewer packet hashes. The prepared 24-answer worksheet is in `human-review/`; its private condition/evaluation key is custodian-only, mode 0600. The sheet has no reviewer labels. The project team has seen the aggregate results, so its later review cannot be described as independent or unexposed.

This is an exploratory diagnostic replay, not independent-scenario validation or a formal Auditor accuracy study. Repetitions are one per condition; five judgments are uncertain; all labels are automated. See the main experiment report for the complete interpretation and remaining human review.
