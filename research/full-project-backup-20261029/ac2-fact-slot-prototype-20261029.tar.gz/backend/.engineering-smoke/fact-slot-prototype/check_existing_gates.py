"""Offline checks only; these do not establish validity or API integration."""
import hashlib
import json
from pathlib import Path
from app.schemas import Memory, TestCase
from app.test_generator.quality import RuleBasedTestQualityValidator
from app.test_generator.scope_review import scope_warning

root = Path(__file__).parent
ledger_bytes = (root / 'model-probe-v1/ledger.json').read_bytes()
ledger = json.loads(ledger_bytes)
sample = {r['history_id']: r for r in json.loads((root / 'samples.json').read_text())}
sources = json.loads((root / 'source-messages.json').read_text())
rows = []
for h in ledger['histories']:
    messages = {m['source_id']: m['text'] for m in sources[h['history_id']]}
    memories = [Memory.model_validate(m) for m in sample[h['history_id']]['memories']]
    by_id = {m.memory_id: m for m in memories}
    for item in h.get('questions', []):
        test = TestCase.model_validate(item)
        assessment = RuleBasedTestQualityValidator().validate(test, memories)
        cited_ids = [s for m in test.supporting_memory_ids for s in by_id[m].source_message_ids]
        cited = [messages[s] for s in cited_ids if s in messages]
        warning = scope_warning(test.prompt, test.dimension.value, cited, source_complete=len(cited) == len(cited_ids),
                                conversation_source_texts=list(messages.values()))
        rows.append({'history_id': h['history_id'], 'test_id': test.test_id,
                     'quality_status': assessment.quality_status.value,
                     'grounding_status': assessment.grounding_status.value,
                     'quality_reason': assessment.reason, 'scope_warning': warning})
assert len(rows) == 3
result = {'ledger_sha256': hashlib.sha256(ledger_bytes).hexdigest(), 'rows': rows,
          'limitations': ['Offline individual checks, not a product API run or a human validity evaluation.',
                          'Source lookup is checked but semantic uniqueness and unextracted relations are not verified.',
                          'Related-topic count was not reconstructed; default count is one.']}
(root / 'model-probe-v1/offline-quality-diagnostic.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
