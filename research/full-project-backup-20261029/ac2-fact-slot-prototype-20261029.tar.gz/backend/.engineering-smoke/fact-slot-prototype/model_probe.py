"""Three-history development probe of the isolated candidate; no target answers."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from app.extraction.llm import PipelineLLMClient
from app.schemas import AuditRun, Memory, ReproducibilityMetadata
from candidate_agent import CandidateAgent

ROOT = Path(__file__).parent
IDS = ['IND-006', 'IND-007', 'IND-008']
MODEL = 'openai/gpt-6-luna'

def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

def main():
    out = ROOT / 'model-probe-v1'
    out.mkdir(exist_ok=False)
    files = [ROOT / name for name in ('fact_slots.py', 'candidate_agent.py', 'model_probe.py', 'samples.json')]
    protocol = {'selection': IDS, 'model': MODEL, 'source': 'Previously observed synthetic development histories; simulated confirmation.',
                'plan': 'One direct accuracy slot maximum per history. Run candidate agent in isolation once per history; save outcomes and receipts; no target calls.',
                'limitations': ['Post-outcome development, not independent validation.', 'Generated questions require source-grounded review.',
                                'Known relationship exclusion cannot prove no unextracted conflicts.', 'Model controls sampling; missing provider costs are unknown.'],
                'frozen_files_sha256': {p.name: hash_file(p) for p in files},
                'application_sha256': {str(p.relative_to(Path('/app'))): hash_file(p) for p in sorted(Path('/app/app').rglob('*.py'))}}
    write(out / 'protocol.json', protocol)
    rows = {r['history_id']: r for r in json.loads((ROOT / 'samples.json').read_text())}
    ledger = {'protocol_sha256': hash_file(out / 'protocol.json'), 'histories': []}
    write(out / 'ledger.json', ledger)
    for identity in IDS:
        assert all(hash_file(p) == protocol['frozen_files_sha256'][p.name] for p in files)
        item = {'history_id': identity, 'state': 'dispatched'}
        ledger['histories'].append(item)
        write(out / 'ledger.json', ledger)
        memories = [Memory.model_validate(m) for m in rows[identity]['memories']]
        audit = AuditRun(run_id='ISO-' + identity, conversation_id=memories[0].conversation_id, status='GROUND_TRUTH_CONFIRMED',
                         target_configuration='weak', provider='rule_based', model='rule-based-target-ai', temperature=0,
                         random_seed=42, test_budget=1, prompt_template_version='isolated',
                         reproducibility=ReproducibilityMetadata(coverage_policy='evidence_supported_only_v1'),
                         created_at=datetime.now(timezone.utc))
        generator = CandidateAgent(PipelineLLMClient('openrouter', MODEL), PipelineLLMClient('openrouter', MODEL), PipelineLLMClient('openrouter', MODEL))
        try:
            tests = generator.generate(memories, audit)
            item.update(state='completed', questions=[t.model_dump(mode='json') for t in tests])
        except Exception as exc:
            item.update(state='failed', error_type=type(exc).__name__, error=str(getattr(exc, 'detail', 'generation failed')))
        item['observation'] = generator.last_observation
        write(out / 'ledger.json', ledger)
        print(identity, item['state'], flush=True)
    ledger['finished_at'] = datetime.now(timezone.utc).isoformat()
    write(out / 'ledger.json', ledger)

if __name__ == '__main__':
    main()
