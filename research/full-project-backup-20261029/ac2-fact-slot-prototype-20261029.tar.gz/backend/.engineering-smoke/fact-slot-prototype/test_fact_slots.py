import pytest
from app.schemas import Dimension, Memory, MemoryRelationship, MemoryStatus, RelationshipType, TestType as Kind
from fact_slots import fact_slots
from candidate_agent import CandidateAgent
from app.test_generator.agent import AgentTestGenerator


def memory(id='m1', **changes):
    values = dict(memory_id=id, conversation_id='c1', canonical_value='A referenced fact',
                  status=MemoryStatus.CONFIRMED, source_message_ids=['s1'], relationships=[])
    return Memory(**(values | changes))


def test_cited_confirmed_fact_creates_only_an_unwritten_slot():
    slot, = fact_slots([memory()])
    assert slot.supporting_memory_ids == ['m1']
    assert slot.dimension.value == 'accuracy'
    assert 'no question' in slot.prompt


@pytest.mark.parametrize('changes', [dict(status=MemoryStatus.CANDIDATE), dict(status=MemoryStatus.REJECTED),
                                     dict(source_message_ids=[]), dict(source_message_ids=[' ']),
                                     dict(canonical_value='  ')])
def test_unconfirmed_or_untraceable_facts_do_not_create_slots(changes):
    assert fact_slots([memory(**changes)]) == []


@pytest.mark.parametrize('relation', list(RelationshipType))
def test_all_known_relationship_endpoints_are_excluded(relation):
    left = memory('m1', relationships=[MemoryRelationship(type=relation, target_memory_id='m2')])
    assert fact_slots([left, memory('m2'), memory('m3')])[0].supporting_memory_ids == ['m3']
    assert len(fact_slots([left, memory('m2'), memory('m3')])) == 1


def test_duplicate_or_cross_conversation_ids_fail_closed():
    with pytest.raises(ValueError):
        fact_slots([memory(), memory()])
    with pytest.raises(ValueError):
        fact_slots([memory(), memory('m2', conversation_id='c2')])


def test_partial_adds_evidence_slot_when_template_cannot_ask_the_fact():
    sample = [memory(canonical_value='My apartment has a small north-facing balcony')]
    seeds, quotas, available = CandidateAgent._coverage_seed_inventory(sample, 4, coverage_policy='evidence_supported_only_v1')
    assert available[Dimension.ACCURACY] > 0 and quotas[Dimension.ACCURACY] > 0
    assert any(s.supporting_memory_ids == ['m1'] for s in seeds)
    assert all(s.supporting_memory_ids == ['m1'] for s in seeds)


def test_strict_inventory_unchanged_and_type_filter_is_respected():
    sample = [memory(canonical_value='My apartment has a small north-facing balcony')]
    assert CandidateAgent._coverage_seed_inventory(sample, 4) == AgentTestGenerator._coverage_seed_inventory(sample, 4)
    seeds, _, _ = CandidateAgent._coverage_seed_inventory(sample, 4, allowed_test_types=frozenset({Kind.INDIRECT}), coverage_policy='evidence_supported_only_v1')
    assert all(seed.test_type == Kind.INDIRECT for seed in seeds)
