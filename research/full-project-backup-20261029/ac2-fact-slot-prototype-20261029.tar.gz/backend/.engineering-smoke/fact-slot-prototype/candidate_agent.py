"""Isolated development candidate; never selected by the application factory."""
from app.schemas import Dimension
from app.test_generator.agent import AgentTestGenerator
from fact_slots import fact_slots


class CandidateAgent(AgentTestGenerator):
    VERSION = 'isolated-fact-slot-candidate-v1'

    @staticmethod
    def _coverage_seed_inventory(memories, test_budget, allowed_test_types=None, coverage_policy='strict_full_v1'):
        seeds, quotas, available = AgentTestGenerator._coverage_seed_inventory(
            memories, test_budget, allowed_test_types=allowed_test_types, coverage_policy=coverage_policy)
        if coverage_policy != 'evidence_supported_only_v1':
            return seeds, quotas, available
        known = {(test.dimension, test.test_type, tuple(sorted(test.supporting_memory_ids))) for test in seeds}
        for candidate in fact_slots(memories):
            if allowed_test_types is not None and candidate.test_type not in allowed_test_types:
                # Do not silently reclassify the experimental direct slot.
                continue
            key = (candidate.dimension, candidate.test_type, tuple(sorted(candidate.supporting_memory_ids)))
            if key not in known:
                seeds.append(candidate)
                known.add(key)
        available = {dimension: sum(test.dimension == dimension for test in seeds) for dimension in Dimension}
        return seeds, AgentTestGenerator._dimension_quotas(test_budget, available, coverage_policy), available
