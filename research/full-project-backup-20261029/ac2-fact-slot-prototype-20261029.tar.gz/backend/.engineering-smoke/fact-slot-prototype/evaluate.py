"""Count candidate slots only; do not treat this as question generation."""
import json
from pathlib import Path
from app.schemas import Memory
from fact_slots import fact_slots

path = Path(__file__).parent
sample = json.loads((path / 'samples.json').read_text())
out = []
for row in sample:
    slots = fact_slots([Memory.model_validate(m) for m in row['memories']])
    out.append({'history_id': row['history_id'], 'previous_state': row['state'],
                'candidate_count': len(slots), 'candidate_memory_ids': [s.supporting_memory_ids[0] for s in slots]})
assert len(out) == 25
summary = {'histories': len(out), 'previous_no_suite': sum(x['previous_state'] == 'failed' for x in out),
           'previous_no_suite_with_candidates': sum(x['previous_state'] == 'failed' and x['candidate_count'] > 0 for x in out),
           'candidate_slots_are_questions': False, 'new_generated_questions': 0,
           'caveat': 'Post-outcome candidate inventory only; simulated confirmation and missing extracted edges are not proof of validity.', 'rows': out}
(path / 'prototype-inventory.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: v for k, v in summary.items() if k != 'rows'}, indent=2))
