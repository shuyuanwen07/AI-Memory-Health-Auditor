"""Prepare blank, source-bound AC1 reviews; never manufacture human judgments."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
BASE=ROOT/'output/proposal-delivery/ac1-ac2-b-return-20261029-v1/17_AC1_AC2_B修复后审核'
SUMMARY=ROOT/'output/proposal-delivery/ac1-ac2-b-return-20261029-v1/ac1-paired-comparison.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def write(p,o):
 with p.open('x',encoding='utf-8') as f:json.dump(o,f,ensure_ascii=False,indent=2);f.write('\n')
files=[BASE/f'审核者{i}/AC1修复后提取/reviewer-{i}.json' for i in (1,2)]
reviews=[json.loads(p.read_bytes()) for p in files];paired=json.loads(SUMMARY.read_bytes()); IDs=paired['paired_history_ids'];assert len(IDs)==27
by=[{x['history_id']:x for x in d['histories']} for d in reviews]
phase_a=[];phase_b=[];prior_reference_status=[]
for hid in IDs:
 a,b=(x[hid] for x in by);assert a['extraction_status']==b['extraction_status']=='completed'
 for k in ('source_messages','reviewed_reference_facts','reviewed_reference_relationships'):assert a[k]==b[k]
 for k,field in [('candidates','candidate'),('relationships','relationship')]:assert [x[field] for x in a[k]]==[x[field] for x in b[k]]
 facts=[x['fact'] for x in a['reviewed_reference_facts']]; lookup={f['memory_id']:f for f in facts};assert len(lookup)==len(facts)
 prior_reference_status.extend({'history_id':hid,'fact_id':x['fact']['memory_id'],'prior_status':x['reference_status']} for x in a['reviewed_reference_facts'])
 pairs=[]
 for index,x in enumerate(a['reviewed_reference_relationships']):
  e=x['relationship'];t=e['relationship_type']
  if t not in ('UPDATE','CONFLICT'):continue
  assert e['memory_id'] in lookup and e['target_memory_id'] in lookup
  pairs.append({'pair_id':hid+'-R'+str(index+1), 'source_fact_id':e['memory_id'],'target_fact_id':e['target_memory_id'],
     'source_fact':lookup[e['memory_id']]['canonical_value'],'target_fact':lookup[e['target_memory_id']]['canonical_value'],
     'source_messages':e.get('evidence_message_ids',[]),'source_label':None,'notes':''})
 phase_a.append({'history_id':hid,'source_messages':a['source_messages'],
  'reference_facts':[{'fact_id':f['memory_id'],'fact':f['canonical_value'],'source_message_id':f['source_message_id'],
     'validity':None,'notes':''} for f in facts], 'relation_pairs':pairs})
 phase_b.append({'history_id':hid,'source_messages':a['source_messages'],
  'reference_facts':[{'fact_id':f['memory_id'],'fact':f['canonical_value'],'source_message_id':f['source_message_id'],
     'coverage':None,'covering_candidate_ids':[],'notes':''} for f in facts],
  'source_relation_pairs':[{'pair_id':e['pair_id'],'source_fact_id':e['source_fact_id'],'target_fact_id':e['target_fact_id'],
     'source_fact':e['source_fact'],'target_fact':e['target_fact'],'copied_phase_a_label':None,
     'matching_extracted_edge_ids':[],'output_status':None,'notes':''} for e in pairs],
  'extracted_candidates':[x['candidate'] for x in a['candidates']],
  'extracted_relationships':[x['relationship'] for x in a['relationships']]})
assert sum(len(x['reference_facts']) for x in phase_b)==216
assert sum(len(x['source_relation_pairs']) for x in phase_b)==54
manifest={'format':'ac1-fullness-classification-review-manifest-v1','paired_summary_sha256':sha(SUMMARY),
 'original_reviewer_sha256':[sha(p) for p in files], 'histories':IDs,'excluded_incomplete_histories':['AC3-H04','AC3-H28','AC3-H30'],
 'reference_fact_count':216,'reference_facts_previously_reviewed':215,'reference_facts_previously_unresolved':1,'selected_update_conflict_pair_count':54,
 'prior_reference_status_sha256':hashlib.sha256(canonical(prior_reference_status)).hexdigest(),
 'phase_a_material_sha256':hashlib.sha256(canonical(phase_a)).hexdigest(),
 'phase_b_material_sha256':hashlib.sha256(canonical(phase_b)).hexdigest(),
 'limitations':['Existing selected synthetic scenarios are not random and were previously used in development.',
 'Reference facts are non-exhaustive; coverage against this inventory is not recall over all facts.',
 'The 54 source pairs were selected from reference UPDATE/CONFLICT edges; they do not form an exhaustive set of all positive and negative relation pairs.',
 'Three partial histories are retained separately and cannot be scored as missing facts or edges.','No new human decisions are present in this package.']}
write(OUT/'manifest.json',manifest)
write(OUT/'private-reference-status.json',prior_reference_status)
for i in (1,2):
 folder=OUT/f'reviewer-{i}';folder.mkdir()
 declaration={'reviewer_label':None,'completed_by_human':None,'independent_of_other_reviewer':None,'viewed_other_review':None,'used_ai_assistance':None,'prior_exposure':None}
 write(folder/'01-source-reference.json',{'format':'ac1-source-reference-review-v1','reviewer_slot':i,'material_sha256':manifest['phase_a_material_sha256'],
  'instructions':'先独立只看来源，逐事实判断 reference 是否可由原文支持（valid / invalid / uncertain）；逐事实对判断真实关系 UPDATE / CONFLICT / neither / uncertain。UPDATE 表示 source_fact 明确更新或替代 target_fact，不能倒置；CONFLICT 表示两个不相容记录同时有效，方向无关。不能默认存在所选类别。允许 uncertain 并注明原因。完成本文件后再打开第二阶段。不得查看另一人判断。','reviewer_declaration':declaration,'histories':phase_a})
 write(folder/'02-extraction-mapping.json',{'format':'ac1-extraction-mapping-review-v1','reviewer_slot':i,'material_sha256':manifest['phase_b_material_sha256'],
  'instructions':'先完成第一阶段，再对照本文件来源和实际提取。每个事实填写 full / partial / missing / uncertain 与支持的 candidate ID；full 要覆盖全部事实内容，partial 仅覆盖一部分，缺少/矛盾或不能判断应如实记录。每个关系对填写第一阶段类别，再填写对应输出 edge ID，标 correct_type / wrong_type / missing / partial / uncertain；完整端点和类别均须核对。不要把未匹配或部分匹配自动认作不存在。','reviewer_declaration':declaration,'histories':phase_b})
 with zipfile.ZipFile(OUT/f'reviewer-{i}.zip','x',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(folder.iterdir()):z.write(p,p.name)
(OUT/'填写说明.md').write_text('''# AC1 双人复核\n\n两位审核者各取各自的 reviewer-1.zip / reviewer-2.zip，独立填写。先只打开 01-source-reference.json，根据原文判断 216 条事实和 54 对 UPDATE/CONFLICT 候选关系；完成后才打开 02-extraction-mapping.json，核对实际提取并填写覆盖、对应候选或关系 ID。`uncertain` 表示不能确定，不应当成通过或失败。`notes` 记录原因。请勿查看对方判断。文件中的声明空位需按实际情况填写；若使用 AI 辅助请如实填写。\n\n此包只覆盖两轮都完整的 27 段；H04、H28、H30 在新运行不完整，不计为提取遗漏。216 条中有 215 条曾被纳入原参考清单，另一条原先未决；本包将其一并提交复审，不覆盖原始状态。事实清单不是穷尽的，54 对关系也不是所有可能关系对，因此最终只能报告对这份选定参考清单的覆盖和条件分类，不能说是全部事实的严格召回或总体准确率。原有审核意见未替换。\n''',encoding='utf-8')
with zipfile.ZipFile(OUT/'AC1-双人分阶段审核包.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in (OUT/'填写说明.md',OUT/'manifest.json',OUT/'reviewer-1.zip',OUT/'reviewer-2.zip'):z.write(p,p.name)
print(json.dumps({'paired_histories':len(IDs),'fact_references':216,'relation_pairs':54,'archive':str(OUT/'AC1-双人分阶段审核包.zip')},ensure_ascii=False))
