# Larger single-history audit (29 October 2026)

This is an operational demonstration, not the multi-history proposal experiment or independent human validation. It reuses synthetic conversation C8AEAC694B4BB4CA98D6BCF41E48283D4 and its existing confirmed memory inventory. GPT-6 Luna was the target; generation and evaluation used rule-based components. The frozen request was 16 distinct questions.

Run: RUN2D220099B3474F1CB3F4679CA7CBF74F. Generated dimensions: accuracy 8, freshness 2, conflict resolution 4, appropriate use 2. Automatic outcomes: accuracy 4/7 decided, one uncertain; freshness 2/2; conflict resolution 2/4; appropriate use 2/2. Reported macro score 76.8%. A single synthetic history and small per-ability counts cannot support population-wide conclusions.

result.json contains the run configuration, questions, model answers and automatic assessments, saved from the API. run_audit.py records the request sequence; re-running it creates a new audit and incurs model charges. For broader cross-history evidence, consult the separately reviewed AC3 study.

Two attempted 23- and 12-question runs on a different history failed the answer-leakage quality gate and yielded no results; their request records are preserved separately in large-single-audit-model-20261029 and large-single-audit-model-12-20261029. The earlier rule-based attempt also failed the quality gate and is preserved in large-single-audit-20261029.
