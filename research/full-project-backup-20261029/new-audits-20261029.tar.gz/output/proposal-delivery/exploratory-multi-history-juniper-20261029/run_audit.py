import json, urllib.request, urllib.error, pathlib, datetime, collections, sys
b='http://127.0.0.1:8000/api/v1'
p=pathlib.Path('output/proposal-delivery/exploratory-multi-history-juniper-20261029');p.mkdir(parents=True,exist_ok=True)
s={'scope':'larger single-history audit; synthetic source; existing confirmed memories; automatically scored, not human validated','requested_test_budget':9,'source_conversation_id':'AC3C9CE4C075FFAB5FB0324A053536315ACA','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'requests':[]}
def save(): (p/'result.json').write_text(json.dumps(s,indent=2,ensure_ascii=False)+'\n')
def req(method,path,data=None):
 q=urllib.request.Request(b+path,method=method,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(q,timeout=1800) as r: out=json.load(r); code=r.status
 except urllib.error.HTTPError as e:
  out=e.read().decode();s['requests'].append({'path':path,'status':e.code,'error':out});save();print('ERROR',path,e.code,out[:500],flush=True);raise
 s['requests'].append({'path':path,'status':code,'body':out});save();print(path,code,flush=True);return out
try:
 roles={'pipeline_provider':'rule_based','pipeline_model':'rule-based-v2','evaluator_provider':'rule_based','evaluator_model':'rule-based-v64','semantic_review_provider':'rule_based','semantic_review_model':'rule-based-v2'}
 a=req('POST','/audits',{'conversation_id':s['source_conversation_id'],'target_configuration':'strong','provider':'openrouter','model':'openai/gpt-6-luna',**roles,'test_budget':9,'random_seed':42,'temperature':0,'memory_strategy':'strong_rule_based','memory_maintenance_policy':'update_aware_consolidation','target_memory_capacity':100,'target_memory_writer':'rule_based','target_system_adapter':'controlled-memory','retrieval_mode':'fixed'})
 rid=a['run_id'];s['run_id']=rid;save()
 tests=req('POST',f'/audits/{rid}/generate-tests');s['generated_counts']=dict(collections.Counter(t['dimension'] for t in tests));s['generated_count']=len(tests);s['quality_counts']=dict(collections.Counter(t['quality_status'] for t in tests));save();print('suite',s['generated_count'],s['generated_counts'],s['quality_counts'],flush=True)
 if len(tests)<8 or len(s['generated_counts'])<4: raise ValueError('Insufficient distinct tests; no execution')
 req('POST',f'/audits/{rid}/execute');req('POST',f'/audits/{rid}/evaluate');s['result']=req('GET',f'/audits/{rid}/results');s['status']='completed';save();print('RESULT',json.dumps({'run_id':rid,'count':s['generated_count'],'dimensions':s['result'].get('dimensions'),'overall':s['result'].get('overall_score')},ensure_ascii=False),flush=True)
except Exception as e:
 s['status']='failed';s['error']=str(e);save();raise
