# AC3 balanced failure-taxonomy diagnostic: analysis plan

Recorded at **2026-11-01 14:14:25 UTC** (2 November in Sydney), before this study's grader results exist. This is a timestamped local analysis plan, not an independently registered preregistration. Preserve the file hash, its actual creation time and any later amendments.

## Question and scope

Does a revised classification rubric improve the Auditor's detection and identification of actual memory errors over the original Astra MAX taxonomy rubric on a new, balanced diagnostic set?

The answers in this set are deliberately curated fault injections and correct controls. They are **not naturally generated target-model answers**. Results estimate diagnostic performance on these controlled cases, not target-model accuracy, naturally occurring error rates, or real-world prevalence. They supplement the preserved natural-answer study rather than replacing its unresolved results.

The prompt developer may inspect the earlier 120-answer development cohort. They must not inspect the new validation sources, answers, intended labels or review judgments while developing the revised rubric. Freeze and hash both rubrics before any validation grading call. Log any exposure or other deviation explicitly.

## Planned observations and independent reference gate

- Thirty new synthetic source-history clusters, with five answer cases in each, give **150 planned cases**.
- Each history intends one single-error case for each of Accuracy, Freshness, Conflict Resolution and Appropriate Use, plus one completely correct pass control. The intended totals are 30 failures of each type and 30 passes.
- Intended labels are private design annotations. They are not reference truth and are not supplied to either reference reviewer or either grader.
- Two independent Astra MAX reference reviewers inspect the source, question and actual answer **before grading begins**. Neither receives the other review, automatic scores, rubric-arm identity or intended categories.
- Each reviewer assesses question validity, source/reference validity, answer pass/fail/uncertain and the actual error category. Multiple independent errors or insufficient evidence remain `multiple` or `uncertain`; do not infer a label from the question's intended dimension.
- The reference gate requires both reviewers to agree on at least **30 actual single-category failures in each of the four categories and 30 passes**, with all 30 histories represented. With exactly 150 planned slots, meeting this gate requires all slots to supply the intended balanced reference coverage.
- Review disagreements, invalid questions, multiple-error cases, and missing reviews remain visible. If the gate is not met, report **insufficient reference evidence** and the actual counts; do not silently drop or replace slots after grading. Any source/question revision before grading must be versioned, independently reviewed again where affected, and frozen as a distinct release. Retain the original release and the reason for change.

The category describes the **observed error**, not merely the topic of a question. Explicitly using a superseded value can support Freshness; choosing an unranked side of an unresolved exclusive conflict can support Conflict Resolution; applying a true general default to a stated scope exception can support Appropriate Use. Other unsupported or incorrect stable facts can support Accuracy. Reference reviewers retain multiple/uncertain judgments when one primary category cannot be justified.

## Paired grader comparison

Grade every frozen case with both arms:

| Arm | Deliberate difference |
| --- | --- |
| Baseline | Original retained Astra MAX taxonomy rubric |
| Candidate | Revised rubric developed only from the earlier development cohort |

Both arms use direct OpenAI `gpt-6-astra`, requested reasoning effort `max`, an 8,192-token output limit and one provider attempt. Keep identical question text, saved answer, approved memories, model, schema/validation policy and all other supported request settings. The only intended intervention is the rubric. Record the exact request settings and fingerprints; preserve any unavoidable deviations.

Neither grader receives the reference answer, intended category, reviewer labels, source-case type, other arm's result or automatic aggregate results. The authorized source boundary is the identical approved-memory material supplied to both arms. Retain the exact supplied context and its hash.

Use the frozen seed `20261102` to randomize case order and the within-pair arm order, balance which arm goes first, and save the schedule before dispatch. Preserve a total of **300 planned grader slots**. A failed, malformed, missing or ambiguous response stays in its original slot. No outcome-dependent retry, replacement, rubric revision or selection of a more favorable repetition is allowed. Do not manufacture a seed parameter unsupported by the provider.

## Outcomes and denominators

Use the two-reviewer actual reference consensus. Keep question/reference validity separate from answer correctness and failure-type correctness.

| Measure | Definition under the complete reference gate |
| --- | --- |
| **Primary: verified detection and correct category** | Correctly detected **and** correctly typed failures / all 120 agreed failures. A missed failure, wrong type, absent type, abstention, malformed output or request error contributes no verified success. |
| Per-category joint sensitivity | Correctly detected and typed failures in that actual category / its 30 agreed failures. |
| Failure recall | All agreed failures detected as failures, regardless of category correctness / 120 agreed failures. |
| False-positive rate | Agreed passes predicted as any failure category / all 30 agreed passes. Display the numerator and 30-slot denominator. |
| Decided coverage | Valid, explicit pass/fail decisions / all 150 planned slots. |
| Question validity | Valid questions / all 150 planned questions; show invalid, uncertain and missing review counts separately. |
| Joint question/reference validity | Both question and reference accepted by both reviewers / all 150 planned cases. |

Also report correct type / all detected reference failures and the number of detections lacking a usable type, but do not substitute that conditional fraction for the primary 120-failure denominator after seeing results. Display counts for every ratio.

An abstention, error or missing response on a pass control is not an observed false-positive claim. Nevertheless, it cannot support a claim of safe behavior. Show those counts beside the false-positive rate, with descriptive bounds: observed false positives / 30 through (false positives + unresolved/missing pass-control outputs) / 30. Show coverage alongside these bounds. Never present zero observed false positives as zero population risk.

If actual consensus differs from the planned balance, report actual category denominators, reference coverage and unresolved planned slots. Do not relabel intended types as actual types, fill unknown labels, or treat unmeasured categories as zero or perfect. Any derived ratios in an insufficient-evidence release remain descriptive and cannot satisfy the planned reference gate.

## Confusion matrix and fixed thresholds

For each arm, publish the full count matrix with actual rows **Accuracy, Freshness, Conflict Resolution, Appropriate Use and Pass**, and prediction columns **Accuracy, Freshness, Conflict Resolution, Appropriate Use, Pass, Uncertain and Error/missing**. Preserve unclassifiable-reference cases separately if the reference gate fails; never conceal them by forcing a row assignment. Matrix totals and all metric numerators must reconcile with the saved slot-level outcomes.

Retain the agreed point thresholds: classification **at least 80%**, failure detection **at least 80%**, question validity **at least 90%**, false-positive rate **at most 10%**, and decided coverage **at least 80%**. Apply classification to the primary joint correct-category / all agreed failures measure. Per-category results remain explicit so a strong Accuracy result cannot hide absent or poor category coverage. Category sensitivity is **unmeasured** where no actual positive references exist.

Report each check separately, reference-gate status and uncertainty. Meeting numerical thresholds is not a claim that confidence bounds meet those thresholds, that the four abilities generalize, or that human verification has occurred. New AI review must retain its own human-confirmation status until explicitly confirmed.

## Paired uncertainty and interpretation

Use a paired source-history cluster bootstrap with **5,000 draws, seed `20261102` and 95% percentile intervals**. Sample 30 history IDs with replacement for each draw. Keep all five cases and both rubric arms together whenever a history is selected. Recompute each arm's ratios and the paired candidate-minus-baseline differences inside each draw.

Report point estimates, intervals, valid bootstrap draw counts and the direction of improvement: positive classification/recall/coverage differences and negative false-positive differences. Undefined resampled ratios stay undefined; do not replace them with zero. Show paired improved, worsened and unchanged case counts. Do not treat the two arms or five within-history cases as independent observations.

These are descriptive intervals for the selected synthetic clusters. Source similarity, deliberate balancing, shared templates and the shared Astra family of reviewers and graders can produce correlated errors and limit generalization. A resampling interval over zero observed false positives can collapse to zero without bounding risk in new cases. Do not select the best denominator, metric, category or prompt variant after observing validation outcomes.

If the original rubric already performs well, or the revision does not improve it, report that result. A negative or tied comparison is still useful evidence about the proposed repair. Preserve the earlier development results, this validation release, all original reference reviews, all 300 scheduled slot outcomes, raw receipts, model/prompt/context hashes, deviations and analysis code.
