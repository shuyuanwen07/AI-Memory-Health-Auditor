# AC3 taxonomy refinement: development rationale

This note uses only the existing 120-answer Astra MAX development cohort. It does not inspect or label the new validation set, run a model, modify product code or change accepted review judgments.

## What the current numbers actually show

The agreed references contain 51 passes and 69 failures. Only 42 failures have an agreed single category: 38 Accuracy, two Conflict Resolution and two Appropriate Use. None is an agreed Freshness positive. The candidate correctly classified 35 of those 42. The 27 other failure types remain unverified, rather than automatically incorrect predictions.

Both Appropriate Use reference cases ask for a particular required communication method. The answers remember the general method, explicitly avoid applying it to the exceptional setting, but do not supply the source-supported exception. The two reference reviewers call this failure to use the applicable instruction. The scorer calls it a directly requested factual omission, using the rubric's warning that mere failure to recall an instruction is not sufficient for Appropriate Use. Both interpretations have a textual basis. This should be reported as an operational definition boundary; the old 0/2 result remains unchanged.

There are five further agreed-type mismatches. Four have Accuracy reference labels but Freshness predictions; the observed answers positively deny that a supplied count/update exists, or correctly retrieve the new number while misidentifying its attribute. The scorer follows the update present in the source rather than isolating the actual erroneous assertion. One additional Accuracy reference is unclassified by the scorer because the answer also invokes an irrelevant preference. The existing multiple-failure rule makes that abstention defensible, so it should not be forcibly relabelled for a higher score.

## Why 27 reference types remain open

- Nine answers merely refuse to recall an updated fact. Neither the old nor the new value appears. A general omission and failure to handle the update are both possible.
- Nine conflict replies safely decline a unique answer or only partially describe the evidence. A factual omission and an omitted conflict explanation may be inseparable. One partially described conflict also falsely denies an available competing value.
- Seven replies potentially contain separate false-source assertions or irrelevant conflict use as well as omitted relevant conflict handling. Multiple actual errors need not have one primary label.
- Two replies recall an old value while saying its revision is unavailable. One reviewer calls the positive source-description error Accuracy and the other calls the update-related failure Freshness.

Six of the incomplete conflict replies also produce a verdict disagreement with the scorer. A question asking only which final value applies may have no unique source-supported answer. A safe refusal can therefore satisfy the question's literal request even when the reference expects both conflicting claims to be listed. The refined rubric must not add an unasked evidence-listing requirement simply to match the development labels. New diagnostic questions should make requested completeness explicit.

## The refinement

`revised-rubric.txt` keeps the five-field single-type JSON schema and four category labels unchanged. It asks the judge to establish the actual question contract, separate safety from requested completeness, and map observable errors to evidence conditions. It clarifies that source updates and contextual instructions are insufficient by themselves to identify an answer's failure mechanism. Actual stale substitution, active exclusive conflict decisions and scope misapplication remain distinct. Ordinary factual errors remain residual. There is no fixed category precedence. Multiple independently evidenced errors or inseparable mechanisms remain null, with a reason.

For contextual application, the revised text distinguishes using the general default for the wrong task from merely failing to recall a recorded instruction. This is a conservative clarification, not a promise to convert the two disputed development interpretations to Appropriate Use. Correcting taxonomy boundaries is more important than reproducing a favourable conditional score.

## Evaluation boundary

Freeze both prompt strings and the existing JSON schema before any new grader result. Use the same question, answer and confirmed-memory input for both Astra MAX arms, with identical output budget, attempt rule and request settings. The scorer must never receive the intended category, expected answer, human judgment or strategy identity. Reviewers should independently validate actual question/reference/answer/type evidence before grader calls.

The proposed balanced source set will intentionally inject unambiguous errors. Its results measure controlled diagnostic coverage, not the frequency or severity of real target errors. Require actual agreed class labels and retain every scheduled slot; an intended category is not a gold label. Report type coverage and all-detected verified classification alongside classifiable-only accuracy. Retain the original natural-answer result, including all 27 unclassifiable cases, and report negative findings if the unchanged rubric already performs as well as the refinement.

The new set must not be called fully held out merely because its histories are new: if its builder knew the conceptual rubric, the set is a prospective controlled diagnostic set. Shared Astra-family reference and scoring models and related synthetic structures remain limitations. Human verification remains a separate, explicitly recorded step.
