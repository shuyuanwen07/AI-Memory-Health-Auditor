# AC3 balanced taxonomy diagnostic draft

This is a **new controlled diagnostic set for the evaluator**. Its answers were intentionally written as fault injections and correct controls. They are **not naturally observed target-model responses**, a model-performance benchmark, or evidence about real-world error prevalence.

## Contents and provenance

- `dataset-draft.json`: 30 fictional histories, 270 source messages and 150 opaque answer cases. No expected answer, intended verdict, or intended category is present in its items.
- `private-intended-key.json`: the author's planned labels, relevant source IDs and expected behaviour. Keep this file away from independent reviewers and candidate scorers. These intentions are not verified ground truth.
- `preparation-integrity.json`: counts, unique identities, source coverage and SHA-256 hashes.
- `scripts/prepare_ac3_balanced_taxonomy_20261102.py`: the deterministic source and case generator, using shuffle seed `20261102`. It performs no model calls and makes no review or acceptance claim.

Sources use `sources[].source_id` and `messages[].message_id/role/content/timestamp`. Cases use `items[].review_id/source_id/question/answer/response_origin`. Source and item orders are shuffled independently. Original source order remains explicit inside each history. All histories are fictional; dates are synthetic provenance markers rather than external facts.

## Planned balance

Each history has one deliberately incorrect stable-fact answer, one obsolete answer after an explicit replacement, one unjustified choice between unresolved exclusive records, one general preference applied to the wrong scoped task, and one correct control. The intended design therefore contains 30 failures per category and 30 passes. Independent reviewers must assess the actual error, not copy this planned balance.

The 30 passing controls include eight ordinary-fact recalls, eight explicit-update summaries, seven acknowledgements of unresolved conflicts, and seven recommendations applying scoped exceptions. They share sources with the failing cases, supporting within-history controls while remaining correlated observations.

## Category boundaries

The current product rubric treats **Accuracy** as a residual ordinary-fact category: it excludes failures that the evidence establishes as update, unresolved conflict or context misuse. Incorrectness in the everyday sense does not by itself justify two taxonomy labels. This set does not impose a forced precedence rule.

- **Accuracy:** the response gives a wrong stable attribute. No update, conflict or scope exception governs that attribute.
- **Freshness:** the source explicitly replaces the old arrangement, cancels it, and states the applicable new arrangement. The bad answer uses the old value.
- **Conflict Resolution:** two active, equally authoritative and simultaneous records assign different values to one exclusive final field for the same event/item. Neither supersedes the other, and no resolution exists. The bad answer commits to one value.
- **Appropriate Use:** the response explicitly uses a true general preference to choose an option for a task with a different explicit scoped requirement. The source preserves the general preference elsewhere, so this is not a global update.

If a reviewer finds a second independent error, ambiguity, unsupported premise, or insufficient source evidence, the verdict/category must remain `multiple` or `uncertain` as appropriate. Passing or uncertain answers have no failure type. None of the author's labels should force reviewer agreement.

## Variety and remaining dependence

The histories cover library materials, gardening, ceramics, astronomy, bicycle volunteering, museum tours, games, music, repair-cafe logistics, book swaps, paddling administration, photography, origami, running registration, craft fairs, robotics, walking-club booking, makerspace printing, theatre, baking meetings, film discussions, outreach, packaging, chess, language exchange, mapmaking, seed exchange, mobile lending, writing and instrument loans.

The underlying tasks differ: times, dates, durations, capacities, locations, formats, fees, word limits and programme languages change; conflicting fields include rooms, plots, finishes, platforms, counters, route direction, titles, credits, names and units. The generator checks 150 unique question strings and no identical full source-message text. This is more than a name substitution, but the five evidence patterns deliberately recur to balance categories. Broad domain labels and unique wording do **not** establish population diversity or statistical independence.

The crafted errors are generally explicit and simpler than naturally occurring multi-error answers. Success on this set would demonstrate controlled diagnostic competence, not solve the previous 27 natural-answer category ambiguities or establish held-out real-world reliability. Analysis should cluster by the 30 histories and show per-class results, all planned slots, review disagreements, uncertain outputs and false positives separately. Do not pool these injected answers into target-model accuracy.

## Required next gate

Two independent reviewers should receive only the source/question/answer material, with category intentions, automatic scores and the other review withheld. They must validate the source, question, verdict, actual category and evidence IDs before scorer calls. The scorer receives only the confirmed memories, question and saved answer, without author intentions or expected behaviour.

After that review, freeze the exact dataset hashes, actual reference-class counts, rubric versions, model/provider/max effort/output budget, single-attempt policy and statistical rules before evaluating the candidate. Any pre-run revision must retain the original draft and its reasons. If the agreed actual labels do not support the predeclared minimum per category, report insufficient evidence instead of selecting favourable cases after seeing grader results. Human confirmation of this new set is still pending.
