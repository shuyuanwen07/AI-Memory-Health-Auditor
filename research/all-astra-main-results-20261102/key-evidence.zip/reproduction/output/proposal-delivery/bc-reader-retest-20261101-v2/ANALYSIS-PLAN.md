# Repeated B/C development retest

The B and C execution protocols were frozen before their calls. This analysis
plan is recorded during collection and before the main review-consensus scores.
It must not be described as an earlier preregistration.

Both studies plan 16 questions, four policies and three repetitions: 48 answer
slots per policy, 192 per study. OpenAI GPT-6 Astra uses max reasoning, the same
8,192-token output cap, memory capacity 50, up to 50 retrieved records and a
16,000-character memory context budget. Source/reference answers and review
labels are never inputs to the target model.

B keeps the four previously reviewed synthetic histories and exact questions.
The common reader is strong for every policy. First-match still retrieves one
record through its store policy. This repairs a bundled reader setting: it
changes both context delivery and reader instructions. The original deterministic
rule writer stays fixed, including its known missing venue records. This is a
reader ablation, not a claim to repair the writer or isolate delivery alone.

C samples 16 cases from the pinned LongMemEval Oracle release with a fixed seed
and stratified quotas, including the two old anchor cases. Oracle evidence-only
histories, the local adapter and the source-aware review are separate from an
official full-benchmark execution. Neither the new set nor the anchors are
claimed to be previously unseen.

## Review and reporting rules

- Two separate Astra high reviewers see opaque source/answer handles, source
  messages and reference behavior. Policy, model, repetition, automatic scores
  and the other reviewer's conclusions are withheld.
- Review question/reference validity separately from answer correctness. A
  disputed or unsupported reference makes an answer unresolved for the primary
  analysis; it is not automatically a model failure. Preserve both judgments.
- Main display: agreed passes / 48 planned. Show unresolved, unreviewed, failed
  requests and incomplete collection separately. This ratio is verified-success
  coverage, not decided-only accuracy. Report agreed passes / (agreed passes +
  agreed failures) separately when useful.
- Safe abstention or a clarification request can still be factually incomplete.
  Record this behavior separately from hallucination and from full correctness.
- Retain all three repetition results and answer text. Do not redispatch an
  ambiguous or failed paid request. A proven pre-provider suite-lock rejection
  may resume only with the archived zero-dispatch evidence and amendment.
- New B overall results use all four histories. Historical matched comparisons
  use only FS01–FS03, which had complete old four-policy answers. New-versus-old
  differences are descriptive development evidence with changed reader/budget.
- C comparisons on the two anchors are separate from the 16-case expansion;
  model, output budget and cohort changes cannot be pooled into one causal gain.
- B and C share a presentation denominator, but differ in source structure and
  difficulty. No pooled B/C accuracy or direct model-strength claim is allowed.
- Bootstrap uncertainty and paired policy differences resample source histories
  for B and cases for C, keeping repeats together; never treat 48 answers as 48
  independent histories. B has only four structurally related clusters. Intervals
  describe these selected cohorts and are not population guarantees.
- AI review is always labelled AI review. Human confirmation requires an explicit
  subsequent human statement or returned review, not silence or elapsed time.

Original artifacts are preserved. Improvements, remaining failures, disagreements
and negative outcomes receive the same retention and reporting treatment.
