# B/C retest: independent archive diagnosis

This audit made no model calls and changed no judgments, application code or presentation.

## Confirmed causes and limits

- Old B saved52answers. Every receipt delivered one memory. All36completed answers from the three advanced policies had2–5records selected but only one sent. The `weak` reader truncated the list; the records later in the ranking never reached the model.
- The shared rule writer stored no venue facts in any of the four available history traces, although source M5/M6 state incompatible named venues. Reader-only repair cannot repair those missing facts. This is an explicit residual-coverage ablation, not a clean estimate of retrieval quality across complete stores.
- `weak`→`strong` also changes the reader's update/context/conflict instruction. Name the intervention “shared reader configuration repair”, rather than claiming a delivery-only causal effect.
- Conflict gold requires exact venue names, whereas the question foregrounds safe handling. Several archived answers correctly request clarification but lack factual specifics. Keep original strict labels; separately describe safety and factual completeness, and flag any wording ambiguity for reviewers.
- In48complete Banswers, automatic lexical grading has8passes that source-aware archived review marked fail. A concrete freshness answer saying the locations are unknown passed on the generic word “longer”. The low slide counts use later-confirmed review consensus, not automatic lexical scores.
- Old C already used a fixed strong reader. It used2reused knowledge-update cases×3repeats with Luna. Do not attribute its outcomes to old B's weak-reader truncation.

## What48means

The new requested48answers perpolicy are16different questions×3repeats. B still has only4related source histories; C has16case clusters. Use per-repeat, per-question, per-ability/category tables and source-cluster uncertainty. Do not present48independent histories or pool B/Caccuracy. B4clusters makes inferential intervals fragile.

For historical comparisons, isolate B's3complete historical histories/12questions and C's2anchorcases. The expanded fourth Bscenario and14additional Ccases cannot silently enter a paired before/after claim.

## Frozen protocol and review requirements

Freeze case/question identity, category quotas, seed, source versions/hashes, OpenAI Astra max, reader/writer/capacity, output budgets and missing-call policy before dispatch. Preserve all errors, missing responses, negative outcomes and uncertain labels. LongMemEval source provenance and outcome-independent sampling support objectivity but do not make the local Oracle adapter an official full benchmark score.

Two independent Astra high reviewers should receive source, question, reference and answer without policy/model/repeat/automatic scores or each other's judgment. Preserve their disagreements and leave human confirmation pending until the user confirms this new batch.

A later writer repair should be a separately frozen source-only intervention with the same questions and reader. Never pass expected answers or reviewer labels into target memory.

Concrete archive member names, test IDs, selected-versus-sent values, source hashes and the complete52answer delivery ledger are in `findings.json`.
