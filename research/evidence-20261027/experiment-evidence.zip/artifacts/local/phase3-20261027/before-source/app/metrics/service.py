"""Deterministic, auditable Memory Health score calculation.

An unmeasured dimension is represented by ``None`` instead of zero. This
keeps benchmark summaries honest: an audit that did not test freshness cannot
be read as evidence of zero freshness performance.
"""

from app.schemas import Dimension, DimensionScores, EvaluationResult
from collections import Counter


class MetricsService:
    """Calculate scores without treating an untested dimension as zero.

    Only evaluations mapped to a known test are valid. At most one evaluation
    per test contributes to a score, which protects aggregates from accidental
    duplicate records while preserving the public API.
    """

    def calculate(
        self,
        evaluations: list[EvaluationResult],
        tests: dict[str, Dimension],
    ) -> tuple[float | None, list[DimensionScores]]:
        # Conflicting or repeated assessments cannot be resolved by row order.
        counts = Counter(evaluation.test_id for evaluation in evaluations)
        valid_by_test: dict[str, EvaluationResult] = {}
        for evaluation in evaluations:
            if evaluation.test_id in tests and counts[evaluation.test_id] == 1:
                valid_by_test[evaluation.test_id] = evaluation

        scores: list[DimensionScores] = []
        for dimension in Dimension:
            scoped = [
                evaluation
                for test_id, evaluation in valid_by_test.items()
                if tests[test_id] == dimension
            ]
            definitive = [evaluation for evaluation in scoped if evaluation.passed is not None]
            expected = sum(value == dimension for value in tests.values())
            total = len(definitive)
            passed = sum(evaluation.passed for evaluation in definitive)
            scores.append(DimensionScores(
                dimension=dimension,
                percentage=round((passed / total) * 100, 1) if total else None,
                passed=passed,
                total=total,
                uncertain_count=len(scoped) - total,
                expected_tests=expected,
                excluded_evidence_count=expected - len(scoped),
            ))

        # Macro-average only across dimensions with one or more valid tests.
        measured = [score.percentage for score in scores if score.percentage is not None]
        return (round(sum(measured) / len(measured), 1) if measured else None, scores)
